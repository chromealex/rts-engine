#include "AudioMixer.h"
#include <algorithm>
#include <cmath>
#include <cstring>

namespace rts::audio {

namespace {
constexpr int kBlock = 256;             // frames mixed per inner iteration
constexpr int kExtraSlots = 16;         // room for voices fading out after being stolen
constexpr float kStealFade = 0.006f;    // seconds
constexpr float kOpen = 20000.0f;       // low-pass "fully open" frequency for air absorption

float softClip(float x) {
    const float a = std::fabs(x);
    if (a <= 0.8f) return x;
    const float y = 0.8f + 0.2f * std::tanh((a - 0.8f) / 0.2f);
    return x < 0 ? -y : y;
}

void normalize3(float v[3]) {
    const float n = std::sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    if (n > 1e-6f) { v[0] /= n; v[1] /= n; v[2] /= n; }
}
} // namespace

float distanceGain(const DistanceDef& d, float distance, float hearing) {
    const float h = std::max(0.01f, hearing);
    const float minD = std::max(0.01f, d.minDistance * h), maxD = std::max(minD + 0.01f, d.maxDistance * h);
    if (distance <= minD) return 1.0f;
    if (distance >= maxD) return 0.0f;
    float g = 1.0f;
    switch (d.model) {
    case Rolloff::Inverse: g = minD / (minD + d.rolloff * (distance - minD)); break;
    case Rolloff::Linear: g = std::max(0.0f, 1.0f - d.rolloff * (distance - minD) / (maxD - minD)); break;
    case Rolloff::Exponential: g = std::pow(distance / minD, -d.rolloff); break;
    }
    // every model reaches silence at maxDistance: the last 20 % of the range fades out
    const float t = (distance - minD) / (maxD - minD);
    if (t > 0.8f) g *= (1.0f - t) / 0.2f;
    return std::clamp(g, 0.0f, 1.0f);
}

float farWeight(float t, float from) {
    if (t <= from) return 0.0f;
    const float u = std::clamp((t - from) / std::max(0.01f, 1.0f - from), 0.0f, 1.0f);
    return u * u * (3.0f - 2.0f * u);
}

Spatial spatialize(const ListenerPose& l, const Environment& env, const DistanceDef& d, float x, float y, float z) {
    Spatial s;
    const float h = std::max(0.01f, l.hearing);
    const float rel[3] = {x - l.pos[0], y - l.pos[1], z - l.pos[2]};
    s.distance = std::sqrt(rel[0] * rel[0] + rel[1] * rel[1] + rel[2] * rel[2]);
    const float minD = std::max(0.01f, d.minDistance * h), maxD = std::max(minD + 0.01f, d.maxDistance * h);
    s.t = std::clamp((s.distance - minD) / (maxD - minD), 0.0f, 1.0f);
    s.gain = distanceGain(d, s.distance, h);

    // listener axes: right = forward x up
    float f[3] = {l.forward[0], l.forward[1], l.forward[2]}, u[3] = {l.up[0], l.up[1], l.up[2]};
    normalize3(f);
    float r[3] = {f[1] * u[2] - f[2] * u[1], f[2] * u[0] - f[0] * u[2], f[0] * u[1] - f[1] * u[0]};
    normalize3(r);
    if (r[0] == 0 && r[1] == 0 && r[2] == 0) r[0] = 1;
    const float lx = rel[0] * r[0] + rel[1] * r[1] + rel[2] * r[2];
    const float lf = rel[0] * f[0] + rel[1] * f[1] + rel[2] * f[2];
    // close sources are wide, not hard-panned: the denominator never drops below half of minD
    s.pan = std::clamp(lx / std::max(s.distance, 0.5f * minD), -1.0f, 1.0f) * 0.85f;

    // air absorption: highs fade with distance (log-frequency interpolation down to airCutoff)
    if (env.airCutoff > 0 && d.air > 0) {
        const float a = std::min(1.0f, s.t * d.air);
        if (a > 0) s.cutoff = std::exp(std::log(kOpen) * (1 - a) + std::log(std::max(100.0f, env.airCutoff)) * a);
    }
    // behind the listener: a bit quieter and duller
    if (env.rear > 0 && s.distance > 1e-3f) {
        const float b = std::clamp(-lf / s.distance, 0.0f, 1.0f) * std::min(1.0f, env.rear);
        if (b > 0) {
            s.gain *= 1.0f - 0.3f * b;
            const float rc = std::exp(std::log(kOpen) * (1 - b) + std::log(1500.0f) * b);
            s.cutoff = s.cutoff > 0 ? std::min(s.cutoff, rc) : rc;
        }
    }
    s.send = env.reverb ? std::max(0.0f, (env.reverbNear + (env.reverbFar - env.reverbNear) * s.t) * d.reverb) : 0.0f;
    return s;
}

void Mixer::configure(int sampleRate, int maxVoices, bool reverb) {
    std::lock_guard<std::mutex> lock(mutex_);
    rate_ = sampleRate > 0 ? sampleRate : 48000;
    maxVoices_ = std::max(1, maxVoices);
    voices_.assign(size_t(maxVoices_ + kExtraSlots), Voice{});
    pending_.reserve(256);
    work_.reserve(256);
    {
        std::lock_guard<std::mutex> s(statusMutex_);
        status_.reserve(voices_.size());
    }
    tmp_.assign(size_t(kBlock) * 2, 0.0f);
    send_.assign(size_t(kBlock), 0.0f);
    track_.assign(size_t(kBlock) * 2, 0.0f);
    pendingMusic_.reset();
    reverbAllowed_ = reverb;
    env_ = Environment{};
    if (reverbAllowed_) reverb_.configure(rate_, env_.reverbSize, env_.reverbDamping);
    for (auto& m : music_) m = std::make_unique<Stream>();
}

uint64_t Mixer::push(MixCmd&& c) {
    std::lock_guard<std::mutex> lock(mutex_);
    c.seq = ++pushed_;
    pending_.push_back(std::move(c));
    return c.seq;
}

void Mixer::status(std::vector<VoiceStatus>& out, uint64_t& applied) const {
    std::lock_guard<std::mutex> lock(statusMutex_);
    out = status_;
    applied = statusApplied_;
}

uint32_t Mixer::nextRandom() {
    rng_ ^= rng_ << 13; rng_ ^= rng_ >> 17; rng_ ^= rng_ << 5;
    return rng_;
}

float Mixer::lowpassCoef(float cutoff) const {
    if (cutoff <= 0 || cutoff >= 0.45f * float(rate_)) return 1.0f;
    return 1.0f - std::exp(-6.2831853f * cutoff / float(rate_));
}

float Mixer::distanceTo(float x, float y, float z) const {
    const float dx = x - listener_.pos[0], dy = y - listener_.pos[1], dz = z - listener_.pos[2];
    return std::sqrt(dx * dx + dy * dy + dz * dz);
}

void Mixer::stopVoices(VoiceId id, float fadeStep) {
    for (auto& v : voices_) if (v.active && v.id == id) { v.stopping = true; v.fadeStep = fadeStep; }
}

template <class Match>
bool Mixer::makeRoom(const MixCmd& c, int max, Steal steal, Match match) {
    if (max <= 0) return true;
    // How loud a sound is (or would be) now: its level, bus, master, distance and fade. The same
    // estimate for playing and new sounds, so a voice started earlier in this block compares fairly.
    auto loudness = [&](const Clip& clip, float volume, Bus bus, bool spatial, const DistanceDef& d, float x, float y, float z, float fade) {
        float g = clip.rms * volume * gains_[size_t(bus)] * fade;
        if (spatial) g *= spatialize(listener_, env_, d, x, y, z).gain;
        return g;
    };
    int count = 0;
    Voice* victim = nullptr;
    float victimKey = 0;
    for (auto& v : voices_) {
        if (!v.active || v.stopping || v.role == MixCmd::Far || !match(v)) continue;
        ++count;
        if (v.priority > c.priority) continue;   // never stolen for a less important sound
        float key = 0;   // larger = better victim
        switch (steal) {
        case Steal::Oldest: case Steal::None: break;
        case Steal::Farthest: key = v.spatial ? distanceTo(v.x, v.y, v.z) : 0; break;
        case Steal::Quietest: key = -loudness(*v.clip, v.volume, v.bus, v.spatial, v.distance, v.x, v.y, v.z, v.fadeStep > 0 ? 1.0f : v.fade); break;
        }
        // ties (e.g. all non-positional) go to the oldest; lower priority always goes first
        if (!victim || v.priority < victim->priority || (v.priority == victim->priority && (key > victimKey + 1e-4f ||
            (std::fabs(key - victimKey) <= 1e-4f && v.serial < victim->serial)))) { victim = &v; victimKey = key; }
    }
    if (count < max) return true;
    if (!victim || steal == Steal::None) return false;
    if (victim->priority == c.priority) {
        if (steal == Steal::Farthest && (c.spatial ? distanceTo(c.x, c.y, c.z) : 0.0f) > victimKey + 1e-4f) return false;
        if (steal == Steal::Quietest && -loudness(*c.clip, c.volume, c.bus, c.spatial, c.distance, c.x, c.y, c.z, 1.0f) > victimKey + 1e-6f) return false;
    }
    stopVoices(victim->id, -1.0f / (kStealFade * float(rate_)));
    return true;
}

void Mixer::startVoice(MixCmd& c) {
    if (!c.clip || c.clip->frames() == 0) return;
    const float stealStep = -1.0f / (kStealFade * float(rate_));

    if (c.role == MixCmd::Far) {
        // the distant half follows its near half: it never counts against limits, and plays only
        // if the near half was accepted (it is pushed right after it)
        bool nearPlays = false;
        for (auto& v : voices_) nearPlays = nearPlays || (v.active && !v.stopping && v.id == c.id && v.role == MixCmd::Near);
        if (!nearPlays) return;
    } else {
        // per-sound limit, then every group of the sound; a refusal anywhere drops the sound
        if (!makeRoom(c, c.maxInstances, c.steal, [&](const Voice& v) { return v.sound == c.sound; })) return;
        if (groupDefs_) {
            for (int8_t g : c.groups) {
                if (g < 0 || size_t(g) >= groupDefs_->size()) continue;
                const SoundGroupDef& def = (*groupDefs_)[size_t(g)];
                if (!makeRoom(c, def.max, def.steal, [&](const Voice& v) { return std::find(std::begin(v.groups), std::end(v.groups), g) != std::end(v.groups); }))
                    return;
            }
        }
    }
    // global limit: steal the lowest priority (oldest first), or drop the new sound
    int playing = 0;
    Voice* victim = nullptr;
    for (auto& v : voices_) {
        if (!v.active || v.stopping) continue;
        ++playing;
        if (!victim || v.priority < victim->priority || (v.priority == victim->priority && v.serial < victim->serial)) victim = &v;
    }
    if (playing >= maxVoices_ && victim) {
        if (victim->priority > c.priority) return;
        if (victim->role == MixCmd::Near) stopVoices(victim->id, stealStep);   // with its far half
        else { victim->stopping = true; victim->fadeStep = stealStep; }
    }
    Voice* slot = nullptr;
    for (auto& v : voices_) if (!v.active) { slot = &v; break; }
    if (!slot) { // every slot is fading out: take the quietest
        for (auto& v : voices_) if (!slot || v.fade < slot->fade) slot = &v;
    }
    Voice& v = *slot;
    v = Voice{};
    v.active = true;
    v.id = c.id;
    v.sound = c.sound;
    v.bus = c.bus;
    v.priority = c.priority;
    v.serial = ++serial_;
    v.clip = std::move(c.clip);
    v.step = double(c.pitch) * double(v.clip->sampleRate) / double(rate_);
    v.volume = c.volume;
    v.soundVolume = c.soundVolume;
    v.pan = std::clamp(c.pan, -1.0f, 1.0f);
    if (c.startAt > 0) v.pos = std::min(double(c.startAt) * double(v.clip->sampleRate), std::max(0.0, double(v.clip->frames()) - 1));
    v.loop = c.loop;
    v.spatial = c.spatial;
    v.x = c.x; v.y = c.y; v.z = c.z;
    v.distance = c.distance;
    v.role = c.role;
    v.pairDistance = c.pairDistance;
    v.pairFrom = c.pairFrom;
    v.delay = c.delayFrames;
    v.duck = c.duck;
    std::copy(std::begin(c.groups), std::end(c.groups), std::begin(v.groups));
    if (c.sync != Quantize::Now && music_[0]->active) // stingers land on the music's beat / bar
        v.delay += uint32_t(std::max<int64_t>(0, framesToNext(*music_[0], c.sync)));
    if (c.fade > 0) { v.fade = 0; v.fadeStep = 1.0f / (c.fade * float(rate_)); }
}

void Mixer::apply(MixCmd& c) {
    switch (c.kind) {
    case MixCmd::Play: startVoice(c); break;
    case MixCmd::Stop: // both halves of a near/far pair share the id
        stopVoices(c.id, -1.0f / (std::max(c.fade, 0.002f) * float(rate_)));
        break;
    case MixCmd::StopAll:
        for (auto& v : voices_) if (v.active && (c.busMask >> unsigned(v.bus) & 1u)) { v.stopping = true; v.fadeStep = -1.0f / (std::max(c.fade, 0.002f) * float(rate_)); }
        break;
    case MixCmd::SetVoice:
        for (auto& v : voices_) if (v.active && v.id == c.id) {
            if (c.setMask & 1) v.volume = v.soundVolume * std::max(0.0f, c.volume);
            if (c.setMask & 2) v.pan = std::clamp(c.pan, -1.0f, 1.0f);
            if (c.setMask & 4) v.step = double(std::clamp(c.pitch, 0.01f, 8.0f)) * double(v.clip->sampleRate) / double(rate_);
        }
        break;
    case MixCmd::PauseVoice:
        for (auto& v : voices_) if (v.active && v.id == c.id) v.paused = c.paused;
        break;
    case MixCmd::SeekVoice:
        for (auto& v : voices_) if (v.active && v.id == c.id) {
            const double frames = double(v.clip->frames());
            v.pos = std::clamp(double(c.startAt) * double(v.clip->sampleRate), 0.0, std::max(0.0, frames - 1));
        }
        break;
    case MixCmd::MusicGain: musicGain_ = std::clamp(c.volume, 0.0f, 4.0f); break;
    case MixCmd::SetPos:
        for (auto& v : voices_) if (v.active && v.id == c.id) { v.x = c.x; v.y = c.y; v.z = c.z; } // both halves of a far pair
        break;
    case MixCmd::SetListener: listener_ = c.listener; break;
    case MixCmd::SetEnv:
        if (reverbAllowed_ && (c.env.reverbSize != env_.reverbSize || c.env.reverbDamping != env_.reverbDamping))
            reverb_.configure(rate_, c.env.reverbSize, c.env.reverbDamping);   // rare (bank load): may allocate
        env_ = c.env;
        break;
    case MixCmd::SetGains:
        std::copy(std::begin(c.gains), std::end(c.gains), std::begin(gains_));
        master_ = c.master;
        break;
    case MixCmd::Music: {
        const Stream& cur = *music_[0];
        if (cur.active && cur.list && c.playlist && cur.list->name == c.playlist->name && cur.target > 0) { pendingMusic_.reset(); break; }
        // leaving a playlist with a beat grid waits for its next beat / bar, so the music cuts musically
        if (cur.active && cur.list && cur.list->bpm > 0 && cur.list->transition != Quantize::Now) {
            pendingDelay_ = framesToNext(cur, cur.list->transition);
            pendingMusic_ = std::make_unique<MixCmd>(std::move(c));
            break;
        }
        pendingMusic_.reset();
        startMusic(c);
        break;
    }
    case MixCmd::SetIntensity: intensityTarget_ = std::clamp(c.intensity, 0.0f, 1.0f); break;
    case MixCmd::SetGroups: groupDefs_ = std::move(c.groupDefs); break;
    case MixCmd::StopMusic: {
        pendingMusic_.reset();
        const float frames = std::max(1.0f, c.fade * float(rate_));
        for (auto& m : music_) if (m->active) { m->target = 0; m->step = -std::max(m->gain, 0.0001f) / frames; }
        break;
    }
    }
}

void Mixer::mixVoices(float* buf, float* send, int n) {
    const float inv = 1.0f / 32768.0f;
    const bool reverbOn = reverbAllowed_ && env_.reverb;
    // ducking: music goes down quickly under announcements and comes back slowly
    float duckTarget = 0;
    for (auto& v : voices_) if (v.active && !v.stopping && v.delay == 0) duckTarget = std::max(duckTarget, v.duck);
    const float duckCoef = duckTarget > duck_ ? 1.0f - std::exp(-float(n) / (0.05f * float(rate_))) : 1.0f - std::exp(-float(n) / (0.6f * float(rate_)));
    duck_ += (duckTarget - duck_) * duckCoef;
    for (auto& v : voices_) {
        if (!v.active) continue;
        const float base = v.volume * gains_[size_t(v.bus)] * masterCur_;
        float g = base, pan = 0, lpT = 1, sendT = 0;
        if (v.spatial) {
            const Spatial sp = spatialize(listener_, env_, v.distance, v.x, v.y, v.z);
            float pair = 1;
            if (v.role != MixCmd::Single) { // crossfade by the near sound's distance range
                const float t = v.role == MixCmd::Near ? sp.t : spatialize(listener_, env_, v.pairDistance, v.x, v.y, v.z).t;
                const float w = farWeight(t, v.pairFrom);
                pair = v.role == MixCmd::Near ? 1 - w : w;
            }
            g = base * sp.gain * pair;
            pan = sp.pan;
            lpT = lowpassCoef(sp.cutoff);
            // the reverb tail falls off slower than the direct sound: far sounds get relatively wetter
            // (master is applied to the reverb output instead, so mute also silences the tail)
            if (reverbOn) sendT = v.volume * gains_[size_t(v.bus)] * pair * std::sqrt(sp.gain) * sp.send;
        }
        pan = std::clamp(pan + v.pan, -1.0f, 1.0f);
        const float tl = g * std::min(1.0f, 1.0f - pan), tr = g * std::min(1.0f, 1.0f + pan);
        if (v.fresh) { v.gl = tl; v.gr = tr; v.lp = lpT; v.send = sendT; v.fresh = false; }
        if (v.paused && !v.stopping) { v.gl = tl; v.gr = tr; v.lp = lpT; v.send = sendT; continue; }   // holds its place, silent
        int k0 = 0;
        if (v.delay > 0) { // speed of sound: the voice waits before it starts
            const uint32_t skip = std::min<uint32_t>(v.delay, uint32_t(n));
            v.delay -= skip;
            k0 = int(skip);
            if (k0 == n) { v.gl = tl; v.gr = tr; v.lp = lpT; v.send = sendT; continue; }
        }
        const float span = float(n - k0);
        const float dl = (tl - v.gl) / span, dr = (tr - v.gr) / span, dlp = (lpT - v.lp) / span, ds = (sendT - v.send) / span;
        float gl = v.gl, gr = v.gr, a = v.lp, sg = v.send;

        const Clip& c = *v.clip;
        const int16_t* pcm = c.pcm.data();
        const double frames = double(c.frames());
        const bool stereo = c.channels == 2;
        bool done = false;
        for (int k = k0; k < n; ++k) {
            if (v.pos >= frames) {
                if (v.loop) v.pos -= frames * std::floor(v.pos / frames);
                else { done = true; break; }
            }
            const size_t i0 = size_t(v.pos);
            size_t i1 = i0 + 1;
            if (double(i1) >= frames) i1 = v.loop ? 0 : i0;
            const float t = float(v.pos - double(i0));
            float sl, sr;
            if (stereo) {
                sl = (float(pcm[i0 * 2]) + (float(pcm[i1 * 2]) - float(pcm[i0 * 2])) * t) * inv;
                sr = (float(pcm[i0 * 2 + 1]) + (float(pcm[i1 * 2 + 1]) - float(pcm[i0 * 2 + 1])) * t) * inv;
            } else {
                sl = sr = (float(pcm[i0]) + (float(pcm[i1]) - float(pcm[i0])) * t) * inv;
            }
            gl += dl; gr += dr; a += dlp; sg += ds;
            // two-pole low-pass (air absorption); a == 1 passes the signal unchanged
            v.f1l += a * (sl - v.f1l); v.f2l += a * (v.f1l - v.f2l);
            v.f1r += a * (sr - v.f1r); v.f2r += a * (v.f1r - v.f2r);
            sl = v.f2l; sr = v.f2r;
            buf[k * 2] += sl * gl * v.fade;
            buf[k * 2 + 1] += sr * gr * v.fade;
            send[k] += (sl + sr) * 0.5f * sg * v.fade;
            if (v.fadeStep != 0) {
                v.fade += v.fadeStep;
                if (v.fade >= 1.0f) { v.fade = 1.0f; v.fadeStep = 0; }
                else if (v.fade <= 0.0f) { done = true; break; }
            }
            v.pos += v.step;
        }
        v.gl = tl; v.gr = tr; v.lp = lpT; v.send = sendT;
        if (done) { v.active = false; v.clip.reset(); }
    }
}

void Mixer::startMusic(MixCmd& c) {
    const float frames = std::max(1.0f, c.fade * float(rate_));
    // fades run at a constant rate: the whole volume in `fade` seconds (a half-faded stream takes half the time)
    auto fadeOut = [&](Stream& s) { s.target = 0; s.step = -std::max(s.list ? s.list->volume : s.gain, 0.0001f) / frames; };
    Stream& back = *music_[1];
    if (back.active && back.list && c.playlist && back.list->name == c.playlist->name) {
        // the playlist that is fading out was asked for again: it comes back from where it is
        std::swap(music_[0], music_[1]);
        if (music_[1]->active) fadeOut(*music_[1]);
        Stream& s = *music_[0];
        s.target = s.list->volume;
        s.step = s.gain < s.target ? s.target / frames : 0;
        if (s.step == 0) s.gain = s.target;
        return;
    }
    if (music_[0]->active) {
        std::swap(music_[0], music_[1]);   // current starts fading out
        fadeOut(*music_[1]);
    }
    Stream& s = *music_[0];
    s.layers.clear();
    s.list = std::move(c.playlist);
    s.active = false;
    if (!s.list || (s.list->tracks.empty() && s.list->layers.empty())) return;
    const size_t n = s.list->tracks.size();
    s.order.resize(n);
    for (size_t i = 0; i < n; ++i) s.order[i] = i;
    if (s.list->shuffle && n > 1) for (size_t i = n - 1; i > 0; --i) std::swap(s.order[i], s.order[nextRandom() % (i + 1)]);
    s.index = 0;
    if (!openTrack(s)) return;
    s.active = true;
    s.gain = 0;
    s.target = s.list->volume;
    s.step = s.target / frames;
}

bool Mixer::openLayers(Stream& s, const std::vector<MusicTrack>& defs, float loopStart, float loopEnd) {
    s.layers.clear();
    for (auto& d : defs) {
        auto l = std::make_unique<Layer>();
        if (!d.bytes || !l->dec.open(d.bytes, rate_)) continue;
        l->threshold = d.intensity;
        l->gain = d.intensity <= 0 || intensity_ >= d.intensity ? 1.0f : 0.0f;
        s.layers.push_back(std::move(l));
    }
    s.pos = 0;
    s.loopStart = loopStart >= 0 ? int64_t(double(loopStart) * rate_) : -1;
    s.loopEnd = loopEnd > 0 ? int64_t(double(loopEnd) * rate_) : 0;
    if (s.loopEnd > 0 && s.loopStart >= s.loopEnd) s.loopStart = -1;
    return !s.layers.empty();
}

bool Mixer::openTrack(Stream& s) {
    const Playlist& list = *s.list;
    if (!list.layers.empty()) return openLayers(s, list.layers, std::max(0.0f, list.layerLoopStart), list.layerLoopEnd);  // stems always loop
    const size_t n = list.tracks.size();
    for (size_t attempt = 0; attempt < n; ++attempt) {
        if (s.index >= n) {
            if (!list.loop) return false;
            s.index = 0;
            if (list.shuffle && n > 1) { // reshuffle, avoiding an immediate repeat
                const size_t last = s.order.back();
                for (size_t i = n - 1; i > 0; --i) std::swap(s.order[i], s.order[nextRandom() % (i + 1)]);
                if (s.order[0] == last) std::swap(s.order[0], s.order[n - 1]);
            }
        }
        const MusicTrack& t = list.tracks[s.order[s.index++]];
        if (openLayers(s, {t}, t.loopStart, t.loopEnd)) return true;
    }
    return false;
}

bool Mixer::loopBack(Stream& s) {
    const int64_t to = std::max<int64_t>(0, s.loopStart);
    for (auto& l : s.layers) if (!l->dec.seek(to)) return false;
    s.pos = to;
    return true;
}

int64_t Mixer::framesToNext(const Stream& s, Quantize q) const {
    if (!s.list || s.list->bpm <= 0 || q == Quantize::Now) return 0;
    const double beat = double(rate_) * 60.0 / double(s.list->bpm);
    const double unit = q == Quantize::Bar ? beat * std::max(1, s.list->beatsPerBar) : beat;
    const double t = double(s.pos) - double(s.list->offset) * rate_;
    if (t < 0) return int64_t(-t);
    const double rem = unit - std::fmod(t, unit);
    return rem >= unit - 0.5 ? 0 : int64_t(rem);
}

// Mixes the playing track's layers into `out` (stereo, n frames, added). Loops A-B; returns the
// frames produced: fewer than n means the track ended.
int Mixer::readTrack(Stream& s, float* out, int n) {
    const bool loops = s.loopStart >= 0;
    int done = 0, jumps = 0;
    while (done < n && !s.layers.empty()) {
        int want = n - done;
        if (s.loopEnd > 0) want = int(std::min<int64_t>(want, s.loopEnd - s.pos));
        if (want <= 0) { if (!loops || ++jumps > 4 || !loopBack(s)) break; continue; }
        int got = want;
        for (auto& l : s.layers) {
            const float target = l->threshold <= 0 ? 1.0f : std::clamp((intensity_ - l->threshold) / 0.15f + 0.5f, 0.0f, 1.0f);
            const float dg = (target - l->gain) / float(want);
            float g = l->gain;
            const int r = l->dec.read(tmp_.data(), want);
            for (int k = 0; k < r; ++k) {
                g += dg;
                out[(done + k) * 2] += tmp_[size_t(k) * 2] * g;
                out[(done + k) * 2 + 1] += tmp_[size_t(k) * 2 + 1] * g;
            }
            l->gain = target;
            got = std::min(got, r);
        }
        s.pos += got;
        done += got;
        if (got < want) { // end of file: loop, or the track is over
            if (!loops || ++jumps > 4 || !loopBack(s)) break;
        }
    }
    return done;
}

void Mixer::mixStream(Stream& s, float* buf, int n) {
    if (!s.active) return;
    const float bus = gains_[size_t(Bus::Music)] * masterCur_ * (1.0f - duck_) * musicGainCur_;
    int done = 0, reopened = 0;
    while (done < n && s.active) {
        const int want = n - done;
        std::fill(track_.begin(), track_.begin() + size_t(want) * 2, 0.0f);
        const int got = readTrack(s, track_.data(), want);
        for (int k = 0; k < got; ++k) {
            if (s.step != 0) {
                s.gain += s.step;
                if ((s.step > 0 && s.gain >= s.target) || (s.step < 0 && s.gain <= s.target)) { s.gain = s.target; s.step = 0; }
            }
            const float g = s.gain * bus;
            buf[(done + k) * 2] += track_[size_t(k) * 2] * g;
            buf[(done + k) * 2 + 1] += track_[size_t(k) * 2 + 1] * g;
        }
        done += got;
        if (s.target <= 0 && s.step == 0 && s.gain <= 0) { s.layers.clear(); s.active = false; break; }
        if (got < want) { // track ended inside this block: continue with the next one
            s.layers.clear();
            // a playlist of empty/broken tracks must not spin forever inside the audio callback
            if (++reopened > int(s.list->tracks.size()) + 1 || !openTrack(s)) { s.active = false; break; }
        }
    }
}

// Big battles stack dozens of sounds: a peak limiter (instant attack per block, ~0.3 s release)
// keeps the mix under the soft-clip knee instead of letting it saturate.
void Mixer::limit(float* buf, int n) {
    constexpr float kThreshold = 0.7f;
    float peak = 0;
    for (int k = 0; k < n * 2; ++k) peak = std::max(peak, std::fabs(buf[k]));
    const float release = std::exp(-float(n) / (0.3f * float(rate_)));
    limEnv_ = std::max(peak, limEnv_ * release);
    const float target = limEnv_ > kThreshold ? kThreshold / limEnv_ : 1.0f;
    // attack: never ramp up into a louder block; release: ramp smoothly across the block
    const float start = std::min(limGain_, target), step = (target - start) / float(n);
    float g = start;
    for (int k = 0; k < n; ++k) {
        g += step;
        buf[k * 2] = softClip(buf[k * 2] * g);
        buf[k * 2 + 1] = softClip(buf[k * 2 + 1] * g);
    }
    limGain_ = target;
}

void Mixer::render(float* out, int frames) {
    {
        std::lock_guard<std::mutex> lock(mutex_);
        work_.swap(pending_);
    }
    uint64_t applied = applied_;
    for (auto& c : work_) { apply(c); applied = std::max(applied, c.seq); }
    work_.clear();
    applied_ = applied;

    int written = 0;
    while (written < frames) {
        const int n = std::min(kBlock, frames - written);
        float* buf = out + size_t(written) * 2;
        musicGainCur_ += (musicGain_ - musicGainCur_) * 0.5f;   // follows over ~one block (no clicks)
        if (std::fabs(musicGain_ - musicGainCur_) < 1e-4f) musicGainCur_ = musicGain_;
        std::memset(buf, 0, sizeof(float) * size_t(n) * 2);
        std::fill(send_.begin(), send_.begin() + n, 0.0f);
        // master follows its target over ~one block (mute/unmute without clicks)
        masterCur_ += (master_ - masterCur_) * 0.5f;
        if (std::fabs(master_ - masterCur_) < 1e-4f) masterCur_ = master_;
        if (pendingMusic_) { // a quantized playlist switch
            pendingDelay_ -= n;
            if (pendingDelay_ <= 0) { startMusic(*pendingMusic_); pendingMusic_.reset(); }
        }
        intensity_ += (intensityTarget_ - intensity_) * (1.0f - std::exp(-float(n) / (1.5f * float(rate_))));
        mixVoices(buf, send_.data(), n);
        if (reverbAllowed_ && env_.reverb) reverb_.process(send_.data(), buf, n, env_.reverbWet * masterCur_);
        for (auto& m : music_) mixStream(*m, buf, n);
        limit(buf, n);
        written += n;
    }
    int count = 0;
    for (auto& v : voices_) count += v.active ? 1 : 0;
    active_.store(count, std::memory_order_relaxed);
    {   // what the main thread sees of the voices (voice handles); try_lock: never block the audio thread
        std::unique_lock<std::mutex> lock(statusMutex_, std::try_to_lock);
        if (lock.owns_lock()) {
            status_.clear();
            for (auto& v : voices_)
                if (v.active && !v.stopping && v.role != MixCmd::Far)
                    status_.push_back({v.id, float(v.pos / double(v.clip->sampleRate)), v.paused});
            statusApplied_ = applied_;
        }
    }
}

} // namespace rts::audio
