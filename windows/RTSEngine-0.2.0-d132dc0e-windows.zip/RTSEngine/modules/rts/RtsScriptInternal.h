// Internals shared by the scripting files (RtsScript.cpp: VM, sandbox, fx, state; RtsScriptApi.cpp:
// the `game` table; view/RtsViewScript.cpp: presentation VM). Not a public header.
//
// Error discipline: Lua is compiled as C, so lua_error() is a longjmp that skips C++ destructors.
// Bindings are therefore written as `int impl(lua_State*, Vm&)` returning the number of results, or
// -1 after setting vm.err; the wrapper `bind<impl>` raises the error after impl has returned (all its
// C++ locals destroyed). Inside impl only non-raising Lua calls are used on user values (raw access,
// lua_to*, luaL_testudata); pushes can only fail on out-of-memory.
#pragma once
#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include <vector>
#include "RtsScript.h"
#include "../../engine/core/Fixed.h"

extern "C" {
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
}

namespace rts { class Simulation; }

namespace rts::game::script {

enum class Mode : uint8_t { Sim, View };

struct Vm {
    lua_State* L = nullptr;
    RtsLuaCtx ctx{};
    Mode mode = Mode::Sim;
    RtsModule* module = nullptr;
    Simulation* sim = nullptr;              // set while scripts run
    std::string err;                        // pending binding error (see header comment)
    // instruction budget (count hook)
    int64_t budget = 1000000, used = 0;
    bool exceeded = false;
    size_t mem = 0, memLimit = 0;           // allocator accounting (crash guard, not a game rule)
    bool loading = false;                   // files are being run: handler registration allowed
    std::map<std::string, std::string> sources;   // path -> text (require)
    std::function<void(bool error, const std::string& text)> log;
    void* owner = nullptr;                  // ScriptEngine::Impl / view host
    // per-entity data (game.data), provided by the simulation engine; view VMs read the stored copy
    std::function<void(Entity)> pushData;
    std::function<bool(Entity, const char*)> dataHas;
    // radius queries: a bucket grid of the living units, built on first use and dropped whenever C++ may
    // have moved / spawned / killed something (every entry into the VM and every non-query binding)
    struct Spatial { int cell = 8, w = 0, h = 0; std::vector<std::vector<Entity>> buckets; std::vector<int32_t> used; };
    Spatial spatial;
    bool spatialOk = false;

    ~Vm();
    bool open(Mode m, size_t memLimit);     // new state + sandbox
    void close();
};

Vm& vmOf(lua_State* L);

// bind: any binding (it may change the world); bindQ: a pure query (keeps the radius-query grid)
template <int (*F)(lua_State*, Vm&), bool kQuery = false>
int bind(lua_State* L) {
    Vm& vm = vmOf(L);
    if constexpr (!kQuery) vm.spatialOk = false;
    int n = F(L, vm);
    if (n >= 0) return n;
    luaL_where(L, 1);
    lua_pushlstring(L, vm.err.data(), vm.err.size());
    vm.err.clear();
    lua_concat(L, 2);
    return lua_error(L);
}
template <int (*F)(lua_State*, Vm&)> int bindQ(lua_State* L) { return bind<F, true>(L); }
inline int fail(Vm& vm, std::string msg) { vm.err = std::move(msg); return -1; }

// ---- fx numbers
void pushFx(lua_State* L, Fixed v);
Fixed* testFx(lua_State* L, int idx);
// Integer or fx at idx (View mode: any number). False with vm.err set otherwise.
bool argFx(lua_State* L, Vm& vm, int idx, Fixed& out, const char* what);
bool argInt(lua_State* L, Vm& vm, int idx, int64_t& out, const char* what);
bool optFx(lua_State* L, Vm& vm, int idx, Fixed& out, Fixed def, const char* what);
// A number for presentation: fx / integer / float as double (view scripts only).
double toDouble(lua_State* L, int idx);
std::string fxText(Fixed v);            // integer-only decimal formatting ("1.25", "-3")

// ---- values
void pushJson(lua_State* L, const Json& j);      // numbers: integer when whole, fx otherwise
// Canonical serialization of the value at idx (bool, integer, fx, string, nested tables with
// integer/string keys, sorted). False with `where` = path of the offending value. lenient: values that
// can't be stored are left out (`where` = the first one) and the rest is written.
bool serialize(lua_State* L, int idx, std::string& out, std::string& where, int depth = 0, bool lenient = false);
// Pushes the value; returns the read position (0 on malformed input, pushes nil).
size_t deserialize(lua_State* L, const std::string& in, size_t pos = 0, int depth = 0);
// Does a serialized table have this (string) key at its top level? (no Lua state needed)
bool blobHasKey(const std::string& blob, const char* key);
// Source scan for float literals (sim scripts): "" or "line N: ...".
std::string findFloatLiteral(const std::string& text);
// Load a chunk (text only) into the VM; pushes the function or returns false with message.
bool loadChunk(Vm& vm, const std::string& name, const std::string& text, std::string& error);
// lua_pcall with budget reset handling; on error logs "message" and returns false.
bool protectedCall(Vm& vm, int nargs, int nresults, std::string* error = nullptr);
// VM instructions run since the budget was last reset (vm.used plus the count hook's residual): exact.
int64_t instructionsUsed(const Vm& vm);
// every GameEvent by its Lua name ("unit_died", "gathered", "status_start", ...); nullptr / -1 when unknown
const char* simEventName(uint16_t type);
int simEventType(const std::string& name);
// built-in command names of game.command ("move", "train", ...; RtsScriptApi.cpp)
const char* commandName(uint16_t type);
// script commands (RtsScriptCommands.cpp)
int argSlots(const ScriptCommandDef& d);
bool encodeScriptArgs(lua_State* L, Vm& vm, int idx, const ScriptCommandDef& d, Command& c);
bool validateScriptCommand(RtsModule& m, Simulation& sim, const ScriptCommandDef& d, Command& c);
void pushScriptArgs(lua_State* L, const ScriptCommandDef& d, const Command& c);

// ---- API tables (RtsScriptApi.cpp)
void openGameApi(Vm& vm);           // `game` table: queries always, actions in Sim mode
void openTerritoryApi(Vm& vm);      // extends the game table at the stack top
void openGridApi(Vm& vm);           // pure integer-grid navigation queries
void openStdApi(Vm& vm);            // `rts` table for the standard library (RtsScriptStd.cpp)
void openFieldApi(Vm& vm);          // `field` table: grid fields (RtsGridFieldsApi.cpp)
void pushEntity(lua_State* L, Entity e);
bool argEntity(lua_State* L, int idx, Entity& out); // integer handle (no liveness check)

} // namespace rts::game::script
