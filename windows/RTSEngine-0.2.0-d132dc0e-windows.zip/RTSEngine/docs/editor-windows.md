# Adding a window to the editor

The editor (`apps/editor`) is a set of dockable Dear ImGui windows (docking branch). Every window
is a small class; the editor creates one instance of each registered class, lists it in the top
menu of its group (`group()`, see below), docks it into the default layout, saves the user's layout
(`<userDataDir>/editor_layout.ini`) and lets agents open/close it over MCP (`editor_windows`,
`editor_window`).

## 1. Create the file

Put a `.cpp` file in `apps/editor/windows/`. Every file there is compiled into the editor
automatically (CMake `GLOB ... CONFIGURE_DEPENDS`), nothing else to register.

```cpp
// apps/editor/windows/BalanceWindow.cpp
#include "../Editor.h"
#include "../EditorUtil.h"     // ui::inputString, ui::inputMultiline, ui::help

namespace rts::editor {

class BalanceWindow : public EditorWindow {
public:
    const char* id() const override { return "balance"; }        // stable latin id (MCP, layout)
    const char* title() const override { return "Баланс"; }      // tab title, Russian (must be unique)
    const char* group() const override { return "logic"; }       // top menu: scene | world | look | logic | publish | service
    const char* dockArea() const override { return "bottom"; }   // left | left-bottom | right | center | bottom
    int order() const override { return 5; }                     // tab order in that area (0 = shown first)
    bool openByDefault() const override { return false; }        // hidden until opened from the menu

    void draw(Editor& ed) override {                             // called between ImGui::Begin/End
        for (auto& t : ed.rules().types) {
            if (t.cost.empty()) continue;
            ImGui::Text("%s: %lld hp", t.name.c_str(), (long long)t.maxHp.toInt());
        }
    }
    void update(Editor& ed, double dt) override {}              // optional: every frame, even when closed
};

RTS_EDITOR_WINDOW(BalanceWindow);

} // namespace rts::editor
```

`title()` is the plain tab text (MCP `editor_windows` reports it). The ImGui name is
`imguiName()` = `"<icon>  <title>###<id>"`: the `###id` part keeps docking, saved layouts and focus
stable. Use `imguiName()` (or `ed.focusWindow("id")`) whenever ImGui needs the window's name. The tab
icon comes from `windowIconFor(id())` in `EditorIcons.h`, or override `icon()`.

Rebuild the editor; the window appears in the menu of its group. New windows join the tabs of their
`dockArea` the first time they open; **Вид → Сбросить раскладку** rebuilds the default layout.

### Menus and groups

| `group()` | Top menu | Windows | Workspace (Вид → Раскладки) |
|---|---|---|---|
| `scene` | **Сцена** | Сцена, Игра, Иерархия, Инспектор, Инструменты | Карта и объекты |
| `world` | **Мир** | Рельеф, Тайлы, Генерация, Материалы, Поля, Туман войны | Ландшафт |
| `look` | **Графика** | Освещение, Постэффекты, Эффекты, Модели, Оверлеи | Графика и эффекты |
| `logic` | **Логика** | Проект, Правила, Скрипты, Статистика (+ запуск теста) | Правила и тест |
| `publish` | **Сборка** | Сборка, Иконки и заставка (+ цели сборки) | Выпуск |
| `service` | **Вид** | Консоль, ИИ-агент | — |
| anything else | **Вид → Другие окна** | | |

A workspace (`Editor::openWorkspace(group)`) opens the default windows plus every window of the group,
rebuilds the layout and brings the group's tabs to the front. Clicking a window in a menu opens it and
brings it to the front; clicking it again while it is in front hides it.

Other menus: **Файл** (projects, maps), **Правка** (undo, symmetry, ramps, map check), **Вид** (service
windows, workspaces, what the Scene shows, theme). Shortcuts: Ctrl/Cmd+S save, Ctrl/Cmd+Z / Y undo/redo,
F5 test, Ctrl/Cmd+B build window; in the Scene 1…0 pick tools, F focus, [ ] brush size, Delete removes.

## 2. What a window can use (`Editor` public API, `apps/editor/Editor.h`)

| API | What for |
|---|---|
| `ed.ws()` | the `Workspace`: project (manifest, `rulesJson`, parsed `rules`), map document, activity log, and **`ws().call(op, params)`** — run any MCP operation (`rules_set`, `entity_place`, `match_run`, ...) exactly like an agent; prefer this over editing data directly, it validates and records history |
| `ed.doc()` | the open map (`MapDoc`): `data` (terrain layers, players, entities, roads, `extra` JSON blocks), `beginEdit()` before a change (undo snapshot), `touched()` after a change (views rebuild) |
| `ed.rules()` | parsed rules of the open game (read-only; change rules through `rules_set`) |
| `ed.selection`, `ed.select(...)`, `ed.selectEntity(i)` | what the Inspector shows |
| `ed.tool`, `ed.brush`, `ed.placeType`, ... | Scene tool state |
| `ed.sceneCam`, `ed.focusScene(x, z)`, `ed.flash(x0, z0, x1, z1)` | camera and highlight in Scene |
| `ed.playing()`, `ed.sim()`, `ed.simModule()`, `ed.startPlay(slot)`, `ed.stopPlay()` | the play-test simulation (read-only from windows; issue player commands with `ed.issueCommand`) |
| `ed.playHistory`, `ed.frameHistory` | sampled statistics |
| `Viewport` + `ed.renderScene(vp, cam, overlays)` / `ed.renderGame(vp, cam)` | a 3D view of the map inside your window (see `SceneWindow.cpp`: `vp.ensure()`, render, `vp.image()`) |
| `ed.status` | text in the status bar |

Rules for windows:
- Never write into the simulation (`ed.sim()`): it is deterministic and replayable; use commands.
- Change rules and maps through `ws().call(...)` or `doc().beginEdit()` + edit + `doc().touched()`.
- Keep per-window state in members (one instance per window).
- Russian UI text, English code and comments (see AGENTS.md).

## 3. Look: theme, icons, toolbars

The editor style (dark / light, accent presets, menu **Вид → Тема**, MCP `editor_theme`) lives in
`apps/editor/EditorTheme.*`; windows don't set colours of their own. Prefer the theme's colours
(`ImGui::GetStyle().Colors`, `ui::accentColor()`, `ed.theme().palette()`) over hard-coded RGB, so
both themes stay readable.

Icons: Lucide font merged into the UI font, constants in `apps/editor/EditorIcons.h`
(`ImGui::Button(ICON_PLAY " Играть")`). Helpers in `EditorUtil.h`:

| Helper | What |
|---|---|
| `ui::toolButton(ICON_X, "Подсказка", active, enabled)` | square icon button: hover / active (accent) states, tooltip |
| `ui::beginSegment()` / `ui::endSegment()` | segmented group of tool buttons on one background (`SameLine()` between them) |
| `ui::toolbarDivider()` | thin vertical divider between groups |
| `ui::beginToolbar()` / `ui::endToolbar(y)` | toolbar strip at the top of a `zeroPadding()` window (Scene, Game) |
| `ui::button(ICON_X, "Текст", primary)` | icon + label button; `primary` = filled with the accent |
| `ui::emptyState(...)` / `ui::emptyStateHere(icon, title, hint)` | centred placeholder: big icon, title, hint |
| `ui::heading("Текст")` | section title in the semibold heading font |
| `ui::section(ICON_X, "Текст")` | section title with an icon and a hairline to the right edge (instead of `SeparatorText`) |
| `ui::beginProps("##id")` + `ui::prop("Подпись", "подсказка")` + widget with a `"##"` label + `ui::endProps()` | property grid: dim labels in a left column, full-width widgets on the right; `ui::propWide()` for a row of its own (checkbox, buttons) |
| `ui::searchField("##id", str, "Подсказка")` | search field with the hint inside and a clear button; `ui::contains(text, filter)` matches case-insensitively |
| `ui::segmented("##id", value, labels, n)` / `ui::choiceGrid(...)` | mode switch filling the width / wrapping tiles for 5+ options |
| `ui::callout(ui::Tone::Warn, "…")`, `ui::resultMessage(msg)` | tinted box with an icon for results, warnings, errors (`resultMessage` guesses the tone) |
| `ui::toneText(tone, fmt, ...)`, `ui::toneColor(tone)`, `ui::badge(text, color)` | theme colours for ok / warning / error text and small count badges — never hard-coded RGB |
| `ui::headerCard(icon, title, subtitle, color)` | card at the top of a panel (Inspector: what is selected) |
| `ui::wideButton(icon, text, index, count, primary)` | buttons that share one row evenly |
| `ui::hint("…")`, `ui::menuItem(icon, text, shortcut)`, `ui::viewportLabel(dl, pos, text)` | dim explanation line, menu item with an icon, readable label over a 3D view |

Style rules: Russian UI text; a window with nothing to show draws `ui::emptyStateHere` with what to do;
results of actions go to a callout in the window (and `ed.status` for the status bar); quote other
windows by their Russian title in «ёлочках» («Сцена», «Консоль»).

## 4. Exposing it to agents

If the window adds an action an agent should be able to do, register an operation (in the
window's constructor is too early; do it in `update()` once, or in `EditorAgent.cpp`):

```cpp
ed.ws().registerOp({"balance_report", "Damage per cost of every unit type.", Json::parse("{}"),
                    [&ed](const Json&) { Json r = Json::object(); /* ... */ return r; }, true});
```

Operations appear in MCP `tools/list` for agents connected through `rtsmcp` (the tool list is the
`Workspace` registry; GUI-only operations have `guiOnly = true` and fail politely without the
editor window).

## Game HUD

The Game play-test renders `ui/hud.rml` and `ui/howto.rml` through RmlUi into its
viewport after the scene. Missing documents, styles and images fall back to
`engine/assets/ui`; game fonts (`fonts/ui.ttf`, `fonts/title.ttf`) follow the client.
The editor selects the game language with the same saved-choice/system-language rules.
Restart the play-test after editing RML, RCSS or fonts to reload them.

`apps/client/UiModel.h` owns the shared `game` model schema and change-only updates.
`apps/editor/GameHud` adapts the editor simulation to that model: resource/status
panels, script HUD cards, support actions and region ratios. Buttons issue Commands;
pause/restart/stop operate on the editor play-test. Pointer coordinates are local to
the viewport; RmlUi layout and projection use its framebuffer size and device density.
World-space region markers remain editor overlays.

This is an embedded play-test HUD, not a second GameClient: client lobby/menu flow,
UI Lua `game` APIs, audio playback and the client's full standard RTS command card/minimap
are not hosted by the editor adapter. Use a client run for those screens and systems.
