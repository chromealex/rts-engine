# Game data format (RTSEngine)

A game is a folder `<project>/`:

```
game.json        manifest: name, id, version, rules file, maps list, orientation, icon, input
rules.json       resources, types (units/structures/objects), techs, factions, game rules, triggers
maps/*.json      terrain, players, objects, waves, triggers, areas, victory overrides
audio.json       sounds, music and which sound plays on which game event (optional: no file = silent)
models/ ui/ ...  assets (glTF models, textures, UI, sounds); 2D images may be packed into atlases (see Texture atlases)
```

JSON allows `//` comments. **Numbers are plain decimals** (`1.5`, never `1e3`): the simulation is
fixed-point and deterministic. Seconds are game seconds, distances are map cells. Every block below
is optional — the blocks present on a type decide what it can do.

## game.json

```json
{ "name": "Iron and Gold", "id": "com.studio.ironandgold", "version": "0.1.0", "build": 1,
  "module": "rts", "rules": "rules.json",
  "maps": [{ "file": "maps/valley.json", "title": "River Valley (1v1)" }],
  "orientation": "landscape", "icon": "icon.png" }
```
`"audio"`: another name for the sound file (default `audio.json`).

`"icons"` and `"splash"`: game icons for every platform and the loading screen — see "Icons and
splash" below (the old single `"icon"` still works as the master icon).

Optional `"camera"` block (2D games, see "2D games" below):
`{"projection": "ortho", "pitch": 90, "yaw": 0, "fov": 43, "zoom": 20, "zoomMin": 8, "zoomMax": 40, "pixelsPerCell": 32, "rotate": false}`.

Optional `"playerColors"`: `[neutral, slot 1, ..., slot 8]` (overlay colour syntax: `"#rrggbb"`, `[r, g, b]` 0..1 or
0..255; `null` keeps a slot) replaces the built-in player palette used for team colours, overlays and the territory
overlay default (`RtsOverlayData::configurePlayerColors`, applied when a match starts in the client and the editor).

Lighting block (game.json / map `"lighting"`), flat-art keys: `"day": {"sun", "sky", "ground", "fog": [r, g, b],
"sunK": k}` replaces fields of the day palette (of the preset or the renderer), `"fogDensity"` (0 = no distance fog),
`"tonemap": false` (lit shaders clamp instead of the ACES fit; with `sunK` 0 and white sky / ground an unlit material
shows its colour unchanged), `"modelOutput": "srgb"` (model shaders encode their linear result with the exact sRGB curve,
as a Unity project in linear colour space does, instead of the engine's default sqrt, which renders midtones darker; GLSL
and MSL). Map keys win over game keys.

## rules.json — top level

| key | meaning |
|---|---|
| `supplyCap` | max supply/population (default 200) |
| `ai` | `{"controller":"builtin"}` (default) or `{"controller":"scripted"}`. Scripted control makes the generic RtsAI submit no commands in client, editor and headless. The game must provide its own controller; Lua handlers, human/network commands, combat, production and victory remain enabled. This is not the `waves` player flag and does not exempt players from defeat. |
| `maxQueue` | production queue length (5) |
| `costModel` | `"upfront"` (pay when ordering) or `"progressive"` (Total Annihilation: pay while building; stalls when short) |
| `sellRefund` | fraction refunded when selling a structure (0.5) |
| `buildRadius` | >0: structures only within N cells of own structures with `extendsBase` |
| `levelHeight` | visual height of one cliff level |
| `waveClock` | seconds; structures with `waveSpawn` release their units together on this clock (lane battlers) |
| `autoBuild` | `{"pool": [types], "cost": {res: n}, "growth": 0.5}` — a BUILD button: the sim picks a type from the pool and a spot next to the base automatically; cost grows by `growth` per structure already auto-built |
| `victory` | `"noStructures"` (default), `"noUnits"`, `"noEntities"`, `"keyUnits"` (lose when all `key` objects die), or an object: `{"mode": "tickets", "tickets": 500, "drain": 1}`, `{"mode": "survive", "seconds": 600}`, `{"mode": "score", "seconds": 240, "keyLoses": true}`, `{"mode": "territory", "share": 0.9}` (a team owning that share of all claimable cells wins; a player with no territory is out) |
| `fogOfWar` | `{"mode": "full"}` — fog of war: `full` (default: unexplored black, explored dim), `explored` (the whole map starts explored, enemies only in sight), `none` (no fog, everyone sees everything); `shareAllies` (true); `lineOfSight` (false: 3D visibility by heights and blockers, see "3D line of sight"); `rockHeight` (2: undug rock as an occluder). A map may override `mode`. The other keys are visual, see "Fog of war look" |
| `heights` | `{"blockVision": true, "missUphill": 0.3, "rangePerLevel": 1, "damagePerLevel": 0.1}` — cliff levels: lower ground can't see up, shots uphill can miss, higher ground adds range and damage. With `terrain.model: "heightfield"` the advantage is the height difference / `levelHeight` (fractional), `missUphill` scales with it (full chance from one level below) and vision follows real line of sight |
| `terrain` | `{"model": "heightfield", "maxSlope": {"ground": 0.8, "sand": 0.6}, "buildSlope": 0.35, "uphillSpeed": 0.5, "downhillSpeed": 0.2, "eyeHeight": 1, "targetHeight": 0.5}` — terrain model, see "Heightfield terrain". `model`: `"levels"` (default: cliff levels + ramps), `"flat"` (levels ignored), `"heightfield"`. Other keys of this block are visual (view) and ignored by the simulation |
| `regions` | `{"claimCost": {"food": 100}, "claimCostGrowth": 0.5, "buildOnlyOwned": true, "productionPerRegion": 0.1}` — territory (Northgard; with flags: Z) |
| `upkeep` | `[{"supply": 50, "gatherMult": 0.7}, {"supply": 80, "gatherMult": 0.4}]` — gathering yields less with a big army (Warcraft III) |
| `armorTypes`, `damageTable` | `"damageTable": {"pierce": {"heavy": 0.5, "light": 1.5}}` multipliers by damage type → armor type |
| `resources` | see below |
| `types` | see below |
| `techs` | see below |
| `factions` | see below |
| `triggers` | see "Triggers" (also allowed in maps) |
| `scripts`, `viewScripts`, `scriptBudget` | Lua scripts of the game (also allowed in maps): `["scripts/rules.lua"]` run in the deterministic simulation (integers and `fx` numbers, no floats), `viewScripts` only on the local machine (notices, effects, sounds); `scriptBudget` = VM instructions per tick (default 1000000). Effects and trigger actions/conditions `{"type": "script", "fn": "name"}` call script functions. See docs/scripting.md |
| `diggable`, `rooms`, `territory`, `hand`, `possession` | see "Dungeon management and territory" |
| `playerAbilities` | see "Player abilities" |
| `storage` | `"player"` (default: one stock per player) or `"buildings"`: goods live in building inventories, see "Settlers economy" |
| `roadNetwork` | `{"cost": {"stone": 1}, "speed": 1.5, "required": true}` — player-built road cells (map char `+`), faster movement, deliveries only between buildings on one network |
| `movement` | `{"avoidance": "rvo", "neighbors": 8, "timeHorizon": 1.5}` — local avoidance between moving units: `rvo` (default, ORCA velocity obstacles in fixed point, idle allies step aside) `simple` (separation only), or `none` (no mobile avoidance/separation); `neighbors` = agents considered per unit (quality/cost knob), `timeHorizon` in seconds. See "Movement and bodies" |
| `lanes` | `{"left": 4, "right": 2, "spacing": 0.35}` — Mushroom Wars 2 lanes between garrison buildings (replaces map `roads` for sends) |
| `ai` | `{"towers": 1, "scouts": 1, "invasionSize": 6, "escalateSeconds": 300, "climbWeight": 24, "exposureWeight": 12, "terrain": true, "workersPerBase": 14, "firstAttackArmy": 8, "armyGrowth": 4, "maxAttackArmy": 16}` — computer player knobs, every key optional (defaults shown): `towers` defensive structures at the chokepoint toward the enemy once the base was raided (0 = none); `scouts` units holding a watch post on high ground along the attack route; `invasionSize` orbit units gathered before a fleet transfers to another body (planets); `escalateSeconds` no enemy structure destroyed for this long (after 8 min) raises the stalemate level (bigger waves, a little more range in the unit mix, economy targets, alternate routes, at level 3 no retreat); `climbWeight` / `exposureWeight` route cost per level climbed / per level of higher ground overlooking a cell (10 = one cell); `terrain: false` turns the terrain analysis off (direct attack-moves). See "Computer player" |

## resources

```json
"resources": {
  "gold":   {"name": "Золото", "start": 500},
  "ore":    {"name": "Руда", "field": true, "regrow": 0.5, "cellMax": 100},              // Red Alert / Dune: harvested from map fields
  "metal":  {"kind": "flow", "start": 500, "storage": 1000},                               // Total Annihilation: income/expense per second, capped by storage
  "power":  {"kind": "capacity", "deficitProduction": 0.5, "deficitDisables": ["defense"]},// Red Alert power: provided vs consumed
  "spice":  {"capped": true, "storage": 1000},                                             // Dune silos: stock limited by storage
  "coins":  {"global": true, "start": 100},                                                // with "storage": "buildings": not a good, stays player-wide
  "ore2":   {"field": true, "convertsTo": {"credits": 4}}                                  // delivered ore is credited as 4 credits each
}
```
Kinds: `stock` (default: gathered/earned, spent), `flow` (per-second income from `income`, spent while
building in progressive mode; at 0 with negative income production slows by `deficitProduction`),
`capacity` (sum of `provides` minus `consumes`; a deficit slows production and disables types with
any tag in `deficitDisables`).

## Movement and bodies

`"move": {"speed": 2.8, "radius": 0.4, "mass": 0.64, "layer": "ground", "maxSlope": 1.6}`

- `maxSlope` (heightfield terrain only): the steepest cell this type can enter (rise per cell); default
  `terrain.maxSlope` of its layer. At most 15 different values per game.

- `radius` is the real body size (cells): units keep `r1 + r2` apart, weapon and ability ranges are measured
  edge to edge (`range` + both radii, structures by their footprint), and paths keep clearance from walls and
  buildings for bodies larger than half a cell (tight gaps cost more; nothing becomes unreachable).
- `mass` (default `4 * radius²`) decides who yields when bodies overlap. Units that are fighting, holding
  position or working (gathering, building, digging) are anchored (x8) and are barely pushed; moving units (x2)
  push idle ones (x1) aside. A 0.03-cell dead zone and a per-tick push cap remove jitter.
- With `movement.avoidance: "rvo"` moving units steer around each other with reciprocal velocity obstacles
  (nearest `neighbors`, deterministic order). Idle allies in the way are asked to yield: they step to a free side
  cell and walk back once the way is clear, so a unit can pass a gap of standing units; units blocked by anchored
  ones re-path around them.
- `movement.avoidance: "none"` disables ORCA and mobile body separation, for games whose Lua
  formation logic supplies positions. It does not disable terrain pathfinding or combat. Keep
  real positive body radii; do not emulate this mode with near-zero radii.
- Melee units (range < 2) attacking a target pick a free slot on a ring around it (slots by angle, claimed
  per target, ties by entity index) and path around allies already fighting instead of pushing into the front
  rank; ranged units stop and shoot. A group given an attack-move spreads into an arc whose flanks run ahead.
- **Flow fields** (`movement.flowField`, off unless a game or map opts in; docs/pathfinding.md): big groups and
  hordes share one integration field per goal area instead of one path search per unit.

  ```jsonc
  "movement": {"flowField": {"minGroup": 12,     // move / attack-move / patrol / right-click orders of >= 12 units (0 = never)
                             "minCells": 0,      // ... only for units at least this many cells from the goal (0 = all)
                             "waves": true,      // units released by map waves and lane waves march on fields
                             "spread": 0.4,      // goal area radius = 0.3 + spread * sqrt(units) (they arrive spread out)
                             "maxFields": 64, "budgetMB": 32}}   // cache: LRU of unreferenced fields beyond these
  ```
  A map may carry the same block (`"movement": {"flowField": {...}}` at the map's top level) to switch fields on for
  itself only (e.g. `templates/lastcolony/maps/horde_plain.json`, `templates/planets/maps/big_planet.json`).
  Fliers keep flying straight; units pushed off the field or stuck repeatedly fall back to their own A* path.
  Followers settle around the goal from the inside out (arrival contagion) and don't block each other.
- `movement.blockedGoals: "nearest"` (rules or map, default `"search"`): paths to a goal inside a structure or obstacle
  (attacking a building) end at the free cell around it nearest to the unit - much cheaper for hordes; different cells
  than the classic search, so it is opt-in (on in `templates/lastcolony/maps/horde_plain.json`).

## types — blocks

```json
"footman": {
  "name": "Пехотинец", "tags": ["infantry", "bio"],
  "health": {"max": 420, "armor": 2, "armorType": "heavy", "regen": 0},
  "move": {"speed": 2.8, "radius": 0.4, "layer": "ground"},          // layer: ground | air | naval | sand (sand: can't enter rock/ramps)
  "sight": 8,
  "weapons": [{"id": "sword", "range": 1.0, "minRange": 0, "damage": 12, "cooldown": 1.2,
               "targets": ["ground"], "projectileSpeed": 0, "splash": 0, "damageType": "normal"}],
  "cost": {"gold": 135, "time": 18, "supply": 1},
  "requires": ["barracks", "tech_id"],
  "xp": 20, "bounty": {"gold": 5}, "score": 1
}
```

| block | meaning |
|---|---|
| `structure` | `{"footprint": [w, h], "on": "geyser", "takesOverNode": true, "terrain": "rock"\|"creep"\|"any", "extendsBase": true}` — `on`: must be built exactly on an object of that type (refinery on a geyser, TA extractor on a metal spot); `takesOverNode` inherits its resource |
| `invulnerable` | can't be damaged (trees, mines, decorations) |
| `energy` | `{"max": 200, "regen": 0.5, "start": 50}` — mana for abilities |
| `abilities` | list, see "Abilities" |
| `hero` | `{"levels": [200, 500, 900], "perLevel": [{"stat": "maxHp", "add": 50}, {"stat": "damage", "add": 0.1}]}` — gains xp from kills nearby; unique per player |
| `unique` | at most one per player |
| `squad` | `{"members": 4, "reinforceCost": {"manpower": 25}, "reinforceTime": 4}` — Company of Heroes squads: hp pool split over members, damage scales with members alive |
| `supply` | supply provided (farms, houses, overlords) |
| `income` | `{"metal": 2, "energy": -5}` per second while complete (and not disabled) |
| `storage` | `{"metal": 500}` raises caps |
| `provides` / `consumes` | capacity resources: `{"power": 100}` |
| `produces` | types it trains; **structures listed here are built Command & Conquer style** (sidebar: produce, then place with a Place command) |
| `builds` | structures a worker can construct |
| `researches` | tech ids |
| `upgrades` | structure types it can turn into in place (levels L1 → L2) |
| `buildMode` | `walk` (default: builder builds; several builders add up), `warp` (Protoss: starts it and leaves), `morph` (Zerg: the builder becomes the structure) |
| `buildPower` | builder speed multiplier |
| `gather` | `{"gold": {"carry": 10, "time": 2}}` — what it gathers (nodes or fields); flow resources (TA reclaim) are credited directly |
| `resourceNode` | `{"resource": "gold", "amount": 12000, "ownerOnly": false}` — `amount` < 0 = infinite (farms); `ownerOnly`: only the owner can gather (refinery, farm) |
| `dropoff` | resources accepted for return trips: `["gold", "wood"]` |
| `charges` | `{"max": 3, "interval": 11}` — larva: parallel production, one charge per item |
| `creep` | radius of creep it spreads (structures with `"terrain": "creep"` need it) |
| `fieldSpawner` | `{"resource": "ore", "rate": 10, "radius": 3}` — grows a resource field around it (ore mine, spice bloom) |
| `deploysTo` | unit → structure (MCV → Construction Yard) |
| `wreck` | `{"metal": 100}` — leaves a type `"wreck"` (define it with a `resourceNode`) to reclaim |
| `sellable` | default true for structures |
| `garrison` | `{"max": 20, "unit": "mushroomling", "interval": 1.0, "capturable": true, "defense": 1.0, "decay": 1.0}` — Mushroom Wars: grows units inside, sends them along roads |
| `entersGarrison` | units that merge into/assault garrisons on arrival |
| `capture` | `{"time": 10, "radius": 3, "victoryPoint": false, "region": false}` — control point: captured by standing next to it; `victoryPoint` drains enemy tickets; `region` flips its region and the capturable structures in it (Z flags) |
| `neutral` | `{"leash": 10, "wander": false, "wanderRadius": 20}` — creeps (owner -1) return home beyond the leash; wanderers roam (Dune sandworm) |
| `waveSpawn` | `{"unit": "trooper", "count": 2}` — releases units on the `waveClock`; they attack-move to the enemy base |
| `worker` | AI/UI hint (default: has gather or builds) |
| `key` | losing all key objects loses the game in `keyUnits`/`score` modes (commander, HQ) |
| `countsForVictory` | override |
| `score` | points to the killer's team (score victory) |
| `view` | presentation only: shape or model, materials, clips, procedural animation (docs/models.md) |
| `sprite` | presentation only: draw the type from a sprite sheet (2D games, see below) |

Stats usable in modifiers: `maxHp`, `armor`, `damage` (multiplier), `range` (added), `speed`, `sight`,
`gatherRate` (multiplier; also dig/claim/work speed, alias `workRate`), `attackSpeed` (multiplier),
`productionSpeed` (multiplier on training/research/autoTrain speed of a producer).

More type blocks (dungeon management and territory, see the section below):

| block | meaning |
|---|---|
| `digs` | `{"rate": 2}` — worker digs cells its owner marked (hardness per second); idle diggers find jobs themselves |
| `claimer` | `{"time": 0.5}` — worker walks to unowned cells next to own territory and claims them (seconds per cell, x2 for enemy cells) |
| `claim` | `{"radius": 1.5, "rate": 2}` — the unit converts cells around it (cells per second): only cells touching own territory, never while hostile units stand on them (territory war front line) |
| `claimedByTerritory` | `true` — a neutral structure (portal) joins the player owning territory next to it |
| `capturable` | `true` — with `territory`: the structure flips to whoever owns the ground under its centre |
| `portal` | `{"interval": 20, "pool": ["goblin"]}` — recruits one attracted creature per interval (pool empty: every type with `attractedBy`), up to the supply capacity |
| `attractedBy` | `{"rooms": {"lair": 1, "library": 9}, "resources": {"gold": 500}, "weight": 1}` — when a portal may recruit this type (room cells owned, stock), chosen by weight |
| `needs` | creature needs and morale, see below |
| `autoTrain` | `{"unit": "soldier", "interval": 4}` — structure continuously produces units while the population cap allows (pays the unit's cost if any); they attack-move to the nearest front (closest non-own cell touching own territory, else the nearest enemy, or the rally point) and keep pushing it when idle |

### Abilities

```json
"abilities": [
  {"id": "storm", "name": "Буря", "target": "point", "range": 9, "cooldown": 12, "energy": 75, "level": 1, "autocast": true,
   "effects": [{"type": "damage", "amount": 80, "radius": 2, "damageType": "magic", "affects": "enemies"}]},
  {"id": "heal", "target": "unit", "effects": [{"type": "heal", "amount": 60}]},
  {"id": "roar", "target": "none", "effects": [{"type": "buff", "stat": "damage", "mul": 1.25, "duration": 15, "radius": 6, "affects": "allies"}]},
  {"id": "stun", "target": "unit", "effects": [{"type": "stun", "duration": 2}]},
  {"id": "wolves", "target": "none", "effects": [{"type": "spawn", "unit": "wolf", "count": 2, "duration": 60}]},
  {"id": "blink", "target": "point", "range": 8, "effects": [{"type": "blink"}]},
  {"id": "devotion", "aura": true, "radius": 7, "effects": [{"type": "buff", "stat": "armor", "add": 2, "affects": "allies"}]}
]
```
`target`: none | self | unit | point (and structure | group | player, see "Abilities and effects").
`affects`: enemies | allies | all. Autocast abilities are also what the AI uses. Delivery (projectiles,
areas, chains, channels), statuses, costs, charges, cast times and level tables: "Abilities and effects".

## techs

```json
"techs": {
  "iron_swords": {"name": "Железные мечи", "cost": {"gold": 100, "time": 30}, "requires": ["blacksmith"],
                  "effects": [{"tags": ["infantry"], "stat": "damage", "mul": 1.15}, {"type": "archer", "stat": "range", "add": 1}]}
}
```
An effect without `tags`/`type` applies to every type. Repeatable upgrades: `"levels": 5, "costGrowth": 0.5` — the
tech can be researched 5 times, each level re-applies its effects (multipliers compound) and costs
`cost * (1 + costGrowth * levelsDone)`; `researched` counts levels. Requirements can be types or techs (ages: a tech
required by the next tier's types).

## factions

```json
"factions": {
  "terran": {"name": "Терраны", "start": [{"type": "command_center", "offset": [0, 0]}, {"type": "scv", "offset": [3, 0], "count": 4}]}
}
```
Map players choose a faction and a `start` point; start objects spawn there.

## Maps

```json
{
  "name": "River Valley", "size": [64, 48],
  "players": [{"name": "Blue", "team": 1, "faction": "terran", "start": [8, 24], "resources": {"gold": 800}},
              {"name": "Zombies", "team": 9, "waves": true}],
  "terrain": {
    "rows":   ["....~~~~....", "..."],      // one char per cell: . ground ~ water # blocked , no-build = shallow / ramp R rock
    "levels": ["000011110000", "..."],      // cliff level per cell 0..9; units change level only over / ramps
    "heights": [0, 0, 16, ...],             // optional fine visual height per cell (1/16 units)
    "corners": [0, 0, 16, ...]              // optional heightfield: (w+1)*(h+1) corner heights, 1/16 units, row-major
    // or, for big maps: "cornersFile": "maps/<name>.r16"   raw int16 little-endian, (w+1)*(h+1) values
  },
  "fields": [{"resource": "ore", "rows": ["0000999000", "..."]}],   // density digits 1..9 of cellMax (or {"center": [x,z], "radius": 3})
  "regions": {"rows": ["AAAABBBB", "..."], "names": {"A": "Долина", "B": "Холмы"}},
  "entities": [{"type": "townhall", "owner": 1, "pos": [9, 24]}, {"type": "goldmine", "owner": 0, "pos": [6, 16], "amount": 8000},
               {"type": "ogre", "owner": -1, "pos": [32, 10]}],     // owner: 0 neutral, 1..N players, -1 hostile creeps
  "roads": [["base_a", "village_1"]],                                 // by entity id (Mushroom Wars)
  "roadsOnly": false,
  "areas": {"relic": [26, 4, 4, 4]},                                  // named rectangles [x, z, w, h] for triggers
  "waves": [{"time": 60, "player": 2, "at": [60, 24], "spread": 3, "spawn": [{"type": "zombie", "count": 10}],
             "every": 45, "growth": 1.3, "repeats": 10}],
  "victory": {"mode": "survive", "seconds": 900},                     // overrides rules.victory
  "triggers": []
}
```

## audio.json

Presentation only: nothing here reaches the simulation. A missing file or audio device just means
no sound. Malformed structure is an error (`audio: sound 'x': unknown bus 'drums'`); a missing or
undecodable sound file, an unknown key, type, weapon or sound name is a warning and only that sound
stays silent.

```json
{
  "volume": {"master": 1, "sfx": 0.9, "ui": 0.7, "voice": 1, "music": 0.6, "ambient": 0.7},
  "spatial": {"minDistance": 10, "maxDistance": 55, "airAbsorption": 1500, "speedOfSound": 150,
              "reverb": {"size": 0.6, "damping": 0.45, "wet": 0.4, "near": 0.04, "far": 0.65}},
  "groups": {"melee": {"max": 6}, "ui": {"max": 3, "bus": "ui", "steal": "oldest"}},
  "sounds": {
    "swing": {"files": ["sfx/swing1.ogg", "sfx/swing2.ogg"], "pitch": [0.9, 1.1], "maxInstances": 4, "cooldown": 0.05, "group": "melee"},
    "alarm": {"file": "voice/under_attack.ogg", "bus": "voice", "priority": 10},
    "blip":  {"synth": {"wave": "square", "freq": [880, 440], "duration": 0.08}, "bus": "ui"},
    "boom":  {"file": "sfx/boom.ogg", "minDistance": 14, "maxDistance": 80, "far": {"sound": "boom_far", "from": 0.25}},
    "boom_far": {"file": "sfx/boom_far.ogg", "maxDistance": 120, "air": 0.5}
  },
  "music": {
    "menu":  "music/menu.ogg",
    "match": {"files": ["music/a.ogg", "music/b.ogg"], "shuffle": true, "loop": true, "volume": 0.8},
    "battle": ["music/fight.ogg"]
  },
  "events":    {"died": "death", "underAttack": "alarm", "notEnough": "need_more", "notEnough.gold": "need_gold"},
  "weapons":   {"sword": {"attack": "swing", "hit": "clang"}, "bow": {"attack": "bow", "hit": "arrow_hit"}},
  "abilities": {"storm": "thunder"},
  "types":     {"footman": {"select": "footman_what", "move": "footman_yes", "died": "death_human",
                            "weapons": {"sword": {"hit": "clang_heavy"}}, "abilities": {"roar": "roar"}}}
}
```

`volume`: mix level per bus, 0..4 (default 1); the player's own volume settings multiply on top
(client data model: `volume` master, `music`, `sfx` = every bus but music, percent; `musicOn` / `sfxOn` 1 / 0 switch
a bus off without changing its volume; saved in the user folder's audio.cfg).

`"scripted": true`: the game's scripts own the music and the UI sounds (the `sound` table, docs/scripting.md § Sound):
the client never plays the `menu` / `match` / `battle` / `victory` / `defeat` playlists by itself, and starting or
leaving a match stops only voices on the `sfx` bus.

### spatial — 3D sound and distance

Positional sounds are placed in 3D around the listener (the RTS client puts the ear on the view
ray above the camera's focus; units on cliffs and flyers are higher). Distances are world units
(map cells). Zooming out raises the ear, so the battle sounds farther away; the audible area
grows with the square root of the zoom.

| key | meaning |
|---|---|
| `model` | distance curve: `inverse` (default, natural), `linear`, `exponential` |
| `minDistance`, `maxDistance` | full volume up to min, silent at max (12, 60); the last 20 % of the range always fades out |
| `rolloff` | steepness of the curve (1) |
| `airAbsorption` | Hz of the low-pass at max distance: far sounds lose their highs (2500; `false` = off) |
| `reverb` | `false`, or `{"size": 0.5, "damping": 0.5, "wet": 0.35, "near": 0.05, "far": 0.6}` — `near` / `far` = reverb send at min / max distance: far sounds get roomy and lose their attack |
| `speedOfSound` | world units per second; distant sounds arrive late (0 = off; capped at 3 s) |
| `rear` | 0..1: sources behind the listener get duller and a bit quieter (0) |

The distance keys (`model`, `minDistance`, `maxDistance`, `rolloff`) are defaults for every sound;
a sound can override them and add `air` / `reverb` multipliers (below).

### sounds

| key | meaning |
|---|---|
| `file` / `files` / `synth` | exactly one. Files: WAV, OGG Vorbis, MP3, FLAC, paths relative to the game folder; `files` = variations, a random one per play, never the same twice in a row |
| `bus` | `sfx` (default), `ambient`, `voice`, `ui`, `music` |
| `spatial` | attenuated and panned around the camera when the event has a position; default true for `sfx` / `ambient`, false otherwise (announcements are heard anywhere) |
| `volume` | 0..4 (1) |
| `pitch` | number or `[min, max]` random per play (1) |
| `maxInstances` | at most this many of this sound at once (4; 0 = no limit); `steal` decides who makes room |
| `steal` | for `maxInstances`: `farthest` (default), `oldest`, `quietest`, `none` — see "groups" |
| `group` | a group name or an array of up to 4: limits shared with other sounds (see "groups") |
| `cooldown` | seconds between two starts (0) — 40 archers firing together make a few sounds, not 40 |
| `priority` | -100..100 (0): when all voices are busy, the lowest priority (oldest first) is stopped; a new sound below everything playing is dropped |
| `loop` | loops until stopped (false) |
| `model`, `minDistance`, `maxDistance`, `rolloff` | override the `spatial` defaults: small sounds (footsteps, swords) fade early, explosions carry far |
| `air` | multiplier of the air absorption, 0..4 (1; 0 = keeps its highs at any distance) |
| `reverb` | multiplier of the distance reverb send, 0..4 (1; 0 = always dry) |
| `duckMusic` | 0..1: music is lowered by this fraction while the sound plays (0.4 on the `voice` bus, else 0) |
| `sync` | `now` (default), `beat`, `bar`: start on the music's grid (stingers) |
| `compress`, `quality` | build-time codec for this sound's files (see "Compression at build time") |
| `far` | a distant variant: `"boom_far"` or `{"sound": "boom_far", "from": 0.3}` — both play together and crossfade from `from` (fraction of this sound's distance range) to max distance; the far sound keeps its own distances, so it can carry farther (a low rumble instead of a crack) |

`synth` — a sound made from parameters instead of a file (prototypes, playables); an object or an
array of layers that are mixed:

| key | meaning |
|---|---|
| `wave` | `sine` (default), `square`, `saw`, `triangle`, `noise` |
| `freq` | Hz, or `[start, end]` for an exponential sweep (440); for `noise` it is the grain rate |
| `duration` | seconds, 0.001..10 (0.2) |
| `attack`, `release` | seconds of fade-in / fade-out (0.005, min(0.1, duration)) |
| `volume` | 0..4 (1) |
| `duty` | square pulse width 0.02..0.98 (0.5) |
| `vibrato` | `[rate Hz, depth]`, depth as a fraction of the frequency |
| `lowpass` | cutoff Hz (off) |
| `crush` | keep only N bits, 1..15 (off) |
| `delay` | seconds before this layer starts (0) |

### groups

Limits shared by several sounds, so a big battle stays readable: six swords hitting at once
sound like a fight, sixty sound like noise, and they hide the sounds that matter.

```json
"groups": {
  "melee":      {"max": 6},
  "missiles":   {"max": 6, "cooldown": 0.02},
  "explosions": {"max": 4},
  "deaths":     {"max": 4, "steal": "quietest"},
  "ambient":    {"max": 5, "bus": "ambient"}
}
```

| key | meaning |
|---|---|
| `max` | sounds of the group at once (0 = no limit, only `cooldown`) |
| `cooldown` | seconds between two starts of any sound of the group (0) |
| `steal` | who makes room when the group is full (below; default `farthest`) |
| `bus` | every sound on that bus belongs to the group: a limit per bus |

Sounds join with `"group": "melee"` (or `["melee", "loud"]`: every group must have room).
Variations (`files`) are one sound; a sound with a `far` variant counts once, and its far half
stops with it.

| `steal` | when full |
|---|---|
| `farthest` | the sound farthest from the listener stops; a new sound farther than all playing ones is not started — fighting off-screen never cuts off the fight on screen. Non-positional sounds: the oldest |
| `oldest` | the sound started first stops |
| `quietest` | the sound that is quietest now stops (content loudness measured at load, volume, bus, distance); a new sound quieter than all of them is not started |
| `none` | nothing stops: the new sound is not started |

A playing sound with a higher `priority` than the new one is never stopped for it; when the
whole group is more important, the new sound is not started. Stopping fades in a few ms (no click).

### music

Music streams from the files (OGG Vorbis recommended); changes crossfade. Playlists the client
plays by name, all optional: `menu`, `match`, `battle` (replaces `match` while heavy fighting
happens near the camera, back after ~15 s of calm), `victory`, `defeat`. A playlist named
`match.<map>` (map file name without extension, e.g. `match.valley`) wins over `match` on that
map; the same for `battle`, `victory`, `defeat`.

```json
"music": {
  "menu":  "music/menu.ogg",
  "match": {"files": ["music/a.ogg", {"file": "music/b.ogg", "loopStart": 12.0}], "shuffle": true,
            "bpm": 96, "beatsPerBar": 4, "transition": "bar"},
  "match.valley": {"layers": [{"file": "music/valley_base.ogg"},
                              {"file": "music/valley_drums.ogg", "intensity": 0.3},
                              {"file": "music/valley_brass.ogg", "intensity": 0.7}],
                   "loopStart": 4.0, "loopEnd": 68.0, "bpm": 112}
}
```

A playlist is a file name, an array of entries, or an object:

| key | meaning |
|---|---|
| `files` | entries played in order: a file name or `{"file", "loopStart", "loopEnd"}` (seconds). With `loopStart` the track plays its intro once and then loops from `loopStart` to `loopEnd` (default: the end) seamlessly until the music changes |
| `layers` | adaptive music instead of `files`: synchronized stems of equal length, looping together (`loopStart` / `loopEnd` on the playlist). A layer with `"intensity": x` fades in as the music intensity passes x; in a match the intensity follows the fighting near the camera, so a layered `match` builds up instead of switching to `battle` |
| `shuffle`, `loop` | shuffle the entries (no immediate repeats) / start over after the last one (false, true) |
| `volume` | 0..4 (1) |
| `bpm`, `beatsPerBar`, `offset` | beat grid (`offset`: seconds before the first beat); used by `transition` and by synced stingers |
| `transition` | switching away from this playlist waits for the next `beat` or `bar` (default `bar` when `bpm` is set, else `now`) |

Stingers are sounds on the `music` bus: `"sync": "beat"` or `"bar"` starts them on the playing
music's grid. Any sound can duck the music while it plays: `"duckMusic": 0.5` lowers it by half
(default 0.4 for the `voice` bus, so announcements are always heard; 0 otherwise).

### Compression at build time

`rtsbuild` re-encodes the referenced sound and music files for each target before packing; the
project folder is never changed. Profiles: `desktop` (macOS, Windows, Linux), `mobile` (iOS,
Android), `web`. `--audio mobile` forces a profile, `--audio off` ships the files as they are;
`rts_audiopack --project <game> --profile mobile` shows what a profile would do.

```json
"build": {
  "desktop": {"sounds": "keep", "music": "vorbis", "musicQuality": 0.6},
  "mobile":  {"sounds": "adpcm", "music": "vorbis", "musicQuality": 0.3, "maxRate": 32000},
  "web":     {"musicQuality": 0.25}
}
```

| key | meaning |
|---|---|
| `sounds`, `music` | codec: `keep` (file as is), `pcm` (16-bit WAV), `adpcm` (IMA ADPCM WAV: 4:1, nearly free to decode — short effects), `vorbis` (OGG: music, long sounds) |
| `soundQuality`, `musicQuality` | Vorbis quality -0.1..1 (0.5 / 0.4; mobile 0.4 / 0.3, web 0.4 / 0.25) |
| `maxRate` | resample anything above this rate (0 = never; mobile and web 32000) |
| `monoSounds` | positional sounds become mono: the mixer pans them anyway (true) |
| `longSound` | seconds: longer sounds (ambient loops, stingers) use the music codec (8) |
| `reencodeLossy` | also re-encode files that are already OGG/MP3 (false: lossy to lossy only loses quality) |

Defaults without a `build` section: `desktop` keeps everything; `mobile` and `web` use ADPCM for
sounds and Vorbis for music at 32 kHz. Sounds on the `music` bus count as music. A sound or a
playlist can override with `"compress"` and `"quality"`. Re-encoded files get the extension of
their codec and audio.json in the build points at them; a result that isn't smaller keeps the
original. Loop points stay exact (Vorbis is sample-accurate; ADPCM pads a loop with its own start).

### events, types, weapons, abilities

Which sound plays on which game event ("cue"). Lookup for an object: its entry in `types`, then its
weapon / ability by id in `weapons` / `abilities`, then `events`.

| cue | when | heard by |
|---|---|---|
| `attack` | a weapon fires (`weapons.<id>.attack` first) | everyone who sees the spot |
| `hit` | damage lands (`weapons.<id>.hit` of the shooter's type first) | everyone who sees the spot |
| `miss` | a shot misses (uphill) | everyone who sees the spot |
| `died` | an object dies (`types.<id>.died`) | everyone who sees the spot |
| `spawned` | an object appears | everyone who sees the spot |
| `ability` | an ability is cast (`abilities.<id>` first) | everyone who sees the spot |
| `captured` | the player captures a building / point; for others: someone captured something in view | owner |
| `lost` | the player's building / point was captured | previous owner |
| `trainStarted`, `ready` | production started / a unit is ready | owner |
| `buildPlaced`, `buildDone` | construction placed / finished | owner |
| `readyToPlace`, `sold`, `upgraded`, `researched`, `levelUp`, `regionClaimed`, `lowPower`, `gathered` | as named | owner |
| `notEnough`, `notEnough.<resource>` | can't afford (the resource-specific one first) | owner |
| `notEnoughSupply`, `noRoom` | supply cap / no place for an automatic build (fallbacks: `notEnough`, `error`) | owner |
| `underAttack`, `baseUnderAttack` | an enemy hits the player's unit / structure where the camera isn't looking; at most every 12 s | owner |
| `select` | the player selects an own unit (`types.<id>.select`) | player |
| `move`, `attackOrder`, `buildOrder` | the player gives an order (fallback: `move`) | player |
| `victory`, `defeat`, `playerDefeated` | match end / another player is out | player |
| `wave` | a scripted wave starts | everyone |
| `message` | a trigger message | its addressees (everyone for a message to all) |
| `click`, `error` | interface | player |

"Everyone who sees the spot" respects fog of war; a spectator hears all world sounds and no
player-only cues.

## Dungeon management and territory

For Lua-owned front lines, see [Territory brushes and scripted formations](scripting.md#territory-brushes-and-scripted-formations).
The optional visual block `terrain.territory` also supports `smooth: true` (default false),
`transition` (0..2 seconds, default 0.2) and `lift` (0..2 world units, default 0.045).
On flat maps smooth mode filters ownership with a compact binomial kernel, reconstructs it bilinearly, applies a soft contour threshold,
and interpolates changed cells over `transition` seconds. It uses the existing RHI mesh pipeline
on both Metal and GL; material quality selects 4 subdivisions per cell (medium/high) or 2 (low).
Fog memory is respected. Legacy square territory/room-floor rendering remains the default;
smooth mode is for territory surfaces and does not draw room-floor tints. Planet visuals retain
their existing renderer. Counts, capture tests and victory still use exact simulation ownership.
The ground-overlay Metal shader uses the shared `LightU` lighting block (matching GLSL's U2
layout); older builds referenced the obsolete `U2` MSL type and silently lost the entire layer.
Shader/pipeline failures now report the backend error to stderr.

```json
"diggable": {"D": {"hardness": 3}, "G": {"hardness": 6, "yields": {"gold": 250}}, "J": {"hardness": 8, "yields": {"gold": 40}, "infinite": true}},
"territory": {"claimBy": "both", "startFromRegions": false, "startRadius": 3, "buildOnlyOwned": true},
"rooms": {
  "lair":     {"name": "Логово", "cost": {"gold": 10}, "supply": 1},
  "hatchery": {"cost": {"gold": 12}, "income": {"food": 0.05}},
  "treasury": {"cost": {"gold": 15}, "storage": {"gold": 500}},
  "library":  {"cost": {"gold": 20}, "income": {"research": 0.02}, "work": {"yields": {"research": 1}}},
  "training": {"cost": {"gold": 20}, "work": {"xp": 3, "cost": {"gold": 0.5}}}
},
"hand": {"max": 8, "ownTerritoryOnly": true, "slapDamage": 5, "slapDuration": 10, "slapSpeed": 1.5, "slapWork": 1.5},
"possession": {"cost": {"mana": 100}, "drain": {"mana": 2}}
```

- **Diggable terrain**: map characters listed in `diggable` (one character, not `. ~ # , = / R` or a digit) are
  solid cells. Players mark cells with the dig command; idle `digs` workers dig marked cells next to ground they
  can reach; the cell becomes ground (paths update) and `yields` is credited (`infinite`: the seam stays).
- **Territory** (per-cell owner layer, `MapGrid::territory`; `GameState::territoryCells[slot]` / `territoryTotal`
  for the HUD share): starts from map `"territory": {"rows": ["..11..", ...]}` (digits = player slots), from owned
  regions (`startFromRegions`) and `startRadius` cells around starting structures and start points. Claimed by
  `claimer` workers and/or units with `claim` (`claimBy`: `workers`, `units`, `both`). `buildOnlyOwned`: every
  footprint cell must be own territory. Losing a cell removes a room painted on it.
- **Rooms** are painted on own territory (paint command with a rect); `cost` is per cell. Effects scale with the
  player's total cells of the type: `supply` (creature capacity), `income`, `storage`, `provides` per cell; `work`
  is earned per creature working inside (`yields` per second, `xp` per second for types with `hero` levels, `cost`
  per second). Painting over another room replaces it; erasing refunds `sellRefund`.
- **Creature needs** (`needs` on a type):
  ```json
  "needs": {"hunger": {"interval": 60, "room": "hatchery", "time": 4, "cost": {"food": 1}},
            "sleep": {"interval": 90, "room": "lair", "time": 8},
            "pay": {"interval": 120, "amount": {"gold": 50}},
            "works": ["library", "training"], "workTime": 10,
            "happiness": {"start": 1, "unmetPerSecond": 0.01, "recovery": 0.005, "slap": 0.1, "unpaid": 0.3, "leaveBelow": 0.2, "leaveAfter": 30}}
  ```
  A need becomes active after `interval`; the idle creature walks to the nearest own room of that type and stays
  `time` seconds (paying `cost`; sleeping heals). Payday deducts `amount`; unpaid wages, slaps and unmet needs
  lower happiness; below `leaveBelow` for `leaveAfter` seconds the creature walks out through an own portal.
  Idle creatures work in `works` rooms (the AI may take them from work to fight).
- **Hand**: pick up own units (`max` in the hand, off the map: no orders, no combat), drop them on a visible own
  territory cell; slap: `slapDamage` (never kills), speed/work buff for `slapDuration`, happiness down.
- **Possession**: one unit per player is steered directly (direction vector per tick, fire button); the AI
  ignores it; `cost` once, `drain` per second (released when unaffordable).

## Settlers economy (Knights and Merchants)

```json
"storage": "buildings",
"roadNetwork": {"cost": {"stone": 1}, "speed": 1.5},
"types": {
  "storehouse": {"structure": {"footprint": [3, 3]}, "storehouse": {"capacity": 2000}},
  "woodcutter": {"structure": {"footprint": [2, 2]}, "recipe": {"out": {"wood": 1}, "time": 10, "from": "wood", "radius": 8}, "cost": {"planks": 3, "stone": 2}},
  "sawmill":    {"structure": {"footprint": [2, 2]}, "recipe": {"in": {"wood": 1}, "out": {"planks": 2}, "time": 8, "buffer": 2}},
  "farm":       {"structure": {"footprint": [3, 3]}, "recipe": {"out": {"grain": 1}, "time": 12}},
  "serf":       {"move": {"speed": 3}, "carrier": {"capacity": 1}},
  "soldier":    {"trainFrom": "recruit", "cost": {"sword": 1, "armor": 1, "time": 6},
                 "needs": {"hunger": {"interval": 120, "at": "inn", "time": 3, "cost": {"food": 1}, "starve": 1}}}
}
```

- With `"storage": "buildings"` every `stock` resource that is not `global` is a **good**: it lives in building
  inventories. The player's stock of a good is the sum of its **storehouses** (`storehouse.capacity` = total
  goods); paying takes goods out of storehouses, income and bounties are put into them. Starting goods (resource
  `start`, map player `resources`) go into the first storehouses; map entities can carry `"inventory": {"wood": 5}`.
- **Recipes**: a workplace consumes `in` from its own inventory and produces `out` into it every `time` seconds
  (`productionSpeed` stat and power apply); it keeps `buffer` cycles of inputs and stops when `buffer` cycles of
  output are waiting. Raw producers have no `in`; `from` + `radius` deplete the nearest resource node or field
  cell of that resource (wood from trees, stone from a quarry, fish from water fields).
- **Carriers** (`carrier.capacity` per trip) haul on request, deterministically (every 0.5 s, buildings in
  entity order): construction sites and workplace inputs first (source: workplace output, else nearest
  storehouse), then workplace outputs to the nearest storehouse with room. With `roadNetwork.required` the
  source and destination must touch the same road network.
- **Construction**: goods in a structure's `cost` are not paid at once; carriers deliver them to the site and
  building progress can't exceed the delivered share (builders still build). Other resources are paid up front.
- **Roads**: map char `+`, the road command (rect), or the connect command (the sim paves the shortest path from
  a structure to the road network of an own storehouse). Movement on road cells is `speed` times faster.
- **Recruits**: `trainFrom` consumes an idle own unit of that type within 15 cells of the producer.
- **Food**: needs with `"at": "<structure type>"` are satisfied at the nearest own structure of that type (cost
  taken from the stock); `starve` hp per second is lost while the need is active.

## Lanes (Mushroom Wars 2)

`"lanes": {"left": 4, "right": 2, "spacing": 0.35}`: for every pair of garrison buildings the sim finds an A* path
around obstacles and other buildings, smooths it into a fixed-point Catmull-Rom spline (about two samples per
cell) and adds `left` + `right` parallel lanes `spacing` cells apart (pulled back towards the main lane where they
would hit an obstacle). Sent units are spread over the lanes round-robin and follow their lane exactly. Lanes are
rebuilt when garrison buildings or obstacles change (`GameState::lanes`, `lanesDirty`, event `kEvLanesChanged`).

## Terrain overlays (visual `terrain` block)

Presentation only (`modules/rts/view/RtsGroundFx.*`): the view reads the territory, dig, room and road layers and
the lanes and never writes them. All keys are optional; put them under `terrain` in rules.json or game.json (game.json
wins per block; sim keys like `model` live in the same block). Each block may be `false` to switch the overlay off.
Colours are `[r, g, b]` (0..1) or `"#rrggbb"`. `texture` paths go through `TextureCache::resolve` (atlases work);
the texture is mapped in world space every `textureScale` units and mixed by `textureStrength` (0..1).

```json
"terrain": {
  "territory": {"fill": 0.28, "border": 0.26, "glow": 0.85, "pulse": true, "colors": [[0.2,0.45,0.95], "#e83a33"],
                "rooms": {"lair": [0.62,0.32,0.22]}, "roomFill": 0.5, "texture": "terrain/floor.png", "textureScale": 2},
  "dig":       {"height": 1.15, "mark": [1,0.8,0.22], "progress": true,
                "kinds": {"D": {"rock": [0.4,0.35,0.3]}, "G": {"style": "vein", "vein": "#f9c238"}, "J": {"style": "gem", "vein": [0.35,0.85,0.95], "glow": 0.55}}},
  "lanes":     {"color": [0.74,0.63,0.44], "edge": [0.5,0.4,0.27], "alpha": 0.75, "width": 0, "sideLanes": false, "all": false},
  "roads":     {"color": [0.72,0.63,0.48], "edge": [0.4,0.33,0.24], "width": 0.7, "alpha": 0.96, "cobbles": true, "texture": ""}
}
```

| Block | What is drawn | Keys |
|---|---|---|
| `territory` | owner colour on owned cells, a glowing (pulsing on high quality) border along edges between owners, painted rooms as a floor tint | `fill` alpha, `border` width (cells), `glow` emissive, `pulse`, `colors` per player slot from 1 (default: player colours), `rooms` tint per room id, `roomFill` alpha, `texture*` |
| `dig` | diggable cells as raised rock blocks with walls (the terrain under them stays flat and shows when dug); `style` per diggable character: `plain`, `vein` (gold-tinted top, nuggets, streaks on walls), `gem` (glowing crystals). Default style: no `yields` = plain, `yields` = vein, `infinite` = gem. The local player's dig marks (framed highlight) and digging progress (cracks + bar) | `height` 0.2..1.25, `mark` colour, `progress`, `kinds.<char>`: `rock`, `vein`, `style`, `glow` |
| `lanes` | lanes (`lanes` rules) as one soft path ribbon per pair of neighbouring buildings (a pair is skipped when a third building lies between them), map `roads` between buildings as ribbons | `color`, `edge`, `alpha`, `width` (0: covers every lane of the pair), `sideLanes` thin tracks per lane, `all` draw every pair |
| `roads` | road cells (map `+`, `roadNetwork` building) as road surfaces with edges, joins, crossings, rounded corners and dead ends; cobbles on high quality | `color`, `edge`, `width` 0.2..1, `alpha`, `cobbles`, `texture*` |

What the viewer sees follows fog of war: territory, rooms, rock and roads are updated only where the cell is visible
(remembered elsewhere). Weak GPUs (`MaterialQuality::Low`; testing: `RTS_GROUNDFX=low`) get no border pulse, no
vein/gem geometry (a tint instead), no rock bevels, no road edges, cobbles or lane tracks. 2D tile maps are not
overlaid.

## Player abilities

```json
"playerAbilities": [
  {"id": "nuke", "name": "Ядерный удар", "cost": {"money": 500}, "cooldown": 60, "target": "point",
   "effects": [{"type": "damage", "amount": 200, "radius": 3}]},
  {"id": "drone", "cost": {}, "cooldown": 5, "charges": {"max": 2, "rearmCost": {"money": 100}, "rearmTime": 20},
   "effects": [{"type": "damage", "amount": 60, "radius": 1.5}, {"type": "stun", "duration": 2, "radius": 1.5}]}
]
```
Not tied to a unit. Effects are the ability effects (any effect except `blink`; see "Abilities and effects").
Charges rearm one at a time after `rearmTime`, paying `rearmCost`. The AI fires them at enemy concentrations.

## Abilities and effects

Everything a skill does is a list of **effects** (a *payload*). Effects can carry their own payload
(`"effects": [...]`): a projectile delivers it on impact, an area applies it when it triggers, a chain
applies it on every jump, a status ticks it, a weapon applies it on hit. Skills are compositions of
these primitives; nothing is coded per skill. All keys below are optional; a game that uses none of
them runs exactly as before (bit-identical replays).

### Abilities (unit) and player abilities

```json
{"id": "barrage", "name": "Ракетный залп", "target": "point", "range": 10, "cooldown": 8, "energy": 40,
 "cost": {"gold": 25}, "initialCooldown": 3, "castTime": 0.5, "backswing": 0.3, "charges": 2,
 "requires": ["rocketry"], "level": 1, "autocast": true, "smart": "densestEnemy",
 "delivery": {"type": "projectile", "speed": 10, "arc": true, "arcHeight": 3, "scatter": 1.2},
 "effects": [{"type": "damage", "amount": [20, 30], "radius": 1.5, "falloff": 0.5}],
 "levels": [{"cooldown": 7, "effects": [{"amount": [30, 40]}]}, {"cooldown": 6, "effects": [{"amount": [40, 55]}]}]}
```

| key | meaning |
|---|---|
| `target` | `none`, `self`, `unit`, `point`, `structure` (a structure, e.g. a garrison), `group` (units sent together, on a lane), `player` |
| `cost` | resources (besides `energy`); player abilities use `cost` only |
| `cooldown`, `initialCooldown` | seconds; the `cooldownRate` stat speeds cooldowns up |
| `charges` | unit abilities: N charges, one regenerates per `cooldown` (player abilities: `{"max", "rearmCost", "rearmTime"}`) |
| `castTime`, `backswing` | windup before the effect (event `kEvCastStart`; stun / silence / a new order cancel it) and the time the caster stays busy after; player abilities: `castTime` = activation delay |
| `requires` | types / techs that must exist (abilities granted by a tech tree) |
| `level` | hero level needed; `levels`: a table for levels 2, 3, ... — each entry overrides keys of the ability (effects merge by index). Unit abilities use the hero level, player abilities the loadout level |
| `smart` | target rule for autocast / auto skills / the AI: `auto`, `lowestHpAlly`, `densestEnemy`, `strongestEnemyStructure`, `weakestOwnStructure`, `ownStructureUnderAttack`, `largestEnemyGroup`, `self`, `enemyPlayer`, `debuffedOwn` |
| `delivery` | how the effects get there: `instant` (default), `projectile`, `area` (delayed / persistent), `chain`, `channel`, `line`, `cone` (see below) |
| `levels`, `aura`, `radius` | as before (`aura`: passive buff around the owner) |

Player abilities also take `passive: true` + `status` (always-on player status, e.g. income
bonuses), `autoEvery` (seconds: cast by itself on its smart target — map / timer skills), and
maps give each player a **loadout**: `"players": [{"loadout": ["freeze", {"id": "nuke", "level": 3}]}]`
(without a loadout every player ability is available; `rules.loadoutSlots` caps the count).
Triggers can cast them: `{"type": "castAbility", "ability": "storm", "at": [20, 8], "free": true}`.

### Delivery

| `delivery.type` | keys | |
|---|---|---|
| `projectile` | `speed`, `homing`, `arc` + `arcHeight` (ballistic), `collide` (hits the first enemy on its way), `scatter` | the payload applies at impact (the hit unit is the target); reuses the `Projectile` entity (`effList` / `effIndex` tell the view which ability) |
| `area` | `delay`, `lifetime`, `interval`, `trigger` (`once`, `periodic`, `contact` + `maxTriggers`), `motion` (`static`, `toward`, `lane`, `wander`, `follow`) + `speed`, `sight` (reveal), `teleportTo` [dx, dz] (portal), `deathSpawn` (soul trap) | an `Area` entity (Transform + Area) — artillery markers, ground fields, mines, moving hazards, portals |
| `chain` | `jumps`, `jumpRadius`, `jumpFalloff` | jumps to the nearest unhit target that passes the filter; amounts scale by `jumpFalloff` per jump |
| `channel` | `duration`, `interval` | repeats while the caster stays still; stun / silence / moving cancel it |
| `line`, `cone` | `length`, `width` / `angle` | shapes the effects that have no shape of their own |

The same keys work inside effects of type `projectile`, `area` and `chain`, which is how skills nest
(a projectile that leaves a burning area, an area that drops projectiles every second, ...).

### Effects

Common keys: `amount` (number or `[min, max]` rolled with the sim RNG), `percent`, `radius`, `duration`,
`chance`, `damageType`, `falloff` (splash: damage at the edge = 1 - falloff), and the **target filter**:

| filter key | meaning |
|---|---|
| `affects` | `enemies` (default for harmful), `allies` (default for helpful), `own`, `self`, `all`, `any` (+ neutral) |
| `shape` | `target`, `circle` (default with a `radius`), `line`, `cone`, `ring` (+ `ring` width), `map`, `group` |
| `layers` | `["ground", "air", "naval"]` |
| `kind` | `unit`, `structure`, `any`; `garrisons: true` (only garrison structures); `inTransit: true` (only units walking to a structure) |
| `tags`, `ofType`, `level` | unit tags, one type, structure level range `[min, max]` (types have `"level": n`) |
| `sort`, `maxTargets`, `ownFirst` | `nearest`, `farthest`, `lowestHp`, `highestHp`, `levelLow`, `levelHigh`, `garrisonLow`, `garrisonHigh`, `random`; take the first N |
| `area` | only inside a named map area |

| `type` | keys | what it does |
|---|---|---|
| `damage`, `heal`, `stun`, `buff`, `spawn`, `blink` | as before; `spawn` also `limit` (alive per caster), `owner` (`caster`, `hostile`, `neutral`) | |
| `status` | `status` (id or inline object), `duration` | applies a status (below) |
| `dispel` | `dispel` (status tags, empty = all), `from` (`enemies` = cleanse, `allies` = purge, `any`) | removes statuses (and reverts temporary captures / transforms) |
| `knockback` | `amount` (negative = pull), `fromCaster` | pushes units away from the point (lane walkers are thrown back on their lane) |
| `teleport` | `mode` (`targets` / `caster`) | moves units to the point (lane walkers continue from the nearest lane point) |
| `resource` | `resource`, `amount` (+ give / − take), `percent` (of the stock), `transfer` | gain, drain, steal (players chosen by the filter / the target's owner) |
| `energyBurn` | `amount`, `percent` (damage per energy burned) | |
| `reveal` | `radius`, `duration` | vision for the caster's side |
| `kill` | `percent` | kills (a share of) the targets |
| `area`, `projectile`, `chain`, `cast` | delivery keys + `effects` | nest payloads (`cast` just applies its effects, e.g. with a `chance`) |
| `garrisonKill`, `garrisonPanic` | `amount`, `percent` | units in the garrison die / flee |
| `garrisonAdd` | `amount`, `percent`, `ofLost` | reinforcements, resurrection (a share of the units lost) |
| `garrisonConvert` | `percent` | defectors walk to the caster's nearest structure |
| `capture` | `duration`, `keepChance` | takes the structure; with a duration it reverts unless recaptured |
| `swap` | | swaps owners and garrisons with the caster's nearest structure (or the nearest enemy one when cast on an own structure) |
| `transform` | `to`, `duration`, `keepChance` | becomes another type for a while (cast tower) |
| `level` | `delta` (+ up / − down the `upgrades` chain), `duration` | |
| `equalize` | | averages the garrisons of the target owner's structures |
| `link`, `redirect` | `duration` | linked structures share units; production goes to the caster's nearest other structure |
| `sendBack` | `mode` (`home`, `reverse`, `throwBack` + `amount` cells) | groups in transit go back / are thrown back |
| `clone` | `percent`, `fake` | copies of units in transit (illusions die on any hit and do nothing on arrival) |
| `formation` | | a group closes rows onto its main lane |
| `convert` | `percent` | units change sides (hypnosis, betrayal) |
| `playerStatus` | `status`, `duration` | a status on players (silence, freeze regen, wind, alerts) |
| `equalizeResource` | `resource` | averages a resource between the chosen players |
| `sacrifice` | `percent`, `gain` | kills own units / garrison for resources per unit |
| `stealSkill` | `duration`, `transfer` | takes a random skill the enemy has and you don't |
| `cooldown` | `amount` | seconds added to (or taken from) the players' skill cooldowns |
| `addCharges` | `amount`, `limit` (cap, default the type's `charges.max`) | a larva structure gets `amount` charges, beyond its natural cap up to `limit` (inject larvae: a status with this in `onExpire`) |
| `teleportGroup` | `radius`, `origin` (`point` / `caster`), `destination` (`point2` / `caster` / `point`), `killTags`, `duration` + filter | units around the origin move to the destination keeping their formation; `killTags` units die instead (Chronosphere infantry); with a `duration` they come back (RA1). Chronosphere: player ability with `"target": "pointPair"`; Mass Teleport: unit ability, `origin: caster`; Strategic Recall: `origin: point`, `destination: caster` |

### Statuses

```json
"statuses": {
  "poison": {"name": "Яд", "tags": ["debuff", "magic"], "tick": {"damage": 4, "interval": 1}, "stacking": "stack", "maxStacks": 5},
  "frost": {"tags": ["debuff", "magic"], "mods": [{"stat": "speed", "mul": 0.6}, {"stat": "attackSpeed", "mul": 0.8}]},
  "aegis": {"tags": ["buff"], "shield": 120, "view": {"color": [0.4, 0.7, 1]}}
}
```

| key | meaning |
|---|---|
| `tags` | status tags for `dispel` (`buff`, `debuff`, `magic`, any word) |
| `flags` | `stun`, `silence`, `disarm`, `root`, `invulnerable`, `invisible`, `lock` (no sending / production), `blind`, `hidden` (garrison counts hidden), `flying` (off the lane, straight to the goal), `fake`, `ignoreDefense`, `spreads` (sent units carry it into the structure they enter — plague), `freezeRegen`, `alert`, `revealed` |
| `mods` | stat modifiers per stack (`stat`, `add`, `mul`) — on players they apply to all their objects (wind, global bonuses) |
| `tick` | `damage` / `heal` per stack, `interval`, `effects` (a payload around the holder: kill aura, burning) |
| `shield` | absorbs damage (or assaulting units on a garrison); the status ends when it breaks |
| `stacking`, `maxStacks` | `refresh` (default), `stack`, `independent` |
| `onExpire`, `onCaptured`, `onHit` | payloads: when it runs out (two-stage skills), when the structure is captured (revenge), on every weapon hit of the holder (enchanted weapons) |
| `incomeMult` | player statuses: `{"mana": 2}` multiplies income + regen |
| `garrisonPerSecond` | structure: units per second (negative: plague) |

Types can carry permanent statuses (`"statuses": ["thorns"]`). Weapons take `"onHit": {"chance": 0.3,
"effects": [...]}` (or a plain effect list) and `"chargeTime"` (charging shot: must stay on one target).
New stats: `energyRegen`, `defense` (garrison defense multiplier), `garrisonCap`, `cooldownRate`,
`upgradeCost`, `lifesteal`, `damageTaken`, `scale` (view). Resources take `"regen"` (per second for every
player: mana, morale).

For the view: `Statuses` (per object: `list` of `StatusInst` with `def` = index into `Rules::statuses`,
`stacks`, `until`, `shield`), player statuses in `PlayerEconomy::statuses`, `Area` entities, ability
`Projectile`s (`effList`), `GroupTag` (group id of units sent together). Events: `kEvStatusStart` /
`kEvStatusEnd`, `kEvAreaStart` / `kEvAreaTrigger` / `kEvAreaEnd`, `kEvProjectileLaunch`, `kEvImpact`,
`kEvChainJump`, `kEvCastStart`, `kEvChannelStart` / `kEvChannelEnd`, `kEvAlert`, `kEvGarrisonChanged`.

The AI casts every skill through the same smart targets (heals on the most wounded ally, area damage on the
densest enemy group, structure skills on the strongest enemy / the own structure under attack, group
skills on the largest group in transit, dispels on debuffed own objects), keeps 20% of a capped resource in
reserve, and leaves `autoEvery` skills to fire by themselves.

### Recipes

| skill | data |
|---|---|
| Rocket barrage | `"delivery": {"type": "projectile", "arc": true, "scatter": 1.5}` + `damage` with `radius` + `falloff`; `charges: 3` |
| Frost arrow | weapon `"onHit": {"effects": [{"type": "status", "status": "frost", "duration": 3}]}` (frost: `mods` speed × 0.6) |
| Heal over time | `{"type": "status", "status": {"tick": {"heal": 10, "interval": 1}, "tags": ["buff"]}, "duration": 5, "affects": "allies"}` |
| Bloodlust | `{"type": "status", "status": {"tags": ["buff", "magic"], "mods": [{"stat": "attackSpeed", "mul": 1.4}, {"stat": "speed", "mul": 1.25}, {"stat": "scale", "mul": 1.2}]}, "duration": 20, "affects": "allies"}` |
| Chain lightning | `"delivery": {"type": "chain", "jumps": 4, "jumpRadius": 5, "jumpFalloff": 0.75}` + `damage` |
| Shield | `status` with `"shield": 150` on an ally |
| Knockback stomp | `"target": "none"`, `[{"type": "knockback", "amount": 3, "radius": 3}, {"type": "stun", "duration": 1, "radius": 3}]` |
| Poison | status with `tick.damage`, `"stacking": "stack"` — from an ability or a weapon `onHit` |
| Artillery strike | `"delivery": {"type": "area", "delay": 2.5, "radius": 3}` (marker shows during the delay) |
| Summon wolves | `{"type": "spawn", "unit": "wolf", "count": 2, "duration": 60, "limit": 4}` |

#### Bunker Wars skills as primitives

Garrison structures, groups and lanes come from `garrison`, `kCmdSend` and `lanes`. `structure` / `group` /
`player` are player-ability targets.

| skill | data |
|---|---|
| Hypnosis | group: `convert` `percent` 0.5 (`shape: group`) |
| Defector | structure: `garrisonConvert` `percent` 0.3 |
| Plague | structure: status `{"flags": ["spreads"], "garrisonPerSecond": -1}` |
| Freeze | group: status `stun` (`shape: group`) |
| FreezeWave | group: `area` `motion: lane`, `trigger: periodic`, effects: status `stun` in a radius |
| Shield | own structure: status `shield` N (absorbs N assaulting units) |
| Invulnerability | own structure: status `invulnerable` |
| Teleport | group: `teleport` (`shape: group`) to the clicked point |
| ShortWay | point: `area` `trigger: contact`, `teleportTo` [dx, dz], `affects: own`, `lifetime` |
| Barrier | point: `spawn` a static unit type with `blocksLanes` and hp (a non-structure, so lanes don't route around it) |
| Mines | point: `area` `trigger: contact`, `maxTriggers` N, effects `kill` / `damage` |
| Tornado / SandStorm | `area` `motion: lane` (along a group's lane) or `wander` / `toward`, `trigger: periodic`, effects `kill` in a radius |
| BlizzardRain | `area` `trigger: periodic`, effects: `projectile` with `scatter` and `damage` |
| ChainLightning | `chain` with `kind: structure` + `garrisonKill` (over structures) or `damage` (over units) |
| SkeletonArmy | point: `area` with `deathSpawn` (units dying inside rise for the caster) |
| Rage | group: status `mods` damage / speed / `scale` up |
| Reverse / GoHome | group: `sendBack` `mode: reverse` / `home` |
| ThrowBack | group: `sendBack` `mode: throwBack`, `amount` cells |
| Panic | structure: `garrisonPanic` `percent` |
| Sabotage | structure: status `lock` + `disarm` (no sending, no production, towers silent) |
| Swap | structure: `swap` |
| Possession | structure: `capture` with `duration` (reverts unless recaptured) |
| CastTower / CastBuilding | structure: `transform` `to` + `duration`, `keepChance` |
| Downgrade / Upgrade | structure: `level` `delta` −1 / +1, `duration` |
| IncreaseProduction | own structure: status `mods` `productionSpeed` × 2 (and/or `garrisonCap`) |
| RedirectProduction | own structure: `redirect` `duration` |
| Landing | structure: `garrisonAdd` `amount` |
| Resurrection | own structure: `garrisonAdd` `percent` + `ofLost` |
| Spy | point: `reveal`; FogOfWar: own structures status `hidden` / `invisible` |
| Silence | player: `playerStatus` with `silence` |
| StealSkill | player: `stealSkill` `duration` |
| BreakAllMagic | none: `dispel` `shape: map`, `affects: any` (statuses on objects and players) |
| MoraleThief | player: `resource` `morale` `amount` −N, `transfer: true` |
| Sacrifice | own structure: `sacrifice` `percent`, `gain` |
| CloseRows | own group: `formation` |
| FlyingWave / Landing by air | own group: status `flying` |
| Worm | `spawn` with `owner: hostile` of a creature whose weapon `onHit` does `garrisonKill` |
| KillAura | own group: status with `tick.effects` `damage`/`kill` in a radius |
| BFG9000 | point: `projectile` (`collide`) delivering `garrisonKill` / `kill` in a large `radius` with `falloff` |
| Bomb | structure: `garrisonKill` `percent` |
| Average units | own structure: `equalize`; average morale: `equalizeResource` |
| Link | own structure: `link` `duration` |
| FastConvert | own structures: status `mods` `upgradeCost` × 0.5 |
| Defense aura | `area` `motion: follow` around a structure, `trigger: periodic`, status `mods` `defense` |
| IgnoreDefense / Suppress | group status `ignoreDefense`; structure status `mods` `defense` × 0.5 |
| Disable / blind towers | structure status `disarm` / `blind` |
| Two-stage slow | status slow with `onExpire`: a weaker slow status |
| Lift and drop | status `stun` (+ `scale` for the view) with `onExpire`: `damage` / `kill` |
| Illusion / fake units | group: `clone` `fake: true`; Clone: `clone` |
| Betrayal | group: `convert` (they keep walking into their former side) |
| Wind | player (all): `playerStatus` with `mods` `speed` |
| Alerts | self: `playerStatus` with `alert` (event `kEvAlert` on enemy sends) |
| Freeze regen / cooldown multiplier | `playerStatus` with `freezeRegen` / `mods` `cooldownRate` |
| Enhance weapon / charging shot | tower status `mods` damage / attackSpeed / range, or `onHit`; weapon `chargeTime` |
| Random N structures | `shape: map`, `kind: structure`, `sort: random`, `maxTargets: N` |
| Auto / map skills | `autoEvery`, or a trigger action `castAbility` |
| Passive skills | `passive: true` + `status` (in the loadout), or `requires` a tech |

Still needs code: **flying towers moving between points** (garrisons are fixed structures; a mobile
garrison would need garrisons on units).

## Army control (agent-mech): stances, retreat, transports

Optional blocks; a game without them plays exactly as before (stances and retreat commands work in any game).

```json
"stances": {"defendRadius": 6},                          // defensive stance: chase at most this far from where it stood
"retreat": {"speed": 1.25, "damageTaken": 0.75},          // the Retreat command (Company of Heroes / Dawn of War II)
"types": {
  "hq":     {"retreatPoint": true, ...},                  // retreating units run to the nearest own one (else key / producer)
  "archer": {"stance": "defensive", ...},                 // default stance of the type: aggressive | defensive | hold | passive
  "apc":    {"transport": {"slots": 8, "accepts": ["infantry"], "layers": ["ground"], "unloadInterval": 0.5, "killOnDeath": 1}},
  "bunker": {"transport": {"slots": 4, "fireFrom": 4, "heal": 2}},                 // passengers shoot from inside
  "town_center": {"transport": {"slots": 15, "damagePerCargo": 0.2, "accepts": ["villager"]}},   // AoE: more arrows per garrisoned unit
  "ifv":    {"transport": {"slots": 1, "weaponFromCargo": true}},                  // the passenger's weapon fires (RA2 IFV)
  "tank":   {"cargoSize": 4, ...}                                                  // slots a passenger takes (default 1)
}
```

- **Stances** (command `kCmdStance`, param 0 aggressive, 1 defensive, 2 hold, 3 passive): aggressive = default behaviour;
  defensive = fights enemies within `stances.defendRadius` of its spot and walks back; hold = never moves on its own
  (persistent `kCmdHold`); passive = never attacks on its own (explicit attack orders still work).
- **Retreat** (`kCmdRetreat`, needs a `retreat` block): the units run to the nearest own `retreatPoint` (else a `key`
  structure, else a producer) with `speed` x speed and `damageTaken` x damage, without fighting; any new order ends it.
  The AI retreats fighters below 30% hp that see an enemy.
- **Transports** (`transport` on units or structures): `kCmdLoad` (units = passengers, target = transport; a right click
  on an own transport does the same), `kCmdUnload` (units = transports; param 1 + point: drive there first). Passengers
  are off the map (`kUnitInCargo`): not targetable, not drawn, not pushing; they ride with the carrier. `accepts`
  (type tags) and `layers` filter passengers, `fireFrom` passengers with weapons shoot from inside at the carrier's
  position, `damagePerCargo` raises the carrier's own damage per passenger, `heal` hp/s inside. When the carrier
  dies, `killOnDeath` of the passengers die with it (default 1 for units, 0 for structures) and the rest get out.
  Events `kEvLoaded` / `kEvUnloaded` (a = passenger, b = transport). The AI mans shooting structures (`fireFrom`:
  fighters; `damagePerCargo`: workers) when enemies are within 10 cells and lets workers out when it is safe.

### Detection, toggles, veterancy, guard / follow, waypoints (agent-mech)

```json
"veterancy": {"xp": [100, 300, 700], "perLevel": [{"stat": "damage", "add": 0.1}, {"stat": "armor", "add": 1}], "healOnLevel": true, "fromCost": 1},
"statuses": {"cloak": {"flags": ["invisible"]}, "burrowed": {"flags": ["invisible", "root", "disarm"]}},
"types": {
  "observer": {"detects": 9, ...},                                   // reveals invisible enemies within 9 cells (allies share it)
  "ghost":    {"abilities": [{"id": "cloak", "target": "none", "toggle": {"status": "cloak", "drain": 1}}], ...},
  "lurker":   {"abilities": [{"id": "burrow", "target": "none", "toggle": {"status": "burrowed"}}], ...},
  "wall":     {"veterancy": false},                                   // or its own {"xp": [...], "perLevel": [...]}
  "tank":     {"xp": 50, ...}                                         // xp its killer gets (default: its cost x fromCost)
}
```

- **Detection**: invisible objects (status flag `invisible`) can be targeted by a side only when `revealed` or within
  `detects` of one of its (or an ally's) detectors. `RtsModule::canSee(sim, e, viewer)` is the query for the view/UI.
- **Toggle abilities**: casting switches the status on (until toggled off) and off; `drain` energy per second turns
  it off when energy runs out. Cloak, burrow, submerge, siege mode (a status with mods / flags) are data.
- **Veterancy** (ordinary units; heroes keep `hero`): the unit that dealt the last hit gets the victim's `xp`;
  ranks apply `perLevel` per rank above 1 and heal on rank-up; event `kEvLevelUp` (value = rank).
- **Guard / follow** (`kCmdGuard`, `kCmdFollow`, target = unit): follow within ~3 cells; guard also fights enemies
  within 6 cells of the guarded unit.
- **Rally waypoints**: `kCmdRally` with the queue flag (Shift) adds waypoints after the rally point; new units walk
  them in order. A plain rally clears them. The order queue itself (`kCmdQueue` on any command) always existed.
- **Wave routes**: map waves take `"route": ["gate", [30, 8]]` (area names or points), walked before the objective.

### Combat and economy models (agent-mech keys = aliases of the fidelity blocks)

These keys come from agent-mech; they are parsed into the single implementation of each mechanic described in
[Fidelity mechanics](#fidelity-mechanics-play-like-the-original) and mean the same there.

```json
"armorModel": "percent",                                               // = "armor": {"model": "percent", "negative": "exponential"}; "factor" = perPoint
"armorModel": {"type": "subtract", "minFraction": 0.2, "min": 0},      // = "armor": {"model": "subtract", "minShare": 0.2, "minDamage": 0}
"armorModel": {"type": "classes", "base": ["melee", "pierce"], "min": 1},   // = "armor": {"model": "classes", "base": [...], "minDamage": 1}
"upkeepResources": ["gold"],                                            // = "resources" of every upkeep tier that names none (Warcraft III)
"types": {
  "spearman": {"weapons": [{"damage": 3, "attacks": {"melee": 3, "cavalry": 15}}], "armors": {"melee": 0, "pierce": 0, "infantry": 0}},
  "knight":   {"armors": {"melee": 2, "pierce": 2, "cavalry": 0}},
  "zealot":   {"shields": {"max": 50, "regen": 2, "delay": 10, "armor": 0}},   // StarCraft shields
  "goldmine": {"resourceNode": {"resource": "gold", "amount": 12500, "maxWorkers": 5}}
}
```

- **classes** (Age of Empires II): damage = max(`min`, sum over the weapon's `attacks` of max(0, attack - armor of that
  class)); `base` classes always count (a missing armor is 0, armor upgrades raise them), other classes only against
  types that list them in `armors` (bonus damage is added, not multiplied). A weapon without `attacks` attacks the first
  base class with its `damage`. The damage table is not used in this model. Without `min` / `minFraction` the classes
  model floors at 1 and has no share floor.
- `armorModel` percent uses the exact Warcraft III curve for negative armor (`2 - (1 - k)^-a`); `"armor"` keeps the
  linear `1 + min(-a·k, 0.71)` unless it says `"negative": "exponential"`.
- type `"shields": {"max", "regen", "delay", "armor"}` = `health.shields` / `shieldRegen` / `shieldDelay` / `shieldArmor`
  (same defaults: regen 2/s, delay 10 s); one shield component (`Shield`) for both spellings.
- `resourceNode.maxWorkers` = `resourceNode.maxGatherers`: further workers wait next to the node or take a free node
  of the same resource nearby.
### Genre mechanics (agent-mech stage 2)

```json
"market": {"currency": "gold", "prices": {"wood": 100, "food": 100, "stone": 130}, "fee": 0.3, "step": 3, "lot": 100},
"tribute": {"fee": 0.3}, "diplomacy": true,
"items": {"potion": {"cost": {"gold": 50}, "use": {"heal": 200}, "charges": 1},
          "boots":  {"cost": {"gold": 100}, "mods": [{"stat": "speed", "add": 1}], "charges": 0, "consumable": false}},
"cycles": [{"id": "day", "length": 480, "phases": [{"id": "day", "until": 0.6}, {"id": "night", "until": 1, "status": "night"}]},
           {"id": "season", "length": 1200, "phases": [{"id": "summer", "until": 0.75}, {"id": "winter", "until": 1, "status": "winter"}]}],
"hazards": [{"field": "tiberium", "damage": 6, "tags": ["infantry"]}, {"area": "lava", "status": "burning"}],
"deck": {"hand": 4, "deployNear": 8, "ownHalf": true},
"types": {
  "wall":     {"wall": true, ...},                       // built in a line (kCmdBuildLine)
  "gate":     {"gate": "own" | "allies", ...},           // the owner walks through; enemies are stopped and attack it
  "bridge":   {"bridge": true, ...},                     // walkable ground over water while it stands (map-placed)
  "nydus":    {"transport": {"slots": 20}, "tunnel": "nydus"},   // load at one, unload at any tunnel of the network
  "hovercraft": {"move": {"layer": "amphibious", ...}},  // ground and water
  "harrier":  {"weapons": [{"ammo": 2, ...}]},           // empty: flies to the nearest own dock and rearms
  "airfield": {"dock": {"slots": 4, "rearmTime": 1}},
  "templar":  {"mergeInto": {"with": "templar", "result": "archon"}},   "archon": {"splitInto": {"type": "templar", "count": 2}},
  "market":   {"market": true}, "cart": {"trader": {"rate": 0.5}},     // currency per cell between the two markets per round trip
  "hero":     {"inventory": {"slots": 6}}, "shop": {"shop": {"sells": ["potion", "boots"], "radius": 4}},
  "kobold":   {"drops": [{"item": "potion", "chance": 0.3}]}
}
```
Map players may have `"deck": ["card ids..."]` (default: every player ability). Commands: `kCmdFormation` (param 0 line, 1 box,
2 wedge, 3 loose, -1 break; a formation ordered to a point keeps its shape and the pace of its slowest member),
`kCmdBuildLine`, `kCmdMerge`, `kCmdSplit`, `kCmdTrade` (sell / buy one lot; prices move by `step` and are shared by all),
`kCmdTradeRoute`, `kCmdTribute`, `kCmdDiplomacy` (alliances need both sides; war moves the player to a new team),
`kCmdBuyItem` / `kCmdUseItem` / `kCmdDropItem` / `kCmdPickItem`. Cycles apply their phase `status` to every player and set
trigger variable `cycle.<id>` = phase index (event `kEvCyclePhase`). Jumps over cliffs, jetpacks and blinks are abilities
with the `blink` effect; teleport networks are `area` effects with `teleportTo`. The AI sells surplus / buys shortages,
sends idle carts to the farthest market, buys and drinks potions with heroes and merges idle pairs.
Through MCP (`scenario_run` / `play_command`), `trade`, `tribute` and `bounty` take readable fields instead of the packed
param: `{"cmd": "trade", "units": [market], "resource": "wood", "sell": true}`,
`{"cmd": "tribute", "resource": "gold", "amount": 100, "to": 2}`, `{"cmd": "bounty", "target": id, "resource": "gold", "amount": 50}`.

## Tactics and society (agent-mech stage 3)

Optional blocks; a game without them loads, plays and hashes as before. Tested in `tests/tests_mech.inc`
(`mech_tactics`, `mech_society`, `mech_rounds`, `mech_ai_staffing`, `mech_designs`).

### Cover, suppression, armor arcs (Company of Heroes, Men of War)

```json
"cover": {"levels": {"1": 0.75, "2": 0.5}, "tags": ["infantry"]},
"suppression": {"decay": 5, "suppressed": 30, "pinned": 80, "suppressedSpeed": 0.5, "suppressedAttack": 0.5, "tags": ["infantry"]}
```

- `cover.levels`: damage multiplier per cover level 1..9. A unit (with one of `tags`, all if omitted) takes the level of its
  cell — map `"cover": {"rows": ["0012..", ...]}` (digit per cell) — or of a structure with `"givesCover": N` within
  half its footprint + 1.5 cells, whichever is higher.
- Weapon `"suppress": 10` adds suppression (0..100) per hit; it decays by `decay` per second. Above `suppressed` the unit is
  slower and attacks slower; above `pinned` it cannot move.
- Type `"armorArcs": {"side": 0.75, "rear": 0.5}`: damage multiplier for hits from the side / rear by the unit's facing.
- Weapon `"turret": {"turnRate": 90}` (degrees per second): the weapon only fires once its turret faces the target.
- Weapon `"crater": 1` (or `{"radius": 1}`): the ground around the hit becomes cover level 1.

### Crews, crushing, ruins, infection (Z, Men of War, C&C, They Are Billions)

- Crews are one mechanic with the fidelity `crew` / `crews` / `killsCrew` keys (see [Fidelity mechanics](#fidelity-mechanics-play-like-the-original)):
  `"crew": {"accepts": ["infantry"]}` (or `true`: any mobile unit) is a crewed vehicle that any unit with an accepted
  tag may man, without `"crews": true`. Weapon `"killsCrew": 1` (chance per non-lethal hit) leaves it empty and neutral
  (owner 0); a unit that may man it right-clicks it (smart / `load`), walks up and becomes its crew: the vehicle
  changes owner, the soldier is removed.
- `"crush": {"damage": 500, "tags": ["infantry"]}`: a moving unit damages hostile mobile units with those tags it touches.
- `"ruins": "rubble"`: a type spawned (neutral) where this one died.
- Weapon `"infect": "zombie"`: a unit it kills rises as that type for the killer's owner. A structure with
  `"infectable": {"spawns": "zombie", "count": 2}` destroyed by such a weapon spawns `count` of `spawns`.

### Staff, growth, power fields (Settlers, Stronghold, StarCraft, Anno)

- `"staff": {"count": 2, "accepts": ["worker"]}`: income and production scale with the share of places taken (workers
  enter with `load` / smart click; a transport block with `count` slots is created). The AI sends idle workers.
- `"grows": {"unit": "villager", "interval": 30, "cost": {"food": 20}}`: the structure produces the unit every
  `interval` seconds while it can pay and has supply.
- `"powerField": 6` (radius) and `"needsPower": true`: a structure that needs power works and can be placed only inside
  a finished field of its owner.

### Bounties and autonomous heroes (Majesty)

`"autonomous": true` units are not commanded; they pick fights by themselves and prefer targets with a bounty.
Command `bounty` (target, `param` = resource index | amount << 8) pays the amount, held until the target dies, to the
owner of the unit that killed it. MCP: `{"cmd": "bounty", "target": id, "resource": "gold", "amount": 100}`.

### Rounds (auto-battlers, Mushroom-style duels)

```json
"rounds": {"prepare": 20, "fight": 40, "rounds": 10, "reset": true, "lives": "lives", "damagePerUnit": 1, "income": {"gold": 5}}
```

The game alternates a prepare phase (nobody acquires targets) and a fight phase. At the end of a fight each side loses
`damagePerUnit` of `lives` per surviving enemy unit; with `reset` the armies are restored to the snapshot taken at the
start of the fight. Everyone gets `income` per round. After `rounds` rounds (or when a side runs out of lives) the game
ends: the side with most lives wins.

### Upgrades paid with garrison (Mushroom Wars 2)

`"upgradeGarrison": 10` on the target type of an `upgrades` entry is an alias of the fidelity key `"cost": {"garrison": 10}`:
the upgrade costs that many units of the building's garrison on top of its resource cost (refused when the garrison is
smaller; the units are taken only when the upgrade is queued).

## Unit designs (agent-mech, UD)

Types can be assembled from a chassis and parts (Master of Orion, Galactic Civilizations, Supreme Commander kits).
`loadRules` expands them into plain type blocks before parsing (`expandDesigns`), so every other key works as usual;
`rules_lint` lints the expanded copy.

```json
"designs": {
  "chassis": {"light": {"move": {"speed": 4}, "health": {"max": 100}, "cost": {"gold": 50}, "slots": {"weapon": 2, "system": 1}}},
  "parts": {
    "laser":   {"slot": "weapon", "weapons": [{"range": 5, "damage": 10, "cooldown": 1}], "cost": {"gold": 20}},
    "plating": {"slot": "system", "add": {"health.max": 60, "move.speed": -1}, "cost": {"gold": 30}, "health": {"armor": 2}}
  }
},
"types": {"scout": {"design": {"chassis": "light", "parts": ["laser", "laser", "plating"]}, "sight": 8}}
```

- The chassis is copied; parts apply in order: `add` adds numbers at dotted paths, `cost` / `upkeep` add per resource,
  `weapons`, `tags`, `abilities`, `upgrades` are appended, other keys are merged (objects) or replaced.
- `slots`: a count, or a count per part `slot` kind; too many parts is a load error.
- The type's own keys (besides `design`) are applied last.

## Field battles, big armies, logistics (agent-mech stage 4)

Tested in `tests/tests_mech.inc` (`mech_battle`, `mech_flow_fields`, `mech_logistics`; `RTS_BENCH_ARMY=1500` runs a
3000-unit benchmark).

### Morale, rout, fatigue, charge (Total War, Close Combat)

```json
"morale": {"max": 100, "regen": 2, "hitLoss": 100, "allyDeath": 6, "allyRadius": 6, "flankSide": 1.5, "flankRear": 2,
           "waver": 40, "rout": 20, "rally": 60, "routSpeed": 1.25, "waverAttack": 0.85, "tags": ["soldier"],
           "general": {"tags": ["general"], "radius": 10, "regen": 6, "death": 30}},
"fatigue": {"run": 2, "fight": 4, "recover": 5, "tired": 50, "exhausted": 85, "tiredMul": 0.85, "exhaustedMul": 0.6}
```

- Morale (per unit, `"morale": 120` on a type overrides `max`) falls by `hitLoss` x the share of max hp a hit takes,
  times `flankSide` / `flankRear` when the attacker is beside / behind the unit's facing; by `allyDeath` when an own unit
  dies within `allyRadius` (`general.death` within twice `general.radius` when a general dies). It recovers by `regen`
  per second, plus `general.regen` near an own general.
- Below `waver` the unit wavers (attack speed x `waverAttack`); below `rout` it routs: drops its orders, runs away from
  the nearest enemy (speed x `routSpeed`), does not fight and recovers only when no enemy is in sight, until `rally`.
  Event `morale` (value 0 steady, 1 wavering, 2 routing). The AI walks idle generals to its shakiest soldiers.
- Fatigue 0..100 grows by `run` per second moving and `fight` per second shooting, drops by `recover` when idle; above
  `tired` / `exhausted` speed and attack speed are multiplied by `tiredMul` / `exhaustedMul`.
- `"charge": {"bonus": 1.5, "run": 3, "shock": 15, "cooldown": 8}` on a type: after running `run` cells, the first blow
  deals `bonus` x damage and costs the target `shock` morale.
- MCP state shows `morale`, `moraleState`, `fatigue`, `supplied`.

### Supply lines (Rise of Nations, Hearts of Iron)

`"supply": {"tags": ["soldier"], "attrition": 0.01, "speed": 0.8, "attack": 0.8}` and `"supplyRadius": 12` on depot
types: units farther than that from every finished own or allied depot lose `attrition` x max hp per second and move
and attack slower.

### Big armies (BA)

`"flowFields": true` (or `{"minCells": 8, "cache": 16}`) is an alias of the one flow-field system
(`movement.flowField`, see Movement): it means `{"minGroup": 1, "minCells": 8, "maxFields": 16}` — every ground move,
attack-move, patrol or right-click order of a unit at least `minCells` cells from its goal follows the goal area's
shared field (an explicit `movement.flowField` wins). In addition attack-move groups of more than 24 form a block of
rows instead of one wide arc (each unit walks to its own row point with its own path). Separation and RVO neighbour
lookups always use a one-cell grid (results identical to the spatial-hash version). Benchmark (ARM VM, -O3): 3000
units fighting, about 13 ms per tick.

### Conveyors, producers, crafters (Mindustry, Factorio)

```json
"belt":    {"structure": {"footprint": [1, 1]}, "conveyor": {"speed": 4}},
"drill":   {"structure": {"footprint": [2, 2]}, "beltOutput": {"resource": "ore", "amount": 1, "interval": 0.5}},
"smelter": {"structure": {"footprint": [2, 2]}, "craft": {"in": {"ore": 2}, "out": {"plate": 1}, "time": 1}},
"core":    {"structure": {"footprint": [2, 2]}, "beltInput": ["plate"]}
```

- A conveyor piece carries one packet per cell at `speed` cells per second in its direction (east, south, west, north):
  set by `build_line` (along the line's main axis), map entity `"dir": "e"`, or command `rotate`
  (`{"cmd": "rotate", "units": [...], "dir": "n"}`; without `dir` it turns clockwise).
- Producers put a packet on a free adjacent belt that does not point back into them every `interval`; crafters take
  their inputs from belts (up to twice a batch), work `time` seconds (scaled by staff / power) and put outputs on belts.
- A structure with `beltInput` (resource list or `"any"`) takes packets into its owner's stock (event `delivered`).
- Belts are ordinary structures (blocking, destructible); a packet on a destroyed belt is lost. The AI does not lay
  belts yet. MCP state: a belt's `dir` and `carries`, a crafter's `input` / `output`.

## Turns, strategic map, 3D flight (agent-mech stage 5)

Tested in `tests/tests_mech.inc` (`mech_turns`, `mech_strategic`, `mech_space_flight`).

### Turn-based mode (Heroes, XCOM, Advance Wars battles)

`"turns": {"moveSeconds": 4, "attacks": 1, "timeLimit": 0}`: players act one after another on the same simulation.
During a turn only the active player's units move (at most type speed x `moveSeconds` cells) and shoot (`attacks`
shots per weapon); the others stand still and don't return fire; commands of other players are ignored. Command
`end_turn` (or `timeLimit` seconds) passes the turn to the next living player; event `turn` (player, turn number).
Bots send their fighters at the nearest enemy once per turn and end the turn when they stop moving.

### Strategic map (Total War campaign, Company of Heroes 3, Empire at War)

`modules/strategic/Strategic.h`: provinces and armies on top of the game's `rules.json`; battles are auto-resolved
(Lanchester square law on hp x dps) or simulated on the RTS simulation with bots, and the survivors return to the map.

```json
{"players": [{"name": "Red"}, {"name": "Blue"}], "start": {"gold": 100}, "movesPerTurn": 1,
 "recruit": {"spear": {}, "archer": {"gold": 40}},
 "battle": {"mode": "simulate", "seconds": 240, "size": [48, 32]},
 "provinces": [{"id": "a", "owner": 1, "income": {"gold": 40}, "adj": ["b"], "pos": [0, 0], "terrain": {"rows": [...]}},
               {"id": "b", "adj": ["c"]}, {"id": "c", "owner": 2}],
 "armies": [{"owner": 1, "at": "a", "units": {"spear": 12}}, {"owner": 2, "at": "c", "units": {"spear": 6}}]}
```

- Adjacency is symmetric. `recruit` with `{}` uses the type's `cost`. Moving into a province with an enemy army
  fights a battle; an empty enemy or neutral province is taken. Own armies in one province merge.
- Income of owned provinces comes at the start of the owner's turn; a player with no provinces and no armies is out;
  the last one standing wins.
- MCP: `strategic_load` (`file` in the project or `def`), `strategic_state`, `strategic_order`
  (`move` / `recruit` / `end_turn`), `strategic_bots` (bots play N turns; `battle`: auto | simulate),
  `strategic_battle_map` (the RTS map of a battle, to play by hand), `strategic_save`.

### Free 3D flight (Homeworld)

`"altitude": {"min": 0, "max": 30, "climb": 3, "start": 10}` on an air type: the unit keeps its own height, climbs or
dives to the `y` of its move orders (MCP `{"cmd": "move", "x", "z", "y"}`), follows the height of the target it
attacks, and weapon ranges to and from it are measured in 3D. Paths and avoidance stay 2D. The view does not draw the
altitude yet.

## Save states (agent-mech)

`Simulation::serialize()` returns the whole dynamic state as bytes (versioned, little-endian, identical on every
platform: `engine/core/Archive.h`); `deserialize(bytes)` loads it into a simulation set up from the same rules, map and
seed and checks the state checksum stored in the file. Saved: tick, RNG, players and teams, pending and executed
commands (replays continue), the entity allocator, every component pool in dense order and the dynamic part of
`GameState` (per-cell layers run-length encoded). Not saved: rules, triggers, the planet surface (from setup) and derived
caches (clearance, HPA*, rebuilt on demand). The computer players keep their own memory, so bots resume from the loaded
state with fresh plans. Module side: `RtsModule::serializeState` (`modules/rts/RtsSave.cpp`); a component type missing from
its list makes saving fail. `rts_headless --save F --save-at S` / `--load F`; MCP `match_run` with `saveCheck` (seconds).
A skirmish match at 90 s is ~150 KB.

## Campaigns (agent-mech)

`campaign.json` in the game folder chains missions; see `modules/rts/RtsCampaign.h`:

```json
{"start": "m1", "missions": [
  {"id": "m1", "name": "Raid", "map": "maps/m1.json", "briefing": "campaign.m1.briefing", "next": "m2",
   "carry": {"resources": ["gold"], "tags": ["hero"], "types": ["knight"], "max": 12}},
  {"id": "m2", "name": "Siege", "map": "maps/m2.json"}]}
```

Trigger actions for missions: `{"type": "objective", "id": "raze", "text": "...", "op": "add" | "done" | "fail", "primary": true}`,
`{"type": "dialog", "speaker": "Captain", "portrait": "ui/captain.png", "voice": "vo/c1.ogg", "text": "...", "duration": 4}`,
`{"type": "camera", "at": [x, z] | "area": "a", "zoom": 1, "duration": 2, "lock": false}`,
`{"type": "endMission", "result": "victory" | "defeat", "next": "m2"}`. State in `GameState::mech` (`objectives`,
`dialogs`, `nextMission`, `missionResult`, saved with the match); events `kEvObjective`, `kEvDialog`, `kEvCamera`,
`kEvMissionEnd` for the HUD (objective list, dialog box, camera moves). Between missions `collectCarry` (survivors with
hp, rank, hero level; resources) -> `applyCarry` (into the next map, players[0] = campaign player) -> `restoreCarry`
after setup. MCP: `campaign_get`, `campaign_set` (validated), `campaign_run` (bots, mission chain, outcomes, carry).

## Commands (for tools and network code)

Besides the unit commands (`RtsModule.h`): `kCmdSurrender` (the issuing player is defeated, event value 1),
`kCmdDig` / `kCmdPaintRoom` (point = first cell, `param = rectParam(w, h, extra)`: dig `extra` 0 mark / 1 unmark;
room `extra` = room index or -1 erase), `kCmdPickUp` (units), `kCmdDrop` (point; units or `param` = count),
`kCmdSlap` (units), `kCmdPossess` (units[0]; empty = release), `kCmdDirect` (point = direction, `param` bit 0 = fire,
optional target), `kCmdPlayerAbility` (`param` = index, point), `kCmdBuildRoad` (rect, `extra` 1 = remove),
`kCmdConnectRoad` (units = own structures), `kCmdTransit` (planets: orbit units, `param` = target body), `kCmdStance` (param = stance),
`kCmdRetreat`, `kCmdLoad` (target = transport), `kCmdUnload` (param 1 = drive to point first), `kCmdGuard` / `kCmdFollow` (target = unit). `kCmdPlayerAbility` with a `structure` / `group` / `player`
ability takes the clicked object in `target` (or the nearest one to `point`).

## Triggers

Event → conditions → actions, evaluated inside the deterministic simulation.

```json
{"id": "relic", "once": true, "enabled": true, "forEachPlayer": false,
 "event": {"type": "enterArea", "area": "relic", "player": 1, "unit": "hero"},
 "conditions": [{"type": "count", "player": "triggering", "kind": "structure", ">=": 3}],
 "actions": [{"type": "message", "text": "Реликвия найдена!"}, {"type": "give", "resource": "gold", "amount": 500}]}
```

Events: `start`, `time` (`seconds`), `every` (`seconds`), `enterArea` / `leaveArea` (`area`, unit filter),
`unitDied`, `built`, `trained` (unit filter), `researched` (`tech`), `captured`, `wave`, `regionClaimed`,
`playerDefeated`, `ability`, `levelUp`, `resource` (`resource`, comparison: fires when it becomes true),
`variable` (`name`, comparison). Event `player`: a slot number, `"any"` (default), `"creeps"`.

Unit filter (events, conditions, actions): `"unit": "type"`, `"tags": [...]`, `"kind": "structure"|"unit"`, `"area": "name"` or `[x,z,w,h]`.

Comparisons: one of `">=", ">", "<=", "<", "==", "!="` with a number.

Conditions: `count` (objects matching the filter), `resource`, `variable`, `researched`, `random`
(`chance`), `time` (seconds), `alive`, `regions` (owned count). `"not": true` negates.

Actions: `spawn` (`unit`, `count`, `at` [x,z] / `area`, `attackMove`), `give` / `take` (`resource`,
`amount`), `setOwner`, `kill`, `remove`, `damage`, `heal` (`amount`), `buff` (`stat`, `add`/`mul`,
`duration`), `message` (`text`), `setVariable` / `addVariable` (`name`, `value`), `research` (`tech`),
`enableType` / `disableType` (`unit`), `victory` / `defeat`, `enableTrigger` / `disableTrigger`
(`trigger`), `addScore` (`amount`), `setRegionOwner` (`region` name), `attackMove` / `move` (units
matching the filter to `at` / `area`), `setTickets` (`amount`).

Action `player`: `"triggering"` (default: the player of the event), `"all"`, `"enemies"`, `"allies"`,
`"creeps"`, `"neutral"`, or a slot number. `"target": "triggeringUnit"` acts on the event's unit.

### Testing data through MCP

`scenario_run` runs a scripted check on a copy of the open map: named `spawn`s, timed `commands` (keys of
`play_command`), optional `bots`, `checks` (pass/fail) and `watch` / `events` / trigger logs. Every fired trigger
is also a simulation event `kEvTriggerFired` (value = trigger index: rules triggers first, then map triggers;
player = triggering slot) — presentation/tools only, not hashed. `rules_lint` lists keys the loader never reads;
`rules_schema` with `part: "keys"` lists every key the loader reads per block, taken from the loader itself.

### C++ modules through MCP

`native_status` compares rules.json `nativeModules` with what the running editor binary has compiled in
(`required`, `compiled`, `missing`) and describes the per-project editor build in `<project>/Builds/.temp/editor-<host>`
(`editor`, `headless`, `built`, `buildModules`, `upToDate`, `ready`, `why`). `native_build` configures and builds
`rts_editor` + `rts_headless` there with `-DRTS_CONTENT_DIR=<project>` (Release), streaming into the build log
(`build_status`); `wait: true` blocks until it ends and returns the binary paths. See docs/native-modules.md.

## Texture atlases (game.json `atlas`, optional)

The editor's Build window shows oversized atlas candidates under “Не в атласе”.
“Исправить размеры текстур” applies the proposed maximum sizes as exact, first-priority
`packaging.targets.<platform>.files` rules and refreshes the size estimate. This reduces
image detail in the built pack; original assets are unchanged. Sprite sheets, tile atlases, and UI `@spritesheet` sources in RCSS
with pixel-based coordinates are never offered this fix. Existing resize rules for these sources
are ignored during packaging to preserve their frame coordinates. Other exclusions (repeat wrapping,
noAtlas, decode failures, a lone image in a group) require manual decisions. Recalculate a stale
report before applying fixes; the button is disabled while settings differ from the report.

When a game is packaged (`rtsbuild`, `assetpipe pack --atlas <profile>`), small 2D images are
packed into atlas pages: fewer texture switches/draw calls, trimmed transparent borders, identical
images stored once, and pages compressed by the pack's zstd. Game code keeps using the original
paths (`units/orc/grunt/walk_0.png`); the lookup is transparent at runtime. Loose-folder builds
(`--no-pack`, editor) use the images as they are. The whole block is optional:

```json
"atlas": {
  "enable": true,                                   // false (or rtsbuild --no-atlas): ship images as is
  "maxPage": { "web": 2048, "android": 2048, "default": 4096 },  // or a single number
  "pageSize": "mul4",          // page sides: multiples of 4 (default) or "pow2"
  "padding": 2,                // empty texels between images
  "extrude": 1,                // edge texels repeated around each image (no filtering seams)
  "trim": true,                // cut fully transparent borders (offsets are kept)
  "maxTextureSize": 0,         // larger images stay standalone; 0 = maxPage / 4
  "mipLevels": 2,              // groups with "mips": padding/alignment safe down to 2^levels
  "pageFormat": "rtex",        // "rtex" (raw RGBA, zstd in the pack, fastest load) or "png"
  "groups": { "units": { "rotate": false, "mips": true }, "tiles": { "trim": false } },
  "files": {                   // glob -> settings; `*` also matches '/'; later rules win
    "ui/splash/*": { "noAtlas": true },
    "units/orcs/*": { "group": "orcs" },
    "textures/water.png": { "wrap": "repeat" },
    "units/*/shadow.png": { "kind": "mask" }
  }
}
```

Profiles are rtsbuild targets (`macos`, `ios`, `android`, `web`, `windows`, `linux`); built-in
page limits: 2048 for `web`/`android`, 4096 otherwise. Targets with equal settings share one pack.

**What goes together.** An image's group key is *usage group* + *kind* (+ opaque/alpha when the
group splits by alpha, + mips). Images only share a page with the same key:

| usage group | default folders (first path component, `engine/` prefix ignored) | defaults |
|---|---|---|
| `ui` | `ui/`, `icons/`, `portraits/`, `cursors/`, `hud/` | trim |
| `units` | `sprites/`, `units/`, `buildings/`, `structures/`, `characters/` | trim |
| `tiles` | `tiles/`, `tilesets/`, `terrain/` | no trim (sheet grids stay intact), opaque and alpha tiles on separate pages |
| `effects` | `effects/`, `fx/`, `vfx/`, `particles/` | trim |
| any name | set with `"group"` (or `"atlasGroup"`) in `files` | as `units` |

Other folders (`models/`, `textures/`, ...) are not atlased unless a `files` rule names a group:
3D meshes use UVs outside 0..1 and wrap. *Kind* is `color`, `normal` (`*_n`, `*_nrm`, `*_normal`,
`normals/`) or `mask` (`*_mask`) — normal maps and masks are never mixed with colour and never
trimmed. Never atlased: `noAtlas`, `"wrap": "repeat"` (also `*_repeat`, `*_tiling`, `*_wrap`),
images above `maxTextureSize` (after trimming), and an image that would be alone in its group
(one page = no saved texture switch, only padding). Images referenced as a frame-grid sprite
sheet anywhere in the game's JSON (`"sheet": "sprites/tank.png"`) are never trimmed or rotated, so
frame uvs map linearly onto the atlas region. Inside a group, images of one folder (one unit's
frames, one faction) stay on the same page whenever they fit; pages are shrunk to the smallest size
that holds them. Per-file keys: `group`/`atlasGroup`, `noAtlas`, `wrap`, `kind`, `rotate` (allow a
90° turn, off by default so facings never rotate), `trim`, `mips`, `splitAlpha`, `padding`,
`extrude`; the same keys (except `group`) work per group in `groups`.

**In the pack.** Atlased images are removed; `_atlas/` is reserved and holds the pages
(`_atlas/<group>-<n>.rtex`) and `_atlas/atlas.json`:

```json
{ "version": 1,
  "pages": [ { "file": "_atlas/units-0.rtex", "group": "units", "w": 1016, "h": 864, "alpha": true, "mips": false } ],
  "textures": { "units/orc/grunt/walk_0.png": [0, 3, 3, 30, 38, 33, 29, 96, 96, 0] } }
```

Texture entry: `[page, x, y, w, h, offsetX, offsetY, sourceW, sourceH, rotated]` — integer pixels.
`(x, y, w, h)` is the trimmed content in the page (when `rotated` = 1 it occupies `h x w` turned 90°
clockwise); `(offsetX, offsetY)` is its position in the original `sourceW x sourceH` image, so
pivots given in original-image pixels stay valid. `.rtex`: 24-byte header (`RTEX`, version,
width, height, flags: 1 alpha, 2 mips, 4 left-delta filtered rows) + RGBA8 rows top to bottom,
straight alpha. Output is byte-identical for the same input.

**Runtime API** (`engine/atlas/TextureLibrary.h`, link `rts_atlas`):

```cpp
atlas::TextureLibrary lib(dev, [](const std::string& p, std::string& o) { return platform::readContentFile(p, o); });
const atlas::TextureRef* t = lib.get("units/orc/grunt/walk_0.png");   // nullptr if missing
// quad: t->w x t->h source pixels at (t->offsetX, t->offsetY) from the original image's top-left
// (pivot in original pixels: pos - pivot + offset); UVs t->uv = TL, TR, BR, BL (rotation applied);
// t->texture equal for images on one page -> batch by it; t->opaque -> draw without blending.
```

`atlas::mapUV(*t, px, py, u, v)` maps a point in original-image pixels to the texture (trim and
rotation included) — e.g. frame corners of a sheet. For a renderer that already maps frames via a
rect (`u0 + (u1 - u0) * lu`), the rect of an atlased sheet is `t->uv[0..1]` .. `t->uv[4..5]`.
The 2D sprite/tile renderer's `render::TextureCache::resolve()` already understands atlases:
an atlased image resolves to the page texture + its rect (sprite sheets are never trimmed, so
frame uvs stay exact); a trimmed or rotated image is rebuilt as a standalone texture.
Plain (non-atlased) images come back the same way (own texture, full UVs, no trim). CPU pixels of
an original image: `lib.loadImage(path, img)` or `atlas::ImageSource` (the UI uses it, so RmlUi
`<img src>` and decorators keep working with atlased files).

**Build report.** `rtsbuild` prints atlas statistics and writes `size-report.json` next to
`size-report.txt` (`<out>/<target>/`): `pack` {rawBytes, packBytes, entries, duplicates, top[]} and
`atlas` {enabled, profile, maxPage, candidates, atlased, duplicates, pages, occupancyPercent,
sourceBytes, atlasBytes, storedBytes, bytesSaved, gpuBytesBefore, gpuBytesAfter,
textureBindsBefore, textureBindsAfter, groups[] {group, textures, unique, pages,
occupancyPercent}, excluded[] {path, reason}}. Preview: `assetpipe atlas --profile web -o <dir>
<project> engine/assets=engine` writes the pages as PNG plus the manifest and the report.

## Icons and splash (game.json `icons`, `splash`, optional)

Both blocks are read by `rtsbuild` (every size each platform needs, generated on the host without
sips/iconutil — works from Linux), by the client (the splash) and by the editor window
**Иконки и заставка** (opened from **Сборка**) / MCP `branding_get`, `branding_set`,
`icons_preview`, `splash_preview`. Paths are relative to the game folder. Code: `tools/branding`
(host), `engine/splash` (runtime), `apps/client/ClientSplash.cpp` (startup).

### icons

```json
"icons": {
  "default": "branding/icon.png",              // master: square, >= 1024 px (old "icon" is the fallback)
  "background": "#101a28",                     // for icons that must be opaque (else: the image's edge colour)
  "padding": 0.0,                              // artwork inset on opaque squares (fraction of the side)
  "cornerRadius": 0.0,                         // rounding of the Android legacy icon (default 0.12)
  "ios": "branding/icon_ios.png",              // path, or {"image", "background", "padding"}
  "macos": {"margin": 0.098, "cornerRadius": 0.225},      // Big Sur grid by default; 0/0 for pre-shaped art
  "android": {"legacy": "...", "round": "...",            // path or look object
              "foreground": "branding/icon_foreground.png", // adaptive 108dp layer (centre 72dp visible)
              "background": "#101a28",                      // colour or image path
              "monochrome": "branding/icon_monochrome.png", // Android 13 themed icon (alpha is used)
              "foregroundPadding": 0.17},                   // when the master is used as the foreground
  "windows": "...", "linux": "...",
  "web": {"image": "...", "appleTouch": {...}, "maskable": {...}}
}
```

A *look* object (any platform) has `image`, `background`, `padding` (inset of the art inside the
icon body), `margin` (transparent space around the body), `cornerRadius` (fraction of the body),
`circle`. Warnings (build log, `branding_get`): master missing, smaller than 1024, not square, iOS
image with transparency (it is flattened on `background`).

| Platform | Generated (rtsbuild) |
|---|---|
| iOS | `gen/Assets.xcassets/AppIcon.appiconset`: iPhone 40..180, iPad 20..167, App Store 1024 + `Contents.json` (opaque) |
| macOS | `gen/AppIcon.iconset` (16..512@2x) and `gen/AppIcon.icns` (written by rtsbuild; `iconutil` re-packs it on a Mac) |
| Android | `res/mipmap-{mdpi..xxxhdpi}/ic_launcher.png`, `ic_launcher_round.png`, `ic_launcher_foreground.png` (+ `_background`, `_monochrome`), `mipmap-anydpi-v26/ic_launcher(_round).xml`, `values/ic_launcher_background.xml`, `app/src/main/ic_launcher-playstore.png` (512); manifest gets `android:roundIcon` |
| Windows | `gen/app.ico` (16, 20, 24, 32, 40, 48, 64 BMP + 256 PNG) and `gen/app.rc` (icon resource 1, also the window icon), compiled into the .exe |
| Web | `favicon.ico` (16/32/48), `favicon-32.png`, `apple-touch-icon.png` (180, opaque), `icons/icon-{192,512}.png`, `icons/maskable-{192,512}.png`, `manifest.webmanifest` (PWA); links injected into `index.html` |
| Linux | `share/icons/hicolor/<n>x<n>/apps/<exe>.png` (16..512) and `share/applications/<exe>.desktop` next to the executable |

### splash

```json
"splash": {
  "background": "#0a0f16",
  "image": "branding/splash_bg.png", "fit": "cover", "scale": 1,     // base layer (optional)
  "logos": [
    {"image": "branding/studio.png", "start": 0, "duration": 2.2, "scale": 0.34,
     "animation": {"fadeIn": 0.5, "fadeOut": 0.45, "zoom": {"from": 0.85, "duration": 0.8}}},
    {"image": "branding/logo.png", "start": 2.0, "scale": 0.55, "anchor": [0.5, 0.46],
     "animation": [{"t": 0, "opacity": 0, "scale": 0.7}, {"t": 0.6, "opacity": 1, "scale": 1, "ease": "out"}]},
    {"sheet": "branding/coin_sheet.png", "frame": [128, 128], "count": 8, "fps": 14, "start": 2.5, "scale": 0.2}
  ],
  "minSeconds": 3.5, "maxSeconds": 6, "loop": false, "skippable": true, "fadeOut": 0.5, "waitForContent": false,
  "progress": {"show": true, "color": "#e8b640", "track": "#ffffff26", "position": "bottom", "width": 0.36, "height": 5, "offset": 0.08},
  "native": {"image": "branding/logo.png", "background": "#0a0f16", "scale": 0.35, "androidIcon": "branding/splash_icon.xml"}
}
```

- **Layers** (base image first, then `logo` / `logos` in order, later on top): a static `image`, an
  animation from `frames` (list of images) or a sprite `sheet` (`frame` [w, h], `count`, frames in
  rows left to right) played at `fps` (`loopFrames`, default true). `fit`: `contain` (default for
  logos), `cover` (default for the base), `center` (image pixels × dpi), `stretch`; `scale`
  multiplies the fitted size; `anchor` is the centre on screen (fractions). `start` / `duration`
  in seconds (duration 0 = until the splash ends).
- **animation**: keyframes `[{"t", "opacity", "scale", "x", "y", "rotate" (degrees), "ease":
  linear|in|out|inOut}]` (t from the layer start; a property is interpolated between the keys that
  set it), or effects `{"fadeIn", "fadeOut", "fade", "pulse": amount | {"amount", "period"},
  "rotate": deg/s, "slide": "bottom" | {"from", "distance", "duration"}, "zoom": from | {"from",
  "duration"}, "keyframes": [...]}` — both combine.
- **Timing**: the splash leaves when loading is done and `minSeconds` have passed (default: the
  end of the last layer with a duration, so a studio logo → game logo sequence plays once);
  `maxSeconds` caps that minimum (never the loading). `loop`: repeat the sequence while loading
  takes longer. `skippable`: a tap / click / key ends the minimum. `fadeOut`: crossfade to the menu.
- **Progress bar**: real loading progress — the client's startup steps (rules, renderer, models
  and textures of every type, effects, audio, UI), and with `waitForContent` (split builds) the
  download of every pack chunk (`platform::contentProgress`).
- **In-engine splash**: drawn through the RHI from the first frame (`engine/splash`, one textured
  quad pipeline, GLSL + MSL; images decoded one per frame and capped at 2048 px), so it runs on
  any GPU. `RTS_SPLASH=off` loads the old way; with `--map` the splash only covers loading
  (`RTS_SPLASH=full` plays it all).
- **Native launch screen** (shown by the OS before the engine starts; a static image on a colour —
  `native`, else the first logo on `background`): iOS `LaunchScreen.storyboard` + `LaunchImage` /
  `LaunchBackground` in the asset catalog; Android 12+ splash theme (`windowSplashScreenBackground`,
  `windowSplashScreenAnimatedIcon`: the logo, or your animated vector drawable `androidIcon`) and a
  pre-12 `windowBackground` drawable, activity theme `@style/RtsLaunchTheme`; web: HTML/CSS splash
  in `platform/web/shell.html` with the `.data` download progress until the wasm starts; macOS and
  Windows: the window background colour.
- Split builds always keep the splash images in the base pack.
- **Defaults**: a game without a `splash` block gets the engine's loading screen — the RTSEngine
  mark assembling on `#0e0f11` with an orange progress bar (`splash::defaultBlock()`, art in
  `engine/assets/branding`); `"splash": false` shows only the background colour while loading.
  Without `icons` the build uses the RTSEngine mark on white (`branding::defaultIcon`). Both are
  drawn from one geometry: `tools/branding/logo/make_logo.py` (also the editor's icon,
  `apps/editor/branding`).
- Sample: `templates/skirmish` (art generated by `templates/_tools/brandart.py`, CC0).

## Recipes (mechanics of known games)

- **Warcraft III**: workers gather gold from mines and wood from trees (`resourceNode` + `gather`), `supply` from farms, `upkeep`, heroes with `hero` + `abilities`, creeps with owner -1 and `neutral.leash`, `bounty`.
- **StarCraft**: three factions with `buildMode` walk/warp/morph, larva `charges`, `creep`, refinery `structure.on` + `takesOverNode`, cliff `levels` + ramps + `heights.missUphill`.
- **Red Alert / C&C**: ore `fields` + harvesters + refinery `dropoff`, `fieldSpawner` mines, `power` capacity with `deficitDisables`, construction yard `produces` structures (sidebar), `deploysTo` MCV, `sellable`, `buildRadius`.
- **Dune II**: spice `fields`, `capped` spice with silos `storage`, `terrain: "rock"` for structures, sandworm `neutral.wander` + `move.layer: "sand"`.
- **Total Annihilation**: `flow` metal/energy with `income`, `costModel: "progressive"`, commander `key` + `victory: keyUnits`, extractors `structure.on: metal_spot`, `wreck` reclaim.
- **Age of Empires II**: four `stock` resources, farms with infinite `ownerOnly` nodes, ages as techs required by types, `techs` with tag effects.
- **Company of Heroes**: `squad`, `capture` points with `victoryPoint`, `victory: tickets`, `income` from captured points via triggers or `income` on point types.
- **They Are Billions**: map `waves` from a `waves: true` player, `victory: survive`, `buildRadius`.
- **Northgard**: `regions` with `claimCost` and `buildOnlyOwned`.
- **Z**: regions with `capture.region` flags, `productionPerRegion`, factories in sectors with `capturable`.
- **Mushroom Wars**: `garrison` structures, `roads` + `roadsOnly`, `entersGarrison` units, Send command.
- **Lane battlers**: `autoBuild`, `waveClock` + `waveSpawn`, `upgrades`, `victory: score`.
- **Dungeon Keeper**: `diggable` rock and gold veins, imps with `digs` + `claimer`, `territory.buildOnlyOwned`, painted `rooms` (lair `supply`, hatchery food `income`, library `work`), neutral `portal` with `claimedByTerritory`, creatures with `attractedBy` + `needs`, `hand`, `possession`, `victory: keyUnits` (dungeon heart).
- **Knights and Merchants / Settlers**: `"storage": "buildings"`, storehouses, `recipe` chains (woodcutter → sawmill, farm → mill → bakery), `carrier` serfs, `roadNetwork`, materials delivered to sites, `trainFrom` recruits, inn food `needs` with `starve`.
- **Mushroom Wars 2**: `garrison` villages + `lanes` instead of hand-made `roads`.
- **Territory war (State.io)**: `territory` with `claimBy: units` + `startFromRegions`, soldiers with `claim`, `capturable` towns, barracks with `autoTrain`, `playerAbilities`, repeatable `levels` techs, `victory: territory`.

Map size: 4..2048 cells per side. The editor saves `corners` inline up to 256x256 cells and as
`cornersFile` (`maps/<map name>.r16`, next to the map) above that; loaders (game, headless, editor, MCP) read
the file through the content reader, so it also works from packs.

## Terrain materials (visual `terrain` block)

Presentation only (`modules/rts/view/RtsTerrainRender.*`). Optional keys in the same `terrain` block as the overlays
(rules.json or game.json; game.json wins per key). **Without them every game looks exactly as before** (vertex
colours per cell kind, plateaus with sharp cliff walls, ramps, soft colour transitions, apron, one water sheet).

```json
"terrain": {
  "layers": [                                   // up to 4 tiling splat layers (world-space, mipmapped, wrap)
    {"id": "snow",  "texture": "textures/terrain/snow_repeat.png", "normal": "textures/terrain/snow_n_repeat.png", "scale": 6, "tint": [1, 1, 1]},
    {"id": "earth", "texture": "textures/terrain/earth_repeat.png", "scale": 4}
  ],
  "cells": {"grass": {"layer": "snow", "color": [0.9, 0.93, 0.97]},  // layer id, or {layer, color (vertex colour override)}
            "sand": "earth", "ramp": "earth", "rock": "earth", "blocked": "earth", "lakebed": "earth", "shallows": "earth", "dug": "earth"},
  "cliff": {"texture": "textures/terrain/rock_repeat.png", "normal": "textures/terrain/rock_n_repeat.png",
            "scale": 3, "tint": [1, 1, 1], "slope": [0.3, 0.55]},     // blended in where 1 - normal.y is in that range
  "splatStrength": 1,                           // 0..1: mix of the textures over the vertex colours
  "water": {"mode": "auto", "color": [0.22, 0.45, 0.62, 0.78], "offset": -0.12},
  "lod": "auto", "lodRange": 128                // heightfield maps: CDLOD on above 256 cells per side ("on"/"off")
}
```

| key | meaning |
|---|---|
| `layers` | splat layers (≤ 4): `texture` albedo (sRGB), optional `normal` (tangent-space, +Y up), `scale` world units per repeat, `tint`. Loaded with `TextureCache::resolve(path, …, tiling)`: **never taken from an atlas page** (name them `*_repeat.png` so the packer skips them too) |
| `cells` | cell kind → layer id or index; kinds: `grass` (.), `sand` (, no-build), `ramp` (/), `rock` (R), `blocked` (#), `lakebed` (~), `shallows` (=), `dug` (diggable rock floor). `color` overrides the vertex colour of the kind on every tier |
| `cliff` | texture on cliff walls and steep slopes (Medium: one projection, High: triplanar + normal map) |
| `water.mode` | `sheet` = one plane under the whole map (classic, default for cliff-level maps), `bodies` = each connected water area gets its own surface just below its lowest shore (lakes on plateaus, valleys of heightfield maps; default for heightfield maps), `auto` |
| `lod`, `lodRange` | big heightfield maps: chunks drawn with 2^k cell steps (k ≤ 4) by camera distance, geomorphing in the vertex shader, skirts against cracks |

**Map key `terrainMaterial`** (optional, visual): rows of `0`..`3` (layer index) per cell, other characters = by cell
kind. Painted with the editor's **Рельеф** window or `terrain_material`.

**Quality tiers** (pause menu *Ground textures*, `Renderer3D::materialQuality()`, capped by the device default;
`RTS_TERRAIN=low|medium|high` overrides for testing): Low = vertex colours (weak Mali / Adreno / PowerVR, also every
game without `layers`), Medium = splat textures + cliff texture, High = + normal maps and triplanar cliffs. Shaders:
`modules/rts/view/RtsTerrainShaders.h` (GLSL + MSL, sun + soft shadows + point lights + clouds as the lit shader).

**Performance**: the terrain is cut into 32x32-cell chunks, frustum-culled; the editor rebuilds only chunks whose cells
changed; during a match nothing is rebuilt: resource fields, creep and (heightfield maps) fog of war are read by the
shader from small per-cell textures. `RTS_TERRAIN_STATS=1` prints chunks / triangles / frame time. Sample:
`templates/frostcrown` (generated CC0 textures, `tools/terrain/make_textures.py`).

**Editor / MCP** (heightfield maps, `apps/editor/core/TerrainOps.cpp`, window **Рельеф**):
`terrain_sculpt {op: raise|lower|smooth|flatten|noise|set, x, y | points, radius, strength, seed}` (the first sculpt
creates corners from the visible surface: cliff levels, ramps, fine heights), `terrain_heights {points | grid}`,
`terrain_material {layer, x, y, radius}`, `heightmap_export {file, scale?}` / `heightmap_import {file, scale, offset}`
(16-bit grayscale PNG, `(w+1) x (h+1)` pixels, height = offset + value / 65535 * scale). Corners are visual unless
rules `terrain.model` is `heightfield` (see below).

### Detail surface (sub-cell relief)

`"terrain": {"style": "smooth"}` in rules.json / game.json draws the terrain from a visual heightmap with several
samples per cell instead of one height per cell corner: bevelled cliffs with organic outlines, rounded plateaus and
ramps on cliff-level maps, bicubic relief with fine noise on heightfield maps, per-pixel lighting, materials blended at
sub-cell resolution with automatic rock on steep slopes. Default `"classic"` keeps the old look. A map can carry its
own painted detail: `terrain.detail` = `{"scale": 4, "file": "maps/<name>.detail.r16", "splat": "..."}` (int16 LE,
1/16 units, `(w*k+1) x (h*k+1)`). Tuning keys `terrain.detailLook`. Editor / MCP: `terrain_detail`, `terrain_sculpt`
(sub-cell, erode, stamp), `terrain_paint_material`, `heightmap_import/export {detail: true}`. Full description and
numbers: `docs/terrain.md` § Detail surface. Samples: `starfall` (cliffs), `metaltide` (relief), `frostcrown`.

## Heightfield terrain

`rules.terrain.model: "heightfield"` + a map with `terrain.corners` / `cornersFile` (without corners the map
plays like `"levels"`). Corner `(x, y)` is the top-left corner of cell `(x, y)`; heights in 1/16 world units.
Everything is integer / fixed point and deterministic.

- **Surface**: ground height at any point is bilinear between the 4 corners of its cell; ground units (and the
  `y` of every mobile unit) stand on it; projectiles start at the shooter's ground + 0.6 and aim at the
  target's ground + 0.4.
- **Slopes**: per cell steepness = max(gradient length, steepest cell edge), in height units per cell.
  A unit can't enter cells steeper than its `move.maxSlope` (or `terrain.maxSlope` of its layer; `sand` for
  `layer: "sand"`); pathfinding, local avoidance and spawning follow the same rule. Cliff/ramp rules
  (`levels`, `/`) are replaced by slopes. Structures need cells no steeper than `terrain.buildSlope`.
- **Speed**: `speed * (1 - uphillSpeed * climb)` going up, `* (1 + downhillSpeed * descent)` going down, where
  climb/descent = height change per cell along the move; clamped to 0.25..2.
- **Vision**: line of sight from `eyeHeight` above the unit's cell to `targetHeight` above each cell in sight
  range; a cell behind a ridge is hidden (`heights.blockVision: false` turns this off, air units see over).
  Targeting only picks enemies in a cell the player sees.
- **Cliff level** of a cell = floor(cell height / `levelHeight`) (0..9), so level-based rules and triggers keep
  working. Range / damage / miss bonuses use the exact height difference (see `heights`).
- **Checksums**: corners and the model are part of the state hash only for heightfield games.
- **Big maps** (256x256 cells and more): long paths use hierarchical pathfinding (16x16 clusters with border
  entrances, refined with A*), built at match start and rebuilt only around structures that block cells.
  `rts_headless --project DIR --bench-paths N` times path queries; `python3 templates/_tools/mapgen.py --big 1024
  <scratch>/maps/big.json` writes a 1024x1024 test map (keep it out of `templates/`).

MCP: `map_info.heightfield` (`corners`, `min`, `max`, `storage`, `model`), `map_heightfield {"enabled"}` adds a flat
heightfield or removes it, `map_validate` warns when the model is heightfield but the map has no corners and flags
units/structures standing on slopes too steep for them. Sculpting: `terrain_sculpt`, heightmap PNG import/export (see Terrain materials). The view draws the relief from the corners (two triangles per cell, diagonal (0,0)-(1,1)); `RtsView::heightAt` follows the same triangles, so models and overlays sit on the drawn ground.

## Planets: visual keys (map `world` block)

The bodies themselves are described in `docs/planets.md` §1-2 (`world.bodies`, `kind`, `radius`, `faceSize`,
`seaLevel`, `orbit`, `terrain.faces` / `terrain.corners`). What only the view reads:

```jsonc
{"id": "terra", "kind": "planet", ...,
 "visual": {"color": [255, 220, 160],                        // stars: light colour and glow; others: far-away tint
            "atmosphere": {"color": [110, 170, 255], "height": 0.08}}}   // or false; default: on for planets, off for moons
```

- `visual.atmosphere.height`: shell thickness as a fraction of the radius (0.005..0.5). The shell and the haze use the
  colour; the shell is drawn from the Medium material tier up.
- `terrain.faces[f].material`: rows of digits `0`..`3` per face (`.` = by cell kind), like the flat map's
  `terrainMaterial`; painted by `terrain_material` with `body`.
- Ground look on planets = the visual `terrain` block of the game (layers per cell kind, cliff texture, water colour).
- Ground overlays on planets use the same visual `terrain.territory` / `dig` / `roads` / `lanes` blocks as flat maps
  (territory fill and borders, rock blocks with veins / gems and dig marks, road cells, lanes and map `roads` between
  buildings draped on the surface). Territory, diggable rock (`diggable` characters in `terrain.faces[f].rows`), rooms,
  claims, capture and lanes work on planets with the same rules keys (docs/planets.md §3).
- Editor / MCP: `planet_info`; `terrain_sculpt` / `terrain_paint` / `terrain_material` with `body` + `face` + `x`, `y`
  (cells on that face) or `dir` [x, y, z] and `radius` in cells (3D brush, crosses face seams).

## Planets: simulation keys (map `world` block)

A map with a `world` block is a planet map: the bodies replace `size` / `terrain` / `fields` (docs/planets.md).
Flat maps are untouched (same checksums).

```jsonc
"world": {"start": "terra", "bodies": [
  {"id": "sun", "kind": "star", "radius": 40},
  {"id": "terra", "kind": "planet", "radius": 16, "faceSize": 24, "orbitAltitude": 4,     // shell of move.layer "orbit"
   "orbit": {"around": "sun", "radius": 400, "period": 1200, "phase": 0.1},               // seconds, turns
   "terrain": {"faces": [{"rows": [...], "levels": [...], "fields": {"metal": ["..19.."]}}, ... 6 faces],
               "corners": [ ... 6 * (N+1)^2 ... ] | "cornersFile": "maps/x.terra.r16"}}]},
"players": [{"name": "Blue", "start": {"body": "terra", "face": 4, "x": 12.5, "y": 12.5}}],
"entities": [{"type": "metal_spot", "at": {"body": "terra", "face": 4, "x": 7, "y": 8}}],
"waves": [{"at": {"body": "terra", "face": 0, "x": 3, "y": 3}, ...}]
```

- `kind`: `planet`, `moon` (surface: `faceSize` 2..512), `star` (no surface). `radius` 2..1200, radius + orbitAltitude
  <= 1500; `orbitAltitude` default 0.15 x radius. `orbit.around` must name an earlier body. At most 16 bodies.
- Visual detail per body (`docs/terrain.md` "Planets"): `terrain.style` (`smooth` / `classic`, default the game's),
  `terrain.detailLook {scale, roughness, craters}`, `terrain.detail {scale, file}` (int16 LE 1/256 units, 6 x
  (faceSize*scale+1)^2, written by the editor). Presentation only: the simulation and checksums ignore them.
- Positions on planet maps are `{body, face, x, y}` (cell coordinates on that face, 0..faceSize); `[x, z]` is an error.
  Fields per face (`fields` in a face: digit rows per resource) or `fields: [{center: {body, face, x, y}, radius}]`.
- Per-face rows / levels use the flat-map characters; `rules terrain.model: "heightfield"` makes corners drive slopes
  (rise per world unit), speed and line of sight, exactly like flat heightfield maps.
- `cornersFile`: raw int16 LE, faces 0..5 each (N+1)^2 row-major; the editor writes it for bodies above 257² corners.
  Seam corners must be equal on every face that stores them (map_validate warns; the loader averages).
- Units: `move.layer: "orbit"` (flies on the orbit shell, free great-circle moves, sees the surface below, can be hit
  only by weapons whose `targets` list `"orbit"`), `move.transitSpeed` (world units/s for transfers; default 10 x speed).
- Command `kCmdTransit` (units = orbit units, `param` = target body index): timed transfer computed from the body
  positions at departure, arrival on the facing side of the target's shell; events `kEvTransitStart` / `kEvTransitEnd`.
- Rules `movement.planetHpaCells` (default 65536): bodies with at least that many cells (6 x faceSize²) use hierarchical
  pathfinding for long trips (0 = every body).
- Structures stand inside one face (a footprint crossing a seam is not buildable). Units on different bodies only meet
  through the orbit layer. Sample: `templates/planets`.

## Map generation (`generate`)

A map can be generated by the engine instead of (or before) being drawn by hand: deterministic integer code
(`modules/rts/gen/`), so the same request gives a **bit-identical map on every platform**. It runs at match start
(lockstep multiplayer, server arbiter, headless, replays: every peer regenerates the same map from the match seed),
in the editor (window **Генерация**) and over MCP (`map_generate`, `gen_presets`), where the result can be baked
into a static map.

```jsonc
"generate": {
  "preset": "continents",          // gen_presets: built-in + rules "mapgen.presets"
  "seed": "match",                 // "match" = the match seed (a new map every match), or a number (fixed map)
  "players": 4,                    // 1..8; the map's players array is resized to it (names/factions/teams kept)
  "symmetry": "auto",              // auto | none | point | mirror | mirror-y | mirror4 | rot4 | rotational
  "template": "maps/valley.json",  // optional: map whose player-1 objects are the start kit and whose neutral objects decide what is placed
  "params": {"water": 0.3, "trees": 1.5}   // overrides of the preset's params
}
```

- Flat maps: top-level `generate`. Planets: `world.bodies[].generate` (presets `rocky`, `ocean`, `moon`; see docs/planets.md §4).
- What the generator writes: `size`, `terrain.rows` (`.` `~` `#` `,` `=` `/` `R`, diggable characters for caves), `terrain.levels`
  (rules `terrain.model` `levels`), `terrain.corners` (`heightfield`), `fields`, `entities`, `regions` (if the template has them),
  `roads` (garrison games), `terrainMaterial` (from the biome and the game's visual `terrain.layers` ids: grass / forest / sand /
  dirt / earth / rock / snow / mud ...), players' `start`, and a summary block `generated` (preset, seed, symmetry, starts, path
  lengths between starts measured with the engine's A*, `connected`, `pathSpread` in per mille, object counts, `warnings`).
  Every other key of the map (victory, triggers, waves, lighting, ...) is kept.
- **Objects come from the game's own types**: player 1's objects of the template (or of the map itself) are the start kit, placed
  for every player in the symmetric frame (rotated by quarter turns so footprints stay aligned); neutral objects are counted
  near the template's bases / far / at the centre and placed the same way (mines and metal spots near each base, forests in
  forest biomes, creep camps away from bases, garrison buildings, portals...). Without a template the rules decide: a
  structure that produces workers + 4 workers (or a `key` unit, or the biggest garrison), resource nodes, `structure.on`
  spots, field spawners, `neutral` creeps. Resource `fields` of the template are reproduced (near ones keep their offset).
- **Fair starts**: the start of player 1 is chosen in the fundamental domain of the symmetry and copied to every image; base
  areas are flattened (one cliff level / gentle corners, never water); starts are connected (ramps cut through cliffs,
  shallows `=` through water, a graded road on heightfields, the cheapest route through diggable rock); objects never block
  the route between starts (an unblock pass removes them); the result is validated with the pathfinder. `"connect": "none"`
  keeps islands separate (naval / air games).
- **Determinism**: integers / `Fixed` only (no float), seeded hashing, ordered containers; the generator runs inside
  `RtsModule::setup` before the map is loaded, so replays and the server arbiter regenerate identically. Golden hashes of
  the presets are in `tests/tests.cpp` (`gen_golden_maps` and friends): a change of the generator's output shows there.
  Same seed + params + engine version = same map.

### Presets

| id | shape | for | main params (defaults) |
|---|---|---|---|
| `continents` | continents | any land/naval game | `size` [96,96], `water` 0.4, `rivers` 0.5, `levels` 1, `connect` shallows, `shallows` 0.6 |
| `islands` | islands | naval / archipelago | `size` [96,96], `water` 0.62, `islands` 4 (neutral islands), `islandSize`, `connect` shallows |
| `highlands` | highlands | any | `size` [80,80], `ridged` 0.7, `levels` 2, `peaks` 0.9 (cells above this land quantile are `#`), `relief` 10 |
| `canyons` | canyons | any | `size` [80,80], inverted ridged noise, `levels` 2, `plateau` 0.6, `scale` 30 |
| `classic` | classic | Warcraft / Red Alert land maps | `size` [64,64], `water` 0.1, `rivers` 0.4, `levels` 1, `plateau` 0.3 |
| `metal` | highlands | Total Annihilation (heightfield, metal spots) | `size` [72,72], `relief` 6, `levels` 0, `baseRadius` 12, `thermal` 10, `erosion` 4 |
| `caves` | caves | Dungeon Keeper (`diggable`) | `size` [48,32], `gold` 0.03 / `gems` 0.004 (share of rock that is a vein / infinite seam), `bedrock` 0.06, `caverns` 0.06 |
| `lanes` | lanes | lane battlers / MOBA | `size` [32,64], `lanes` 3, `laneWidth` 4, `bend` 0.35 (rock everywhere else) |
| `field` | lanes, `open` | Mushroom Wars 2 (garrisons + roads) | `size` [44,28], `obstacles` 0.12, `roads` from the template |
| `rocky` / `ocean` / `moon` | planet | whole planet maps, or one body's terrain | `faceSize`, `water` 0.25 / 0.7 / 0, `relief`, `ice` (polar caps), `craters` (moon), `layout`, `moonResources`, `baseRadius` (moon 11) |

**Planet maps.** A planet preset as the map's `generate` builds the whole `world` block: the bodies (and their orbits,
visuals) come from the template map's `world` (e.g. `templates/planets`), else a sun + planet + moon. Every surface body
gets per-face `rows`, `corners`, `material`; players get `start: {body, face, x, y}`; objects are written with `at`.
- `layout: "shared"` (default): all players on the start body, rotational symmetry about the polar axis: exact for 2 and 4
  players (half / quarter turns map the cube-sphere onto itself, heights are symmetrized corner by corner), averaged over the
  rotations for 3, 5+ (`generated.symmetry`: `polar-exact` / `polar`). Starts near the equator in the middle of each longitude
  sector, away from face seams and rough ground; base areas flattened; graded causeways where the ground doesn't connect.
- `layout: "separate"`: every player on an identical planet of its own (same terrain, same objects), orbiting the star at
  equal phases; players meet through orbit-layer units (warning when the rules have none).
- Objects: the template's player-1 objects (offsets measured on its body, across face seams) are the kit; neutral objects
  near the template bases / far / on moons are counted and reproduced (`objects[].moon`, `objects[].pole`); moons get
  `moonResources` (default 2) x their share. `generated.nearResources` lists the resource objects within `nearRadius` of
  each start (equal by construction; a warning otherwise).
- Fairness: the generated map is loaded into a simulation and the engine's `MapGrid::findPath` measures the ground path
  between every pair of starts (`generated.paths`, `connected`, `pathSpread` = spread of each player's distance to the nearest
  rival, per mille).
- One body only: `world.bodies[].generate` (terrain + reported start sites, no objects), as before.

`rts_headless --project templates/planets --generate rocky --seed N --players 3 [--gen-params '{"layout": "separate"}']`.

All params (any preset): `shape`, `size` [w, h] (16..1024; the map's own size wins unless `params.size` is given), `water`
(share of corners below sea level), `rivers` (0..1: flow accumulation carved into rivers), `lakes` (pit depth that stays a lake),
`shallows` (water this close to the surface becomes `=`), `levels` (cliff levels 0..9), `plateau`, `peaks`, `relief` (world units),
`scale` (feature size in cells), `octaves`, `roughness`, `ridged`, `warp` (domain warp), `thermal` / `talus` (thermal erosion),
`erosion` / `erosionRate` (stream-power erosion), `moisture`, `temperature`, `latitude` (biomes), `baseRadius`, `startSpread`
(0.2..1 of the largest possible distance between starts), `startJitter`, `starts` [[x, y], ...] (explicit), `kit` [{type, offset,
count, garrison}], `objects` [{type, near, far, centre, owner, garrison, amount}] (override per type), `trees` / `resources`
(count multipliers), `nearRadius`, `fieldRadius`, `fieldsFar`, `regions` / `regionsPerPlayer` (Voronoi regions), `roads`, `connect`
(`ground` | `shallows` | `none`), `border` (blocked rim), `fineHeights` (visual per-cell heights inside a level), `visualCorners`
(write corners on non-heightfield games), `maxPathSpread` (warning threshold without symmetry, per mille).

Games add presets in rules.json: `"mapgen": {"presets": {"my_valley": {"title": "Долина", "base": "classic", "params": {"water": 0.2}}}}`.

**Tools**: `rts_headless --project DIR --generate PRESET [--seed N] [--players N] [--symmetry S] [--gen-params JSON] [--gen-out F]
[--max-seconds 0]` (the open map is the template; `--record` writes `<replay>.map.json` next to the replay so `--replay` regenerates).
Editor: window **Генерация** (preset, seed, players, symmetry, params; *Сгенерировать* bakes, *При старте матча* writes
`"seed": "match"`). MCP: `gen_presets`, `map_generate {preset, seed, players, symmetry, params, mode: bake | match | fixed,
useTemplate, keepSize}`.
## Fidelity mechanics (play like the original)

Optional blocks that make the sample games play like their originals (`modules/rts/RtsOriginals*.cpp`). A game that
uses none of them keeps its exact checksums. These blocks are the single implementation of their mechanic: the
agent-mech spellings of the same mechanics (`armorModel`, type `shields`, `upkeepResources`, `resourceNode.maxWorkers`,
`"crew": {"accepts"}`, `upgradeGarrison`) are aliases parsed into them (see the agent-mech sections above).

| block | where | meaning |
|---|---|---|
| `armor` (alias `armorModel`) | rules | `{"model": "subtract" \| "percent" \| "classes", "perPoint": 0.06, "minDamage": 1, "minShare": 0.2, "negative": "linear" \| "exponential", "base": ["melee", "pierce"]}` — the one damage pipeline of every game: weapon `bonus`, shields, then the model. `subtract`: StarCraft / AoE with a floor (no block at all: damage - armor, at least damage / 5); `percent`: Warcraft III (reduction = a·k / (1 + a·k)); `classes`: AoE II class attacks / armors (type `armors`, weapon `attacks`, see the agent-mech aliases above) |
| `health.armor` object | type | `{"melee": 1, "pierce": 2}` (or `health.pierceArmor`): two armors; weapons pick one with `"armorClass": "pierce"`; stat `pierceArmor` / `armor2` for techs |
| weapon `bonus` | type | `{"cavalry": 15, "armored": 10}` extra damage vs types with the tag, added before armor (AoE / SC2 bonuses) |
| `health.shields` (alias type `shields: {max, regen, delay, armor}`) | type | shields soak damage first (after the damage table and weapon bonuses; minus `shieldArmor`, at least the armor floor), the share that breaks through goes on to armor and hp; they recharge `shieldRegen` per second (default 2) after `shieldDelay` seconds (default 10) without a hit on the shield (StarCraft) |
| `heroes` | rules | `{"skills": true, "max": 3, "freeFirst": true, "tiers": ["hall", "keep", "castle"], "revive": {"costShare": 0.4, "perLevel": 0.1, "timeShare": 0.6, "maxTime": 110, "maxCost": {"gold": 700}}}` — skill points (one at start, one per level; command `kCmdLearn`), ability `"learnAt": [1, 3, 5]` (default) / `[6]` (ultimate); hero n needs a structure from `tiers[n-1..]`; a dead hero is trained again as a revive (its level and skills, cheaper) |
| `upkeep[].resources`, `incomeMult` (alias `upkeepResources`) | rules | upkeep only on some resources (WC3 gold) and / or on per-second income (CoH manpower); rules `"upkeepResources": ["gold"]` is the default `resources` of every tier without its own |
| `resourceNode.maxGatherers` (alias `maxWorkers`) | type | workers harvesting at once (WC3 mine 5, SC patch 1); the others wait or take a free node nearby |
| `powerField` / `structure.needsField` | type | `{"id": 0, "radius": 6.5}` on pylons; structures with `needsField` are placed and work only inside an own field |
| `queueSlots` | type | items produced at once (reactor) |
| `cost.garrison` (alias `upgradeGarrison`) | type | upgrading / converting into this type costs units of the garrison (Mushroom Wars 2) |
| `garrison.onCapture`, `garrison.keep` | type | type it drops to when captured (loses a level); units that always stay home when sending (State.io) |
| `clash` | type | units in transit fight hostile units they meet |
| `playerMods` | type | `{"max": 4, "mods": [{"tags": [...], "stat": "damage", "mul": 1.08}]}` — every completed one modifies the owner's types (forges) |
| resource `gain`, `perUnit`, `min` | rules | `"gain": {"kill": 1, "capture": 0.3, "captured": -0.4, "upgrade": 0.2, "lost": 0.45, "defended": 0.01}`; `"perUnit": [{"tags": [...], "stat": "damage", "mul": 1.06}]` per whole unit held (morale suns) |
| `crew` / `crews` / weapon `killsCrew` | type | `"crew": "grunt"` (or `{"unit": "grunt"}`): vehicles and guns with a driver; `killsCrew` (chance per non-lethal hit) empties them (owner 0); units with `crews` man any empty one (Z). `"crew": {"accepts": [tags]}` / `true` (agent-mech alias): units with one of the tags (any mobile unit) may man it too |
| `infect` | type | `{"by": ["infected"], "spawn": "walker", "count": 3}` — killed by a unit with the tag: rises as the spawn type for the killer (They Are Billions) |
| `neutral.eats`, `neutral.resurface` | type | an eater submerges after that many kills and comes back somewhere on its layer later (Dune sandworm) |
| `crush` | type | `{"tags": ["infantry"]}` — moving over such units kills them (tanks over infantry, units over spice blooms) |
| `deathField` | type | `{"resource": "spice", "radius": 4, "amount": 120}` — dying spreads a resource field (spice bloom) |
| `onDeath` | type | payload where it dies (commander explosion) |
| `factions` | type | only these factions may train / build it (Dune houses, RA sides) |
| `requiresRegions` | type | trainable only with this many own regions (Z factory levels) |
| `ownsRegion` | type | its region (and the territory cells) take its owner's colour (State.io) |
| `autoTrain.advance` | type | `false`: auto-trained units stay home (Northgard births) |
| `cost.growth` | type | cost × (1 + growth × owned) (Dungeon Keeper imps) |
| tech `requiresAny` | rules | `{"count": 2, "of": [types]}` — that many different buildings (AoE ages) |
| `regions.requireExplored`, `clearFirst`, `supplyLines` | rules | claim only scouted / creep-free regions (Northgard); points pay only in sectors linked to an own key structure (CoH) |
| `territory.incomePerCell` | rules | income per owned cell (Dungeon Keeper mana) |

Recipes of `storage: "player"` games (no goods in buildings) take their inputs from the player stock and credit the
outputs to it: buildings that gather around them (They Are Billions sawmills, Northgard lodges).

### Foundations, traps, group teleports, charges (`RtsFidelity.cpp`)

```json
"foundation": {"startHp": 0.5, "decay": 0.25, "floor": 0.5, "lostWithBuilding": true},   // or just true
"types": {
  "concrete": {"structure": {"footprint": [1, 1], "terrain": "rock"}, "foundation": true, "cost": {"credits": 5, "time": 2}},
  "wall":     {"weathers": false, ...},
  "gas_trap": {"structure": {"footprint": [1, 1]}, "health": {"max": 200},
               "trap": {"radius": 0.8, "charges": 5, "rearm": 8, "armTime": 0, "hidden": true, "revealFor": 4, "removeWhenEmpty": true,
                        "layers": ["ground"], "tags": ["hero"],                          // trigger filter (effect filter keys; or "trigger": {...})
                        "effects": [{"type": "area", "radius": 2, "lifetime": 5, "trigger": "periodic", "effects": [{"type": "damage", "amount": 18}]}]}},
  "queen":    {"abilities": [{"id": "inject", "target": "unit", "energy": 25, "smart": "ownProducer",
                              "effects": [{"type": "status", "status": "injected", "duration": 29, "affects": "own", "kind": "structure"}]}]}
},
"statuses": {"injected": {"onExpire": [{"type": "addCharges", "amount": 3, "limit": 19, "affects": "own"}]}},
"playerAbilities": [{"id": "chronoshift", "target": "pointPair", "effects": [{"type": "teleportGroup", "radius": 1, "maxTargets": 1, "tags": ["vehicle"], "affects": "own", "duration": 180}]}]
```

- **Concrete (Dune II)**: a placed `foundation` structure turns its cells into the owner's concrete (`MapGrid::foundation`,
  drawn by the view's `terrain.concrete` block: `color`, `seam`, `alpha`, `texture`) and goes away (event `kEvPaved`).
  Concrete doesn't block anything. A structure finished with b = share of its cells not on own concrete gets at most
  `1 - b·(1 - startHp)` of its hp and weathers by `decay·b` of its max hp per minute down to `1 - b·(1 - floor)`
  (repairs raise it, the weather keeps going). `weathers: false` exempts a type. Structures of the starting map stand on
  concrete; a destroyed structure takes its concrete with it (`lostWithBuilding`). Flat maps only. The AI keeps a few free
  paved cells near the base and places its buildings on concrete first.
- **Traps**: a structure with `trap` fires its `effects` at the nearest unit passing the trigger filter (enemy ground and air
  units by default) within `radius` (target = the victim, point = its position, caster = the trap), then waits `rearm`
  seconds; `charges` (0 = unlimited) run out and the trap disappears (`removeWhenEmpty`). `hidden` traps are invisible to
  enemies (not targeted, not drawn) except for `revealFor` seconds after firing and to detectors. Event `kEvTrapFired`
  (a = trap, b = victim). The AI builds a few traps at the front of its base, more as the match goes on.
- **Group teleport**: see the `teleportGroup` effect; `pointPair` player abilities take two clicks (from, to); the second
  point travels in `kCmdPlayerAbility` param bits 16..48 (`RtsModule::packPoint2`). Event `kEvGroupTeleport` (a = unit,
  value 1 = return trip). The AI shifts its biggest matching group next to the nearest enemy structure.
- **Smart rule `ownProducer`**: autocast / AI target: an own structure without the payload's status that has larva
  charges (when the payload, or the status it gives, adds charges) or something in production (chrono boost:
  a status with `{"stat": "productionSpeed", "mul": 1.5}`).

## Sample games (data only, `<project>/`; maps from `templates/_tools/mapgen.py`)

| id | like | recipe |
|---|---|---|
| `frostcrown` | Warcraft III (Orcs) | percent armor, upkeep on gold, hall tiers, 3 heroes with learned skills / free first / revive, 5 peons per mine, creeps |
| `starfall` | StarCraft II | Protoss warp + shields + pylon fields + chrono boost + recall, Zerg morph + larva + inject + creep, Terran add-ons (tech lab / reactor), attribute bonuses, 1 worker per patch |
| `ironfront` | Red Alert | Allies / Soviets, sidebar, ore + gems, silos, power, engineers, Tanya, superweapons incl. the Chronosphere, crush |
| `ambersands` | Dune II | houses, bases on rock, concrete slabs and weathering, spice without regrowth, blooms, sandworms that eat and resurface, crush, palaces |
| `metaltide` | Total Annihilation | Arm / Core, flows, progressive cost, D-gun, commander explosion, metal makers, heightfield |
| `fourages` | Age of Empires II | four ages (requiresAny), melee / pierce armor and bonuses, AoE II gather rates, finite farms, techs |
| `holdtheline` | Company of Heroes | US / Wehrmacht, sectors with supply lines, tickets, squads, manpower upkeep |
| `lastcolony` | They Are Billions | buildings gather, workers / food / energy, tesla grid, stake / blade traps, infection, final wave |
| `clanlands` | Northgard | scouted and cleared regions, births, production in buildings, warband from villagers, happiness |
| `flagsectors` | Z | flags, free factories with levels, drivers and empty vehicles / guns, fort |
| `laneclash` | lane battler | `autoBuild` pool, `waveClock` + `waveSpawn`, `upgrades`, `victory: score` with `keyLoses` |
| `underlord` | Dungeon Keeper | `diggable` rock/gold/gem, imps with `digs` + `claimer`, `rooms`, neutral `portal` + `claimedByTerritory`, creatures with `attractedBy`, `needs` and hero levels from training, `hand`, `possession`, leveled tech paid in research |
| `borderrush` | State.io (portrait) | `territory` with `claimBy: units` + `startFromRegions`, soldiers with `claim`, `autoTrain` capital and towns, `capturable` towns, `playerAbilities` (air strike, drones with charges), leveled techs incl. `productionSpeed`, `victory: territory` |
| `hearthhaul` | Knights and Merchants | `storage: buildings`, storehouse, recipe chains (woodcutter → sawmill, farm → mill → bakery, armoury), serf `carrier`s, `roadNetwork`, delivered construction materials, `trainFrom: recruit`, inn `needs` with `starve` |
| `sporelanes` | Mushroom Wars 2 | `garrison` hives/huts/towers, `lanes` instead of `roads` |
| `planets` | Total Annihilation on planets | metaltide rules on a planet + moon (`world` block, `at` positions), `orbital_yard` → `gunship` (`move.layer: orbit`, `transitSpeed`), defender weapons with `targets: orbit`; map from `templates/_tools/planetgen.py` |
| `spellbunkers` | Bunker Wars / Mushroom Wars 2 skills | sporelanes + mana/morale `regen`, named `statuses`, 26 player skills (structure / group / player targets, areas moving along lanes, chains over structures), per-player `loadout` of 16, an `autoEvery` map skill and a `passive` |
| `shroomwars` | Mushroom Wars 2 | levels and conversions paid with units, forges, clashes, morale, energy, hero skill sets |

## 2D games

Still the 3D engine, seen through an orthographic camera; objects can be sprites and the ground a
tile map. Two flavours, both pure data (samples: `templates/tiles2d`, `templates/km2d`; their placeholder
art is generated by `tools/art2d/make_samples.py`):

- **Tile 2D** (Red Alert, Dune II, Warcraft II): `camera` straight down (`pitch: 90`), a map
  `tiles` layer drawn from a tileset, sprite units and buildings (`"mode": "ground"`).
- **3D terrain + sprites** (Knights and Merchants): the normal terrain (levels, ramps, heights),
  `camera` at a fixed angle (`pitch: 50`), billboard sprites standing on the ground.

### game.json `camera`

| key | meaning |
|---|---|
| `projection` | `"ortho"` or `"perspective"` (default) |
| `pitch`, `yaw`, `fov` | degrees; pitch 90 = straight down, yaw 0 = north up |
| `zoom`, `zoomMin`, `zoomMax` | start/limits: visible map cells vertically (ortho) or camera distance (perspective); without `zoom` the game frames the map |
| `pixelsPerCell` | ortho: start zoom so that one world unit is that many screen pixels (pixel-perfect sprites drawn with the same `pixelsPerCell`) |
| `rotate` | allow camera rotation (default: false for ortho) |

The editor uses the projection and angle for its Scene and Game views.

### type `sprite`

```json
"tank": { ...,
  "sprite": {"sheet": "sprites/tank.png", "frame": [32, 32], "facings": 8, "mirror": false,
             "mode": "billboard", "pixelsPerCell": 32, "anchor": [0.5, 1.0], "offset": [0, 0],
             "team": "magenta", "filter": "nearest", "depthBias": 1.0, "lift": 0,
             "shadow": {"size": [0.8, 0.45], "alpha": 0.35}, "corpseTime": 4,
             "actions": {"idle": [0, 1], "move": [1, 4, 8], "attack": {"start": 5, "count": 2, "fps": 6},
                         "work": [5, 2, 4], "build": {"start": 1, "count": 4, "loop": false}, "die": [7, 3, 6]}}}
```

| key | meaning |
|---|---|
| `sheet` | image (PNG/JPEG/TGA), required. **Rows = facings** (row 0 faces east/+X, then clockwise on screen: SE, S, SW, W, ...), **columns = animation frames** |
| `frame` | frame size in pixels (default: whole sheet width, square — give it for single images that are not square, otherwise the frame reaches past or stops short of the image) |
| `facings` | 1, 4, 8, 16, 32... rows; `mirror: true` stores only north → east → south (`facings/2 + 1` rows) and flips them for the west side |
| `actions` | column ranges `[start, count, fps]` or `{"start", "count", "fps", "loop"}`. `idle`, `move`, `attack`, `work` (gathering/building workers), `build` (structure under construction; non-looping = frame follows the progress), `die` (played where the object disappeared, then the last frame stays `corpseTime` s). Missing actions fall back to `idle` (`work` → `attack` → `idle`) |
| `mode` | `billboard` (faces the camera; default), `upright` (vertical quad), `ground` (lies on the terrain; top-down games) |
| `size` / `pixelsPerCell` / `scale` | world size: `[w, h]` cells, or frame pixels / `pixelsPerCell`; default width = footprint width (structures) or 1 |
| `anchor` | pivot in the frame, 0..1 from the top-left (default `[0.5, 1]`, ground mode `[0.5, 0.5]`) |
| `offset` | `[right, front]` cells from the object centre; default for standing structures: the front edge of the footprint, so a 3/4-view drawing stands on its footprint |
| `team` | `"magenta"` (default): pixels in shades of magenta (r = b, g = 0) become the player's colour times their brightness; `"none"` |
| `shadow` | `"cast"` (real sun shadow, see below), `"blob"` (soft ellipse under the sprite), `"none"`; `true` = blob, `false` = none; the object form `{"mode", "size": [w, h], "alpha"}` is a blob unless `mode` says otherwise (`size`/`alpha` also shape the blob that replaces a cast shadow on low tiers). Default: the game's `sprites.shadow`; with the default `"blob"` only units get one (as before), ground sprites never cast |
| `castHeight` | world height of the shadow caster (default: the drawn height). 3/4-view buildings whose drawing includes the roof seen from above cast a long shadow with the full height: give the real wall + roof height |
| `shadowOffset` | `[right, front]` cells added to the sprite's `offset` for the caster (default: the caster stands where the sprite is drawn — for buildings the front edge of the footprint) |
| `castDepth` | buildings cast like a box: a second caster this many cells behind the first (default: the footprint depth for structures, 0 for units) |
| `lit` | override of the game's `sprites.lit` for this type |
| `depthBias`, `lift` | pull towards the camera so hills don't cut the sprite; air units float `lift` cells (default 1.2) above their shadow |

Sprites are batched (one draw call per sheet), alpha-tested, depth-tested against the 3D scene and
painter-sorted; textures are read with `platform::readContentFile`. Types without `sprite` keep
their 3D `view`, so a map can mix both.

### Sprite shadows and lighting (`sprites` block)

Game-wide defaults in `game.json` (wins) or `rules.json`:

```json
"sprites": { "shadow": "cast", "lit": true }
```

| key | meaning |
|---|---|
| `shadow` | default `shadow` of every sprite type: `"blob"` (default, the classic look), `"cast"`, `"none"` |
| `lit` | sprites take the scene light (default `false`: painted colours, pixel-art purists): sun and sky colour, day/night and presets, point lights, cloud shadows and (Medium/High) the sun shadows of other objects falling on them. In full default daylight a lit sprite keeps its painted colours |

**Cast shadows**: the sprite is drawn into the sun shadow map as an upright alpha-tested quad
standing at its foot, facing the camera's yaw (turned towards the sun when the sun shines almost
along it), current animation frame and facing; the shadow then falls on the terrain, 3D models
and other lit sprites with the sun direction, softness and PCF tiers of the 3D games.

| `RTS_SHADOWS` / shadow tier | sprites with `"shadow": "cast"` |
|---|---|
| Off | blobs only (the classic look, no shadow pass) |
| Low | buildings cast, units keep blobs; sprites don't sample the shadow map |
| Medium / High | everything casts (units keep a faint contact blob); lit sprites receive shadows |

Where shadows fall is the sun's direction: `"lighting": {"sunDir": [x, y, z]}` (game.json or the
map, towards the sun at noon; the day cycle swings around it). Flat drawings hide shadows that
fall straight behind them, and a sun behind the scene leaves camera-facing cliff walls unlit, so
sprite games usually want it from the side and a little in front (km2d: `[-1.0, 1.2, 0.45]`,
shadows to the right). `"shadowSoftness"` (world units, default 0.22) is the penumbra radius;
pixel-art games look cleaner with a tight one (km2d 0.07): kernels of a few shadow-map texels are
filtered without the per-pixel noise rotation, so they stay smooth on every tier.

**Blobs and ground sprites are projected**: a blob (and any `"mode": "ground"` sprite) is cut from
the ground triangles under it — the exact triangles of the terrain mesh or the tile map — and drawn
with a depth bias, so it bends over slopes and cliff edges and never z-fights or hovers. Sprite
types get no extra contact-shadow decal from the lighting system (their blob does that job).

### Tilesets (`tilesets/<name>.json`)

```json
{"name": "Desert", "atlas": "tilesets/desert.png", "tileSize": [32, 32], "columns": 8, "filter": "nearest",
 "terrains": [
   {"id": "sand",  "char": "s", "cell": ".", "color": [0.84, 0.71, 0.47], "tiles": [0, 1, {"tile": 2, "weight": 0.6}]},
   {"id": "spice", "char": "o", "cell": ".", "field": {"resource": "crystal", "density": 9},
    "under": "sand", "depleted": "sand", "tiles": [4, 5], "autotile": {"type": "corner16", "first": 104}},
   {"id": "rock",  "char": "r", "cell": "R", "level": 0, "under": "sand", "tiles": [6, 7], "autotile": {"type": "blob47", "first": 8}},
   {"id": "cliff", "char": "c", "cell": "#", "under": "sand", "autotile": {"type": "mask16", "first": 120}},
   {"id": "water", "char": "w", "cell": "~", "under": "sand", "autotile": {"type": "blob47", "tiles": [56, 57, "... 47 indices"], "with": ["deep"]}}]}
```

Atlas tile `i` is at column `i % columns`, row `i / columns`. Per terrain:

| key | meaning |
|---|---|
| `char` | character of the terrain in the map's `tiles.rows` |
| `cell`, `level`, `field` | **gameplay**: cell kind (`. ~ # , = / R`, as in `terrain.rows`), cliff level 0..9, resource field `{resource, density 1..9}` |
| `tiles` | base variants (weights optional, default 1; picked by a deterministic per-cell hash) — also used for the interior of autotiled terrain |
| `autotile` | edges/corners chosen from the 8 neighbours. `mask16`: 4 edges, index N=1 E=2 S=4 W=8. `corner16`: 4 corners (a corner counts when its 3 cells are the same terrain), index NE=1 SE=2 SW=4 NW=8. `blob47`: 8 neighbours, a corner only counts with both its edges; the 47 shapes in ascending order of the mask N=1 NE=2 E=4 SE=8 S=16 SW=32 W=64 NW=128 (index 0 = isolated, 46 = full). `first` (consecutive tiles) or `tiles` (explicit list); `with`: other terrains that count as the same. Out-of-map neighbours count as the same |
| `under` | terrain whose base is drawn below the transparent edge pieces |
| `depleted` | view only: shown once the cell's resource field is used up |
| `color` | palette colour (editor) |

### Map `tiles`

```json
"tiles": {"tileset": "tilesets/desert.json", "rows": ["sssrrr", "..."], "fixed": [[x, y, tile]], "seed": 0}
```

When a map with `tiles` is loaded (game, headless, editor play), the tile terrains' gameplay is
written into `terrain.rows`, `terrain.levels` and a `fields` entry (`"fromTiles": true`) before the
simulation starts — deterministic and idempotent; the simulation itself knows nothing about tiles.
The editor also bakes it while painting, so saved maps carry valid terrain anyway. `fixed` places
exact atlas tiles (autotile off). Visuals: autotile per cell, at most two quads per cell (`under` +
the tile), one static mesh.

Editor: window **Тайлы** (palette, brush, autotile on/off, atlas picker; paints in the Scene view).
Agents: `tileset_list`, `tiles_init {tileset, fill | fromTerrain}`, `tile_paint {terrain, x, y, radius | rect, tile?}`,
`tile_info {x, y}`, `tiles_remove`.

## Fog of war look

Visual keys of rules.json `"fogOfWar"` (game.json `"fogOfWar"` overrides key by key; editor window
**Туман войны**, or `rules_merge {path: "fogOfWar", value: {...}}` over MCP):

```json
"fogOfWar": {
  "mode": "full",                 // simulation: full | explored | none (see rules table)
  "show": true,                   // false: no fog drawn (enemies outside sight stay hidden)
  "color": [8, 10, 14],           // 0..255 or 0..1
  "unexplored": 0.92, "explored": 0.47,   // opacity over never-seen / seen-before ground
  "style": "smooth",              // smooth | cells | grid (cells + lines) | pattern (dithered edge, classic)
  "softness": 2,                  // blur radius in cells (smooth, pattern)
  "fade": 0.3,                    // seconds for a cell to clear / fog over
  "noise": 0.0,                   // 0..1 cloudy moving edges
  "height": 1.3,                  // sheet height above the ground (covers units and low buildings)
  "grid": {"show": "fog", "color": [255, 255, 255], "alpha": 0.15}   // none | fog | all
}
```

Weak GPUs (shadow quality off/low) draw `smooth` as `cells` without noise. Heightfield maps draw
the fog in the terrain shader (colour, transparency, cells, grid; `pattern` and `noise` are
sheet-only).

### 3D line of sight

With `"fogOfWar": {"lineOfSight": true}` (always on for heightfield maps with `heights.blockVision`)
each ground unit sees a cell only if the straight line from its eyes to the cell clears every cell in
between. Heights: heightfield surface, or cliff level × `levelHeight` on level maps; plus dynamic
occluders, recomputed every vision pass (5 ticks):

| Source | Key | Height above the ground |
|---|---|---|
| Unit or structure type (walls, forests, tall buildings) | type `"vision": {"blocks": 3}` | over its footprint (structures) or its cell; gone when it dies |
| Smoke, dust, wall-of-fog skills | delivery `{"type": "area", "radius": 2, "lifetime": 10, "blocksVision": 4}` | disc of the area while it lasts |
| Undug rock | `fogOfWar.rockHeight` (2, 0 = transparent) | every rock cell |

Eyes: `terrain.eyeHeight` + type `"vision": {"eye": 6}` (watchtowers see over walls and hills);
targets count `terrain.targetHeight`. Air units and types with `"vision": {"seesOver": true}` see the
full circle. Integer math, deterministic; editor: **Туман войны** → "3D: линия видимости".

## Overlays (helper elements on screen and in the world)

Optional list `"overlays"` in rules.json; game.json `"overlays"` adds entries or overrides them **by
id**. An overlay is a condition (`when`), a place (`anchor`), a `shape` and a `style`, optionally
spawned by simulation `event`s. Presentation only: overlays never change the simulation. Editor:
window **Оверлеи** (list, templates, JSON, preview); MCP: `overlay_templates`, `overlay_list`,
`overlay_get`, `overlay_set`, `overlay_delete`, `overlay_preview` (+ `view_screenshot`).

```json
"overlays": [
  { "id": "build_grid", "when": "placing", "anchor": "ghost",
    "shape": {"type": "grid", "radius": 4, "predicate": "buildable"},
    "style": {"colors": {"true": "#3cff6450", "false": "#ff3c3c60"}, "lineColor": "#ffffff38", "outerAlpha": 0.55} }
]
```

**Built-in overlays** are ordinary entries (the look the engine always had); override any key by id
(objects are deep-merged, `"replace": true` replaces the whole entry), or hide one with
`{"id": "health_bars", "enabled": false}`. A game without the block looks exactly as before.

| id | what |
|---|---|
| `selection` | ring under selected objects (`#78ff78e6`; neutral objects `#ffffa0e6`) |
| `hover` | ring under the hovered object when it is not selected |
| `move_markers` | small ring where a move order was given |
| `placement` | footprint of the structure being placed, green / red (`predicate: "ok"`) |
| `garrison_count` | garrison number in an owner-coloured pill |
| `health_bars` | hp bar of selected / hovered / damaged objects (26 px units, 46 px structures) |
| `build_progress` | construction bar |

Entry keys: `id` (required, unique), `enabled` (default true), `order` (draw order, default 0, then
list order), `when`, `anchor`, `shape`, `style`, `event`; `name` / `description` are free text.
Unknown keys, types, tags, statuses, colours or impossible combinations are errors
(`overlay 'x'.anchor.types: unknown type 'dragon'`); at game start a broken entry is skipped with a
warning, `overlay_set` refuses it.

### when

A string, a list (all must hold) or an object (every key must hold). Strings: `always`, `never`,
`placing`, `selected`, `hovered`, `cursor`, `playing`, `paused`, `over`.

| key | holds when |
|---|---|
| `always` | `true` / `false` |
| `placing` | `true`: a structure is being placed; `"id"` / `["id", "tag:x"]`: one of these types |
| `selected` | entity anchors: **this** object is selected (`false`: is not); other anchors: something selected. A filter object / type list narrows it: `{"selected": {"owner": "own", "flags": ["ranged"]}}` |
| `hovered` | the same for the object under the cursor |
| `entity` | entity filter on the anchored object (other anchors: any visible object matches) |
| `types`, `tags`, `owner`, `flags`, `status`, `hp` | shorthand for an `entity` filter at the top level |
| `key` | keys held: `"Alt"`, `["Shift", "Q"]` (A–Z, 0–9, F1–F12, Shift, Ctrl, Alt, Super, Space, Tab, Enter, arrows) |
| `state` | `"playing"` / `"paused"` / `"over"` or a list |
| `var` / `flag` | trigger variable: `"alarm"` (non-zero) or `{"name": "alarm", ">=": 3}` (`==`, `!=`, `<`, `<=`, `>`, `>=`) |
| `zoom` | camera distance in `[min, max]` |
| `cursor` | the cursor is over the map (`true` / `false`) |
| `mode` | client input mode: `normal`, `attack`, `patrol`, `place`, `rally`, `ability`, `claim` |
| `any` / `all` / `not` | combinations |

**Entity filter** (`when`, entity anchors): `types` (ids or `"tag:x"`), `tags`, `owner` (`own`,
`ally`, `friendly`, `enemy`, `neutral`, `any`, or a list), `flags` (all must hold, `!` negates:
`structure`, `unit`, `constructing`, `damaged` (hp < 99.9%), `garrison`, `moving`, `producing`,
`idle`, `hero`, `worker`, `invulnerable`, `air`, `carrying`, `attacking`, `resource`, `energy`,
`ranged` (a weapon with range > 1.5), `aura`), `status` (any of these statuses active), `hp`
(`[min, max)` fraction).

### anchor

`"name"` or `{"type": "name", ...}`.

| anchor | elements at |
|---|---|
| `selected` | every selected object (optional entity filter keys) |
| `hovered` | the object under the cursor |
| `entities` | every visible object matching the filter: `{"type": "entities", "owner": "own", "flags": ["structure"]}` |
| `cursor` | the cursor on the ground (`"snap": true`: cell centre) |
| `ghost` | the structure being placed (centre, its type for footprint / stats, `ok` = placement valid) |
| `area` | `{"type": "area", "area": "gate"}` (map area) or `"rect": [x, z, w, h]` |
| `point` | `{"type": "point", "at": [x, z]}` |
| `screen` | HUD point `{"type": "screen", "at": [x, y]}` in points; negative = from the right / bottom; text boxes hang from that corner |
| `orders` | line through the queued order points of selected units |
| `route` | the current path of selected moving units |
| `rally` | from selected producers to their rally point |
| `markers` | move order markers |
| `map` | the camera target (for `cells`) |

Event overlays have no anchor: they sit where the event happened.

### shape

`"name"` or `{"type": "name", ...}`.

| shape | keys |
|---|---|
| `ring`, `circle` | `radius`: number (cells) or a stat of the anchored type: `range` / `range:N` (weapon N, + body radius, + upgrades), `minRange`, `sight`, `aura` (`aura:N` = ability N), `buildRadius`, `selection`, `capture`, `claim`, `footprint`, `ability:N` (cast range), `leash`; `radiusScale`, `radiusAdd`. `circle` is filled |
| `rect` | `size: [w, h]` around the anchor; area anchors: the area |
| `footprint` | footprint of the ghost / object type, `margin` cells around |
| `grid` | cells within `radius` around the anchor (ghost: around its footprint; `square: true`), filled by `predicate` (`colors.true` / `.false`), cell lines with `style.lineColor`; `highlightFootprint` (default true: cells under the ghost at full alpha, the rest `style.outerAlpha` and fading out) |
| `cells` | every cell within `radius` (default 24) of the anchor matching `predicate`; `territoryEdge` draws owner-coloured borders |
| `line`, `arrow` | from the anchor `to`: `target` (current attack target), `rally`, `cursor`, `order` (first order point), `[x, z]`; `head` = arrow head length. With `orders` / `route` / `rally` anchors: the path |
| `path` | the `orders` / `route` / `rally` polyline |
| `text` | `text` with placeholders `{value}` (event value; hits: damage), `{amount}`, `{resource}`, `{name}`, `{hp}`, `{maxHp}`, `{energy}`, `{garrison}`, `{build}` (%), `{selected}` (count), `{owner}`, `{player}`, `{var:NAME}`; `size` in font heights. Always screen space |
| `icon` | `image` (texture path, atlases work), `size` (world units; points in screen space) |
| `bar` | `value`: `hp`, `energy`, `build`, `garrison`, `production`, `carry`, `capture`; `width`, `widthStructure`, `height` in points. Entity anchors only, above the object |

Predicates: `ok` (ghost placement valid), `buildable`, `blocked`, `buildRadius`, `walkable`,
`water`, `resource`, `creep`, `road`, `region`, `territory` (own), `enemyTerritory`, `anyTerritory`,
`territoryEdge`, `visible`, `explored`, `fogged`, `unexplored`. Cells the local player has not
explored never show resources / territory.

### style

| key | meaning |
|---|---|
| `color` | `[r, g, b, a]` (0..1 or 0..255), `"#rrggbb[aa]"`, a name (`white`, `red`, `gold`, ...) or `"player"` (owner colour) |
| `colors` | per predicate result `true` / `false` and per owner relation `own`, `ally`, `enemy`, `neutral` |
| `stops` | bars: `[[0.3, red], [0.6, yellow], [1, green]]` (first stop >= value) |
| `fillColor`, `lineColor` | fill / outline when both are drawn |
| `alpha`, `thickness` | thickness in world units (0 = 1-pixel line; screen space: points) |
| `fill`, `outline` | defaults by shape (`circle`, `grid`, `cells` filled; `ring`, `rect`, `footprint` outlined) |
| `dash` | `[on, off]` world units; `scroll` = dash speed per second |
| `pulse`, `pulseMin` | alpha pulse in Hz down to `pulseMin`; `rotate` radians / s (rings, icons) |
| `fadeIn`, `fadeOut`, `fade` | seconds (conditions of non-entity anchors, event popups) |
| `onTop` | drawn over everything (no depth test); `additive` / `blend: "add"` glows |
| `space` | `ground` (draped over the terrain), `billboard` (faces the camera), `screen` (ImGui overlay), `minimap` (rings / discs / rects on the client minimap) |
| `ground` | `follow` (each vertex on the terrain, default), `flat` (height under the anchor), `zero` |
| `lift`, `segments`, `offset` | height above the ground; ring segments; screen offset `[x, y]` |
| `background`, `backgroundShade`, `backgroundAlpha`, `padding`, `rounding`, `border`, `shadow` | text / bar boxes |
| `outerAlpha`, `falloff` | grids / cells: alpha outside the footprint, fade towards the edge |

### event

`"hit"` or `{"on": "hit" | [...], "lifetime": 1.2, "rise": 0, "grow": 0, "spread": 0, "by": "own",
"owner": "enemy", "types": [...], "max": 32}`: every matching simulation event spawns a popup at its
position for `lifetime` seconds, rising `rise` units / s, rings / icons growing `grow` / s. `by` =
relation of the player who caused it, `owner` = of the object it happened to, `types` = its type.
Events: `hit`, `died`, `spawned`, `attack`, `gathered`, `delivered`, `produced`, `ability`, `cast`,
`impact`, `miss`, `built`, `placed`, `trained`, `researched`, `levelup`, `captured`, `sold`,
`upgraded`, `alert` (under attack), `status`, `area`, `claimed`, `wave`, `message`, `ping` (pings of
the client / editor). Popups never appear in cells the local player cannot see.

**Quality tiers** (renderer material quality; `RTS_OVERLAYS=low|medium|high` for testing): game
overlays are capped per overlay (48 / 192 / 1024 elements), per grid / cells shape (600 / 3000 /
12000 cells) and in live popups (24 / 96 / 256); low halves ring segments. Built-in overlays are
never capped.

### Recipes

```json
// 1. build grid while placing (any building), cells under the ghost brighter
{"id": "build_grid", "when": "placing", "anchor": "ghost",
 "shape": {"type": "grid", "radius": 4, "predicate": "buildable"},
 "style": {"colors": {"true": "#3cff6450", "false": "#ff3c3c60"}, "lineColor": "#ffffff38", "outerAlpha": 0.55, "lift": 0.07}}
// 2. attack range of selected own ranged units / towers, dashed and scrolling
{"id": "attack_range", "anchor": {"type": "selected", "owner": "own", "flags": ["ranged"]},
 "shape": {"type": "ring", "radius": "range"}, "style": {"color": "#ff6a4ac0", "thickness": 0.06, "dash": [0.6, 0.35], "scroll": 0.4, "segments": 64}}
// 3. range preview while placing a tower only
{"id": "tower_range", "when": {"placing": ["tower"]}, "anchor": "ghost", "shape": {"type": "ring", "radius": "range"},
 "style": {"color": "#ffd24ad0", "thickness": 0.05}}
// 4. aura radius
{"id": "aura_radius", "anchor": {"type": "selected", "flags": ["aura"]}, "shape": {"type": "circle", "radius": "aura"},
 "style": {"color": "#7ac8ff40", "outline": true, "lineColor": "#9ad8ffc0", "pulse": 0.5, "pulseMin": 0.6}}
// 5. rally line with an arrow
{"id": "rally_line", "anchor": "rally", "shape": {"type": "arrow"},
 "style": {"color": "#78ff78d0", "thickness": 0.07, "dash": [0.5, 0.3], "scroll": 1.5, "lift": 0.12}}
// 6. damage numbers
{"id": "damage_numbers", "event": {"on": "hit", "lifetime": 1.0, "rise": 1.6, "spread": 0.5},
 "shape": {"type": "text", "text": "-{value}", "size": 1.1}, "style": {"color": "#ffe070ff", "colors": {"own": "#ff7060ff"}, "fadeOut": 0.4, "lift": 1.4}}
// 7. resource gained
{"id": "resource_popup", "event": {"on": "gathered", "by": "own", "lifetime": 1.4, "rise": 1.2},
 "shape": {"type": "text", "text": "+{amount} {resource}"}, "style": {"color": "#ffd84aff", "fadeOut": 0.5, "lift": 1.6}}
// 8. territory borders near the hovered structure
{"id": "territory_hover", "when": {"hovered": {"flags": ["structure"]}}, "anchor": "cursor",
 "shape": {"type": "cells", "predicate": "territoryEdge", "radius": 14}, "style": {"color": "player", "thickness": 0.08}}
// 9. ping marker (alerts and client pings), always on top
{"id": "ping_marker", "event": {"on": ["ping", "alert"], "lifetime": 2.0, "grow": 1.5}, "shape": {"type": "ring", "radius": 0.6},
 "style": {"color": "#ffd040ff", "thickness": 0.1, "fadeOut": 0.8, "pulse": 3, "onTop": true}}
// 10. minimap ping
{"id": "minimap_ping", "event": {"on": "alert", "lifetime": 3.0, "grow": 2}, "shape": {"type": "ring", "radius": 2},
 "style": {"space": "minimap", "color": "#ffe040ff", "pulse": 2, "fadeOut": 1}}
// 11. sight range of own units while Alt is held
{"id": "sight_alt", "when": {"key": "Alt"}, "anchor": {"type": "entities", "owner": "own", "flags": ["unit"]},
 "shape": {"type": "ring", "radius": "sight"}, "style": {"color": "#ffffff50"}}
// 12. pulsing warning under badly damaged own units
{"id": "low_hp", "anchor": {"type": "entities", "owner": "own", "hp": [0, 0.3]},
 "shape": {"type": "ring", "radius": "selection", "radiusAdd": 0.15}, "style": {"color": "#ff3030ff", "thickness": 0.06, "pulse": 2}}
// 13. build radius of own bases while placing
{"id": "build_radius", "when": "placing", "anchor": "ghost", "shape": {"type": "cells", "predicate": "buildRadius", "radius": 18},
 "style": {"colors": {"true": "#60b0ff22"}}}
// 14. energy bar of selected casters
{"id": "energy_bar", "anchor": {"type": "selected", "flags": ["energy"]}, "shape": {"type": "bar", "value": "energy", "height": 3},
 "style": {"offset": [0, 6], "background": "#000000aa", "color": "#4aa0ffff"}}
// 15. a decal under the hero, rotating
{"id": "hero_decal", "anchor": {"type": "entities", "owner": "own", "flags": ["hero"]},
 "shape": {"type": "icon", "image": "ui/hero_ring.png", "size": 2.4}, "style": {"rotate": 0.6, "alpha": 0.8}}
// 16. a gate area highlighted while a trigger variable is set
{"id": "gate", "when": {"var": "gate_open"}, "anchor": {"type": "area", "area": "gate"}, "shape": "rect",
 "style": {"fill": true, "color": "#40e0ff80", "pulse": 1}}
// 17. restyle / hide built-ins
{"id": "selection", "style": {"color": "#40c0ffff", "thickness": 0.06, "ground": "follow"}}
{"id": "health_bars", "enabled": false}
```

The client gives the overlays its input state each frame (cursor, structure being placed, held
keys, input mode, pause); the editor's Scene view passes the Place tool's structure, so placement
overlays can be checked while placing objects, and `overlay_preview` / the window's checkboxes draw
any overlay regardless of its `when`.

## Post effects (`postfx`)

`game.json` and maps can have a `"postfx"` block: a list of full-screen effects (bloom, colour
grading, LUT, vignette, tilt-shift, sun shafts, FXAA, grain, ...) with quality tiers and a frame-cost
model. Format, parameters, tiers and MCP tools: `docs/postfx.md`.

### Initial script variables (local match setup)

Optional map `initialVars` is an object of integer trigger variables loaded before user scripts. Example: `"initialVars": {"loadout_support_1": 2}`. At most 128 keys, ASCII letters/digits/underscore/dot/hyphen, length 1–128; integers −1000000..1000000. Values enter ordinary `trig.vars` hashing. Client UI can pass overrides with `game.start(..., {initialVars=...})`; see docs/ui-scripting.md. Saved map/replay setup retains the options, and omitted options preserve old behavior.
## Computer player (`RtsAI`, agent-ai-terrain)

The bot reads the state and submits commands like a player (replays don't re-run it). Generic for every template;
knobs in rules `ai` (above). What it does with the terrain:

- **Analysis at match start** (`RtsAITerrain.*`, integer, rebuilt identically after loading a save): per cell the
  elevation in height-advantage units (cliff level, or heightfield / planet height divided by `levelHeight`), the
  walkable mask of the ground layer (terrain only), corridor width (steps to the nearest wall: chokepoints), `over`
  (how far higher ground within 4 cells rises above the cell) and `crest` (prominence). Flat maps, heightfields and
  cube-sphere planets (neighbours across face seams) alike.
- **Routes**: weighted Dijkstra from our base to the nearest enemy base: climbing into the enemy and cells overlooked
  by higher ground cost extra (`climbWeight`, `exposureWeight`), so waves come through saddles and ramps instead of
  up a ridge under fire; an alternate route avoids the main corridor (used on odd waves when stalemated).
- **Posts on the route**: rally point on the highest well-covered ground 9-14 steps out of the base (the army waits
  there, producers rally there); the narrowest cell on our side (towers after a raid); a watch post on the most
  prominent ground in the middle of the route for a scout (vision over ridges). Idle units are not re-sent to the
  rally point (a unit walking back would not count as ready for the next wave).
- **Waves** follow waypoints every 12 cells, stop at a siege spot on high ground short of the target, then attack;
  they hold up to 30 s instead of charging uphill into a stronger enemy (and pull in reinforcements), retreat to the
  rally point below 25% of their start size without a kill (until stalemate level 3), launch early with what is at
  home when our army is twice the enemy's whole armed force, stop at a stuck-wave watchdog (30 s without moving), retarget the next structure, attack construction sites by name.
- **Economy guards**: own build spots (lanes between dropoffs and resources kept free, the rally area kept free,
  random tie-breaks), stuck builders released and their spots avoided, the first army producer early, converters
  (metal makers) only with a surplus, one more producer when resources float, expansion (a dropoff at the next
  node) when the near nodes are gone, workers spread over crowded nodes and spawned on the side of their resource.
- **Breaking stalemates**: an enemy without armed units is finished by the whole army (its weakest structure that
  counts); at stalemate level 1+ a smaller strength edge launches a wave and at level 2+ waves are capped at 3/4 of
  `firstAttackArmy`; the bot builds / researches what unlocks units clearly better against the enemy's toughest
  building (damage table, bonuses, armor) and saves for it; garrison play sends from full garrisons first, funnels
  them to the front and after 10 min lets every garrison join a push; settlers economies build the main building
  material chain first, then what the army costs; a stock the population eats running dry stops housing; regions
  that must be seen first get a scout; slow gatherers (no `workersPerBase` in the rules) get more workers.
- **Planets**: an orbit fleet (`invasionSize` + 2 per invasion) transfers together to the body with enemy
  structures and fights there until the body is clear, then the next body; more orbital yards when the enemy can be
  reached only through orbit; towers that hit the orbit when attacks come from there.
- **Save states**: `RtsAI::saveState()` / `loadState()` (headless `--save F` writes `F.ai` next to the sim state,
  `--load F` reads it): a restored bot plays on exactly like the saved one.

