// Platform layer: window/surface, main loop, input, file access.
// One implementation per OS lives next to this file; the game/editor only sees this API.
//
// Entry point: the application defines   int rtsMain(int argc, char** argv);
// and calls platform::run() from it. Each platform provides the real main()/android_main/WinMain.
#pragma once
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace rts::gfx { class Device; }

namespace rts::platform {

enum class Key : uint16_t {
    Unknown = 0,
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,
    Num0, Num1, Num2, Num3, Num4, Num5, Num6, Num7, Num8, Num9,
    Escape, Enter, Tab, Backspace, Delete, Insert, Space,
    Left, Right, Up, Down, Home, End, PageUp, PageDown,
    LeftShift, RightShift, LeftCtrl, RightCtrl, LeftAlt, RightAlt, LeftSuper, RightSuper,
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,
    Minus, Equal, LeftBracket, RightBracket, Semicolon, Apostrophe, Comma, Period, Slash, Backslash, GraveAccent,
    Count
};

enum Mod : uint8_t { kModShift = 1, kModCtrl = 2, kModAlt = 4, kModSuper = 8 };

enum class EventType : uint8_t {
    MouseDown, MouseUp, MouseMove, MouseWheel,
    KeyDown, KeyUp, Char,
    TouchBegin, TouchMove, TouchEnd, TouchCancel,
    Resized, FocusGained, FocusLost, QuitRequested,
    TextInputEnded,   // the user closed the on-screen keyboard (Done, Back, hide key): blur the field
    KeyboardChanged,  // on-screen keyboard shown/hidden/resized: see softKeyboardHeight()
    OpenFile,         // the OS asks the app to open a document (double-click, Open With, Dock drop): Event::path
};

struct Event {
    EventType type{};
    float x = 0, y = 0;          // logical points, origin top-left
    float wheelX = 0, wheelY = 0;
    int button = 0;              // 0 left, 1 right, 2 middle
    Key key = Key::Unknown;
    uint32_t codepoint = 0;      // Char
    int64_t touchId = 0;
    uint8_t mods = 0;
    bool repeat = false;
    std::string path;            // OpenFile: absolute path (UTF-8); delivered after init, between frames
};

struct AppConfig {
    std::string title = "RTSEngine";
    int width = 1280, height = 720;  // logical size of the initial window (desktop)
    bool highDpi = true;
    float clearColor[3] = {0.08f, 0.09f, 0.11f};  // window background until the first frame (Windows, macOS)
    // "landscape" | "portrait" | "any". Locks the screen when the web build goes fullscreen; native
    // mobile apps get it from game.json through rtsbuild (Info.plist / AndroidManifest).
    std::string orientation = "landscape";
};

struct AppCallbacks {
    std::function<void(gfx::Device&)> init;          // device ready (after window creation)
    std::function<void(gfx::Device&, double dt)> frame;  // called every display refresh; must call beginFrame/endFrame
    std::function<void(const Event&)> event;
    std::function<void()> shutdown;
};

// Runs the main loop. Returns the exit code (on iOS/web it may never return).
int run(const AppConfig& cfg, AppCallbacks cb);

// --- queries valid while running ---
float windowWidth();      // logical points
float windowHeight();
int framebufferWidth();   // pixels
int framebufferHeight();
float dpiScale();         // framebuffer pixels per logical point
bool isTouchDevice();
const char* name();       // "macos", "ios", "android", "web", "windows", "linux"
void requestQuit();        // Android's Back button arrives as Key::Escape; quit from your own menu
void setTitle(const std::string& title);

// --- screen ---
// Parts of the window covered by hardware or system UI: notch / Dynamic Island, rounded corners,
// home indicator, display cutouts, system bars. Logical points from each edge; 0 on desktop.
// Keep buttons and text inside, let backgrounds extend under them. Changes arrive as Resized.
struct Insets { float left = 0, top = 0, right = 0, bottom = 0; };
Insets safeAreaInsets();
// Desktop: borderless fullscreen window. Web: browser fullscreen + orientation lock (call it from
// an input event handler — browsers require a user gesture). Mobile apps are always fullscreen.
// The user can leave fullscreen on their own (Esc in a browser): isFullscreen() follows that.
// Built-in toggles: F11 (Windows, Linux, web), Alt+Enter (Windows), the green button (macOS).
void setFullscreen(bool on);
bool isFullscreen();

// --- text input / on-screen keyboard ---
// Call startTextInput when a text field gets focus and stopTextInput when it loses it. Phones and
// tablets (iOS, Android, mobile browsers) show the on-screen keyboard; on desktops it is a no-op,
// the physical keyboard already sends KeyDown/Char. Typed text arrives as Char events in any
// language (after IME composition), Backspace and Enter as KeyDown + KeyUp.
// `area` is the focused field in logical points; it keeps the field where the user expects it
// (web places its hidden input there, so the browser doesn't scroll or zoom).
// Web: call it while handling the touch/mouse event that focused the field — mobile browsers open
// the keyboard only inside a user gesture.
struct TextInputArea { float x = 0, y = 0, w = 0, h = 0; };
void startTextInput(const TextInputArea& area = {});
void stopTextInput();
bool textInputActive();
// Height of the bottom part of the window covered by the on-screen keyboard, in logical points
// (0 when hidden or on desktop). Move the focused field above it. Changes: EventType::KeyboardChanged.
float softKeyboardHeight();

// --- files ---
// Content (rules, maps, textures) shipped with the app: bundle Resources on Apple, APK assets on
// Android, preloaded virtual FS on web, folder next to the executable elsewhere.
std::string contentRoot();
bool readContentFile(const std::string& relativePath, std::string& out);
// Resource packs: `<content>/content.rpak` is mounted automatically; files in packs win over
// loose files. mountPack adds another pack on top (patch, DLC); path is relative to the content
// root or absolute. Returns false (and logs why) if the pack can't be opened.
bool mountPack(const std::string& path);
// Content hash of the mounted packs (0 when running from loose files) — identifies the data set.
uint64_t contentPacksHash();

// Split builds (rtsbuild --split): content not shipped with the app lives in pack chunks that are
// downloaded on demand from the sources in game.json `packaging.sources` (mirrors tried in order),
// sources set here, or $RTS_CONTENT_SOURCES (';'-separated). Chunks are verified (SHA-256) and
// cached in userDataDir()/content-cache. readContentFile on a file that isn't downloaded yet
// returns false and queues its chunk; a loading screen polls contentProgress() until it's ready.
enum class ContentState { Missing, Ready, NotDownloaded };
ContentState contentState(const std::string& relativePath);
void requestContent(const std::vector<std::string>& relativePaths);   // chunks holding these files
void requestAllContent();
struct ContentProgress {
    size_t chunks = 0, ready = 0, active = 0, failed = 0;
    uint64_t bytesTotal = 0, bytesReady = 0;   // over requested and ready chunks
    bool busy = false;
    std::string error;                         // last failure (after all sources were tried)
};
ContentProgress contentProgress();             // also drives downloads
void pollContent();                            // drives downloads; called once per frame by the platform loop
void setContentSources(const std::vector<std::string>& urls);
// Writable per-user directory (settings, saved replays).
std::string userDataDir();
// Makes recent writes to userDataDir() durable. Native platforms write through (no-op); the web
// keeps the folder in IndexedDB and also syncs by itself every few seconds and when the page hides.
void syncUserData();
// Text clipboard (copy/paste). Web: setClipboardText writes the system clipboard; reading the
// system clipboard silently is not allowed by browsers, so clipboardText() returns what the user
// pasted last (Ctrl/Cmd+V is delivered after the browser handed over the pasted text).
std::string clipboardText();
void setClipboardText(const std::string& s);
// Opens an http(s) / mailto link in the system browser / mail app (terms of use, privacy policy, store pages).
// Other schemes are refused (false). Web: a new tab (call it from a click handler or the popup blocker may stop it).
bool openUrl(const std::string& url);
namespace detail { bool urlAllowed(const std::string& url); }

} // namespace rts::platform

int rtsMain(int argc, char** argv);
